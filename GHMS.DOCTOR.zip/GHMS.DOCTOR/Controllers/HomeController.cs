﻿using GHMS.DOCTOR.Helpers;
using GHMS.DOCTOR.MODEL.Models;
using GHMS.DOCTOR.ViewModels;
using GHMS.UTILITY;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace GHMS.DOCTOR.Controllers
{
    public class HomeController : Controller
    {
        private static string API_PATIENT_ENDOINT = "Patient/";
        private static string API_VISIT_ENDOINT = "Visit/";
        private static string API_ASSESSMENT_ENDOINT = "Assesment/";
        private static string API_FOLLOWUP_ENDOINT = "Followup/";

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public PartialViewResult Search(string recordNo)
        {            
            MedicalRecord medicalRecord = new MedicalRecord();           
            medicalRecord._PatientDetails = new Patient();
            medicalRecord._PatientDetails.PATIENT_ID = recordNo;
            try
            {
                Task<APIResponse<Patient>> aPIResponse_Patient = APIHelper.Get<Patient>(Constants.API_DOCTOR_BASE_URL + API_PATIENT_ENDOINT + recordNo);
                medicalRecord._PatientDetails = aPIResponse_Patient.Result.Response;

                Task<APIResponse<Visit>> aPIResponse_Visits = APIHelper.Get<Visit>(Constants.API_DOCTOR_BASE_URL + API_VISIT_ENDOINT + recordNo);
            }
            catch(Exception)
            { }
            return PartialView("MedicalRecord", medicalRecord);
        }

        [HttpGet]
        public PartialViewResult GetAssessment(string id)
        {
            Assessment assessment = new Assessment();
            try
            {
                Task<APIResponse<Assessment>> aPIResponse_Assessment = APIHelper.Get<Assessment>(Constants.API_DOCTOR_BASE_URL + API_ASSESSMENT_ENDOINT + id);
                assessment = aPIResponse_Assessment.Result.Response;
                if (assessment == null)
                {
                    assessment = new Assessment();
                    assessment.PATIENT_ID = id;
                    assessment.CONSULTANT_ID = 1045;
                    assessment.DT_TIME = DateTime.Now;
                }
            }
            catch(Exception)
            { }
            return PartialView("Initialassessment", assessment);
        }      

        [HttpPost]
        public PartialViewResult CreateAssessment(Assessment assessment)
        {
            assessment.CONSULTANT_ID = 1045;
            assessment.DT_TIME = DateTime.Now;
            Task<APIResponse<Assessment>> aPIResponse = APIHelper.Post<Assessment,Assessment>(Constants.API_DOCTOR_BASE_URL + API_ASSESSMENT_ENDOINT, assessment);
            assessment = aPIResponse.Result.Response;
            ViewBag.AssessmentMessage = Constants.CREATE_SUCCESS_MSG;
            return PartialView("Initialassessment", assessment);
        }

        [HttpGet]
        public PartialViewResult GetFollowups(string id)
        {
            Task<APIResponse<IEnumerable<FollowupNote>>> aPIResponse_FollowupNote = APIHelper.Get<IEnumerable<FollowupNote>>(Constants.API_DOCTOR_BASE_URL + API_FOLLOWUP_ENDOINT + id);
            ClinicalNotes clinicalNotes = new ClinicalNotes();
            FollowupNote followupNote = new FollowupNote();
            followupNote.PATIENT_ID = id;
            clinicalNotes.followupNote = followupNote;
            clinicalNotes.followupNotes = aPIResponse_FollowupNote.Result.Response;
            return PartialView("FollowupNoteSummary", clinicalNotes);
        }

        [HttpPost]
        public PartialViewResult CreateFollowupNote(FollowupNote followupNote)
        {
            followupNote.VISIT_ID = 1;
            followupNote.CONSULTANT_ID = 1045;
            followupNote.DT_TIME = DateTime.Now;
            Task<APIResponse<FollowupNote>> aPIResponse = APIHelper.Post<FollowupNote, FollowupNote>(Constants.API_DOCTOR_BASE_URL + API_FOLLOWUP_ENDOINT, followupNote);
            //followupNote = aPIResponse.Result.Response;
            ViewBag.FollowupNoteMessage = Constants.CREATE_SUCCESS_MSG;
            Task<APIResponse<IEnumerable<FollowupNote>>> aPIResponse_FollowupNote = APIHelper.Get<IEnumerable<FollowupNote>>(Constants.API_DOCTOR_BASE_URL + API_FOLLOWUP_ENDOINT + followupNote.PATIENT_ID);
            ClinicalNotes clinicalNotes = new ClinicalNotes();
            clinicalNotes.followupNote = aPIResponse.Result.Response;
            clinicalNotes.followupNotes = aPIResponse_FollowupNote.Result.Response;
            return PartialView("FollowupNoteSummary", clinicalNotes);
        }
    }
}
