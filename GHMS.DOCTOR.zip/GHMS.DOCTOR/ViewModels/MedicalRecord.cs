﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GHMS.DOCTOR.MODEL.Models;

namespace GHMS.DOCTOR.ViewModels
{
    public class MedicalRecord
    {
        public Patient _PatientDetails { get; set; }
        public Assessment _InitialAssessment { get; set; }
        public ClinicalNotes _ClinicalNotes { get; set; }
    }

    public class ClinicalNotes
    {
        public FollowupNote followupNote { get; set; }
        public IEnumerable<FollowupNote> followupNotes { get; set; }
    }
}