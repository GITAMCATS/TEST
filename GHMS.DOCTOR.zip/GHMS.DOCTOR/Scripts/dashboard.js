$(function () {

    $(".s-y").hide();
    $(".moreInfo").hide();
    $(".reportdetail").hide();
    $(".reportdetail1").hide();
    $(".reportdetail2").hide();
    $(".tbl-note").hide();
    $(".btnDiagnostic").hide();
    $('#tbldiagnostics').hide();
    $(".btnMedicine").hide();
    $('#tblmedicines').hide();
    $(".patclose").click(function () {
        $(".s-x").hide();
        $(".s-y").fadeIn(100);
        $('#step-1').css('display', 'block');
        $('.Nursing_assesment').find('.stepwizard-step:first-child').find('.btn-circle:first-child').addClass('btn-success');
    });

    $(".viewmore").click(function () {
        $(".moreInfo").fadeToggle("fast");
    });
    $(".viewreport").click(function () {
        $(".reportdetail").fadeToggle("fast");
    });
    $(".viewreport1").click(function () {
        $(".reportdetail1").fadeToggle("fast");
    });
    $(".viewreport2").click(function () {
        $(".reportdetail2").fadeToggle("fast");
    });

    $(".btn-note").click(function () {
        $("#txt-note").val('');
        $(".tbl-note-hd").hide();
        $(".tbl-note").show("fast");
    });

    $("#wizard").steps({
        headerTag: "h2",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        transitionEffectSpeed: 500,
        labels: {
            finish: "Submit",
            next: "Forward",
            previous: "Backward"
        }
    });

    $('.wizard > .steps li a').click(function () {
        $(this).parent().addClass('checked');
        $(this).parent().prevAll().addClass('checked');
        $(this).parent().nextAll().removeClass('checked');
    });
    // Custome Jquery Step Button
    $('.forward').click(function () {
        $("#wizard").steps('next');
    })
    $('.backward').click(function () {
        $("#wizard").steps('previous');
    })
    // Select Dropdown
    $('html').click(function () {
        $('.select .dropdown').hide();
    });
    $('.select').click(function (event) {
        event.stopPropagation();
    });
    $('.select .select-control').click(function () {
        $(this).parent().next().toggle();
    })
    $('.select .dropdown li').click(function () {
        $(this).parent().toggle();
        var text = $(this).attr('rel');
        $(this).parent().prev().find('div').text(text);
    })

    $(".sel").change(function () {
        $(this).find("option:selected").each(function () {
            var optionValue = $(this).attr("value");
            if (optionValue) {
                $(".sbox").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else {
                $(".sbox").hide();
            }
        });
    }).change();

    //toggle the componenet with class accordion_body
    $(".accordion_head").click(function () {
        if ($('.accordion_body').is(':visible')) {
            $(".accordion_body").stop(true).slideUp(100);
            $(".plusminus").text('+').stop(true);
            $(".accordion_body").slideUp(100);
        }
        $(this).next(".accordion_body").toggle().stop(true);
        $(this).children(".plusminus").stop(true).text('-');
    });

    $("#srchDiagnostic").autocomplete({
        source: diagnosticTags,
        select: addDiagnostic,
    });

    function addDiagnostic(event, ui) {
        event.preventDefault();
        $('#tbldiagnostics').show();
        $(".btnDiagnostic").show();
        $(this).val('');
        $('.el2').append('<tr class="upload_docs"><th><label>' + ui.item.label + '</label></th><th><input class="form-control"></th><th><a class="removeb2"><i class="icon-trash ic2x"></i></a></tr>' + '');
    }

    $(document).on('click', '.removeb2', function (events) {
        $(this).parent().parent().remove();

        if ($('.el2').children('tr').length == 0) {
            $(".btnDiagnostic").hide();
            $('#tbldiagnostics').hide();
        }

    });

    $("#srchMedicines").autocomplete({
        source: medicineTags,
        select: addMedicine,
    });

    function addMedicine(event, ui) {
        event.preventDefault();
        $('#tblmedicines').show();
        $(".btnMedicine").show();
        $(this).val('');
        $('.el3').append('<tr class="upload_docs"><th><label>' + ui.item.label + '</label></th><th><input type="number" min="0" class="form-control"></th><th><a class="removeb3"><i class="icon-trash ic2x"></i></a></tr>' + '');
    }

    $(document).on('click', '.removeb3', function (events) {
        $(this).parent().parent().remove();

        if ($('.el3').children('tr').length == 0) {
            $(".btnMedicine").hide();
            $('#tblmedicines').hide();
        }

    });


});

$(".actionGroup").each(function (index) {
        var Group = $(this);
        var Tab = Group.find(".actionTab > label > input");
        var Panel = Group.find("> .actionPanel");
        function checkz(selector,reactor){
               selector.each(function() {
            var $this = $(this);
               if ($this.is(":checked")) {
                reactor.hide();
                reactor.filter("[data-id='" + $this.val() + "']").show();
            }
             });
        }
        checkz(selector=Tab,reactor=Panel);
        Tab.on("change",function() {
         checkz(selector=$(this),reactor=Panel);
        });
    });

function hFull(){
     var $mainh = $(".main").innerHeight() - 0;
    $(".h-full").css({"min-height":$mainh});
   }

$(window).on("load",function(){
    hFull();
});
$(window).on("resize",function(){

    hFull();

});

// HFULL Code


function sticky(){
       $(".sidebar .sidebar_menu").stick_in_parent({
        parent: ".main",
        offset_top: $(".navigation").height()
    }).on('sticky_kit:bottom', function(e) {
        $(this).parent().css('position', 'static');
    }).on('sticky_kit:unbottom', function(e) {
        $(this).parent().css('position', 'relative');
    }); 
        if ($(window).width() < 1000) {
        $(".sidebar").trigger("sticky_kit:detach");
    } else {
      
    }

}

sticky();

$(document).ready(function () {

    var navListItems = $('div.setup-panel div a'),
        allWells = $('.setup-content'),
        allNextBtn = $('.nextBtn');
        allPrevBtn = $('.prevBtn');

    allWells.hide();

    navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
            $item = $(this);

        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('btn-success').addClass('btn-default');
            $item.addClass('btn-success');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function () {
        var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for (var i = 0; i < curInputs.length; i++) {
            if (!curInputs[i].validity.valid) {
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid) nextStepWizard.removeAttr('disabled').trigger('click');
    });

    allPrevBtn.click(function () {
        var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for (var i = 0; i < curInputs.length; i++) {
            if (!curInputs[i].validity.valid) {
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid) nextStepWizard.removeAttr('disabled').trigger('click');
    });

    $('div.setup-panel div a.btn-success').trigger('click');
});



$('.addb1').on('click', function() {
    var order = $('input').closest('label').index() + 1;
    $('.el1').append('<tr class="upload_docs"><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><a class="removeb1"><i class="icon-trash ic2x"></i></a></tr>' +  '');

});

// $('.addb2').on('click', function() {
//     var order = $('input').closest('label').index() + 1;
//     $('.el2').append('<tr class="upload_docs"><th><label>Labaratory</label></th><th><label>Biochemistry</label></th><th><label>24 Hrs Urine</label></th><th><input class="form-control"></th><th><input class="form-control"></th><th><a class="removeb2"><i class="icon-trash ic2x"></i></a></tr>' +  '');

// });

// $('.addb3').on('click', function() {
//     var order = $('input').closest('label').index() + 1;
//     $('.el3').append('<tr class="upload_docs"><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><input class="form-control"></th><th><a class="removeb3"><i class="icon-trash ic2x"></i></a></tr>' +  '');

// });

$(document).on('click', '.removeb1', function(events) {
    $('.el1>.upload_docs:last').remove();

    
});

// $(document).on('click', '.removeb2', function(events) {
//     $('.el2>.upload_docs:last').remove();

    
// });

// $(document).on('click', '.removeb3', function(events) {
//     $('.el3>.upload_docs:last').remove();

    
// });