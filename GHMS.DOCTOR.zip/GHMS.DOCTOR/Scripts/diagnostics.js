var diagnosticTags =[
        {
            "type":"LB","value":1449,
            "label":"UNSTAINED SLIDES FOR OPINION(LESS THAN 5 SLIDES)"
        },
        {
            "type":"LB","value":1450,
            "label":"CD4/CD8 RATIOS"
        },
        {
            "type":"LB","value":1451,
            "label":"BONE MARROW ASPIRATION(BED SIDE)"
        },
        {
            "type":"LB","value":1452,
            "label":"BONE MARROW BIOPSY(BED SIDE-IP)"
        },
        {
            "type":"LB","value":1453,
            "label":"URINE BILE PIGMENT AND SALT"
        },
        {
            "type":"LB","value":1454,
            "label":"URINE UROBILINOGEN"
        },
        {
            "type":"LB","value":1455,
            "label":"L.E.CELL"
        },
        {
            "type":"LB","value":1456,
            "label":"FOETAL HAEMOGLOBIN (HB-F)"
        },
        {
            "type":"LB","value":1457,
            "label":"BONE MARROW SMEAR EXAMINATION(UNSTAINED SMEARS)"
        },
        {
            "type":"LB","value":1458,
            "label":"GLUCOSE PHOSPHATE DEHYDROGENASE(G6 PD)"
        },
        {
            "type":"LB","value":1459,
            "label":"BLOOD GAS ANALYSIS WITH ELECTROTYPES"
        },
        {
            "type":"LB","value":1460,
            "label":"VAGINAL CYTOLOGY FOR HORMONAL EVALUATION"
        },
        {
            "type":"LB","value":1461,
            "label":"IMMUNOHISTOCHEMISTRY -MARKER (AP)"
        },
        {
            "type":"LB","value":1462,
            "label":"BIOPSY - LARGE"
        },
        {
            "type":"LB","value":1463,
            "label":"GUIDED FNAC"
        },
        {
            "type":"LB","value":1464,
            "label":"HISTO PATHOLOGY (BIOPSY) - 2"
        },
        {
            "type":"LB","value":1465,
            "label":"IHC - 2 MARKERS"
        },
        {
            "type":"LB","value":1466,
            "label":"URINE FOR ALBUMIN"
        },
        {
            "type":"LB","value":1467,
            "label":"IMMUNO PHENO TYPING"
        },
        {
            "type":"LB","value":1468,
            "label":"URINE FOR HEMOGLOBIN"
        },
        {
            "type":"LB","value":1469,
            "label":"S-100"
        },
        {
            "type":"LB","value":1470,
            "label":"VIMENTIN"
        },
        {
            "type":"LB","value":1471,
            "label":"URINE FOR CYTOLOGY"
        },
        {
            "type":"LB","value":1472,
            "label":"HISTOPATHOLOGY(BIOPSY)- STAGING LAPAROTOMY OVARY"
        },
        {
            "type":"LB","value":1473,
            "label":"HISTOPATHOLOGY(BIOPSY)- BREAST"
        },
        {
            "type":"LB","value":1474,
            "label":"HISTOPATHOLOGY(BIOPSY)- THYROID AND RND"
        },
        {
            "type":"LB","value":1475,
            "label":"RT-PCR FOR PML - RARA-FISH(QUANTITATIVE)"
        },
        {
            "type":"LB","value":1476,
            "label":"HISTOPATHOLOGY - LB(COMPOSITE RESECTION)"
        },
        {
            "type":"LB","value":1477,
            "label":"RT-PCR FOR PML RARA(QUALITATIVE)"
        },
        {
            "type":"LB","value":1478,
            "label":"IHC - 4 MARKERS"
        },
        {
            "type":"LB","value":1479,
            "label":"ICD FLUID FOR CHYLE URINE"
        },
        {
            "type":"LB","value":1480,
            "label":"BRONCHIAL BRUSH + WASH"
        },
        {
            "type":"LB","value":1481,
            "label":"NIPPLE DISCHARGE"
        },
        {
            "type":"LB","value":1482,
            "label":"BRONCHIAL BRUSH"
        },
        {
            "type":"LB","value":1483,
            "label":"FLOW CYTOMETRY(ONE MARKER)"
        },
        {
            "type":"LB","value":1484,
            "label":"HISTOPATHOLOGY-LB - AMPUTATION"
        },
        {
            "type":"LB","value":1485,
            "label":"IHC-UNDIFFERENTIATED CARCINOMA PANEL"
        },
        {
            "type":"LB","value":1486,
            "label":"IHC-MYOEPI PANEL"
        },
        {
            "type":"LB","value":1487,
            "label":"IHC-NEWENDOCRINE PANEL"
        },
        {
            "type":"LB","value":1488,
            "label":"RT-PCR-PML/RARA (QUANTITATIVE) (GENE)"
        },
        {
            "type":"LB","value":1489,
            "label":"CYTOLOGY AND CELL COUNT (FLUID)"
        },
        {
            "type":"LB","value":1490,
            "label":"FISH HER-2-NEU"
        },
        {
            "type":"LB","value":1491,
            "label":"PML-RARA FISH"
        },
        {
            "type":"LB","value":1492,
            "label":"MLL FISH"
        },
        {
            "type":"LB","value":1493,
            "label":"BCR ABL BY FISH"
        },
        {
            "type":"LB","value":1494,
            "label":"FISH - 1 MARKER"
        },
        {
            "type":"LB","value":1495,
            "label":"FISH - EWS"
        },
        {
            "type":"LB","value":1496,
            "label":"IMMUNO PHENO TYPING-CLPD PANEL"
        },
        {
            "type":"LB","value":1497,
            "label":"CYTOGENTICS CONVENTIONAL"
        },
        {
            "type":"LB","value":1498,
            "label":"E2A ALL MARKER (GENE)"
        },
        {
            "type":"LB","value":1499,
            "label":"ALL PROGNOSTIC PANEL"
        },
        {
            "type":"LB","value":1500,
            "label":"TAL - 1(IP32) PCR EDTA (GENE LAB)"
        },
        {
            "type":"LB","value":1501,
            "label":"FISH TEL - AML - 1"
        },
        {
            "type":"LB","value":1502,
            "label":"RT PCR FOR BCR ABL (QUANTITATIVE) (GENE LAB)"
        },
        {
            "type":"LB","value":1503,
            "label":"IRMA(ONQ)"
        },
        {
            "type":"LB","value":1504,
            "label":"URINARY NMP 22"
        },
        {
            "type":"LB","value":1505,
            "label":"RT PCR FOR BCR ABL (QUALITATIVE) (GENE LAB)"
        },
        {
            "type":"LB","value":1506,
            "label":"FISH  MARKER FOR SOLID TUMOR(TMH)"
        },
        {
            "type":"LB","value":1507,
            "label":"JAK-2-(MUTATION)(GENELAB)"
        },
        {
            "type":"LB","value":1508,
            "label":"FISH FOR DEL 17 & 11Q(GENE)"
        },
        {
            "type":"LB","value":1509,
            "label":"TCELL(VMC VELLORE)"
        },
        {
            "type":"LB","value":1510,
            "label":"FISH IN SOLID TISSUES-1 MARKER"
        },
        {
            "type":"LB","value":1511,
            "label":"PROCESSING OF SURGICAL SPECIMEN FOR STORAGE"
        },
        {
            "type":"LB","value":1512,
            "label":"CD34 STEM CELL ANALYSIS"
        },
        {
            "type":"LB","value":1513,
            "label":"FISH 1P 9Q"
        },
        {
            "type":"LB","value":1514,
            "label":"TRANSLOCATION(14:18) FOLLICULAR LYMPHOMA(GENELAB)"
        },
        {
            "type":"LB","value":1515,
            "label":"HLA ABC TYPING(BASIC SEROLOGY)(SPECTRA)"
        },
        {
            "type":"LB","value":1516,
            "label":"SLIDE REVIEW WITH IHC ANCILLARY WORK-UP(TMH)"
        },
        {
            "type":"LB","value":1517,
            "label":"ER"
        },
        {
            "type":"LB","value":1518,
            "label":"PROCESSING CHARGES FOR OUTSOURCED EGFR"
        },
        {
            "type":"LB","value":1519,
            "label":"PNH PANEL(APOLLO)"
        },
        {
            "type":"LB","value":1520,
            "label":"HLA-TYPING (DNA-PCR(HLA A,B,DRB TYPING)(SPECTRA)"
        },
        {
            "type":"LB","value":1521,
            "label":"T-CELL+IHC+SLIDE REVIEW (CMC VELLORE)"
        },
        {
            "type":"LB","value":1522,
            "label":"EGFR MUTATION(CMC VELLORE)"
        },
        {
            "type":"LB","value":1523,
            "label":"PROCESSING CHARGES FOR FLUID(RESEARCH SAMPLE)"
        },
        {
            "type":"LB","value":1524,
            "label":"FLUID CYTOLOGY+CELL BLOCK"
        },
        {
            "type":"LB","value":1525,
            "label":"FISH FOR N-MYC AMPLICATION (TMH)"
        },
        {
            "type":"LB","value":1526,
            "label":"FISH FOR HER-2/NEU(OUTSIDE SAMPLE)"
        },
        {
            "type":"LB","value":1527,
            "label":"PROCESSING CHARGES FOR OUTSOURCING(CANCELLATION)"
        },
        {
            "type":"LB","value":1528,
            "label":"DISPOSABLE BONE BIOPSY NEEDLE"
        },
        {
            "type":"LB","value":1529,
            "label":"DISPOSABLE BONE ASPIRATION NEEDLE"
        },
        {
            "type":"LB","value":1530,
            "label":"HPV-DNA DETECTION(METROPOLIS)"
        },
        {
            "type":"LB","value":1531,
            "label":"FISH FOR EML 4 ALK"
        },
        {
            "type":"LB","value":1532,
            "label":"KRAS MUTATION ANALYSIS (AIG)"
        },
        {
            "type":"LB","value":1533,
            "label":"SLIDE REVIEW WITH IHC ANCILLARY WORK-UP(CMC VELLOR"
        },
        {
            "type":"LB","value":1534,
            "label":"FLOW CYTOMETRY 1 MARKER (APPOLO)"
        },
        {
            "type":"LB","value":1535,
            "label":"RT-PCR FOR SYT-SSX SECOND OPINION(TMH)"
        },
        {
            "type":"LB","value":1536,
            "label":"TRANSLOCATION(2;5) ALK TRANSLOCATION REARRANGEMENT"
        },
        {
            "type":"LB","value":1537,
            "label":"SECOND OPINION(TMH)"
        },
        {
            "type":"LB","value":1538,
            "label":"HEREDITAY CANCER PALE (94 GENES)(METGENOME)"
        },
        {
            "type":"LB","value":1539,
            "label":"SOMATIC MUTATION CANCER PANEL(26HOTSPOT)METGENOME"
        },
        {
            "type":"LB","value":1540,
            "label":"JAK 2 MUTATION DETECTION,QUALITATIVE PCR(LAL PATH)"
        },
        {
            "type":"LB","value":1541,
            "label":"FISH FOR 14Q 32.3 OR LSI IGH GENE BREAKAPART(LALPA"
        },
        {
            "type":"LB","value":1542,
            "label":"FISH FOR 17P(LAL PATH)"
        },
        {
            "type":"LB","value":1543,
            "label":"FISH 22 Q DELETION OR LSI DI GEORGE/VCFS(LALPATH)"
        },
        {
            "type":"LB","value":1544,
            "label":"FISH FOR AMINO 1 PROBE(TRISOMY21)(LAL PATH)"
        },
        {
            "type":"LB","value":1545,
            "label":"FISH FOR AMINO 3 PROBES(TRISOMY18,X,Y)(LAL PATH)"
        },
        {
            "type":"LB","value":1546,
            "label":"FISH FOR AMINO 2 PROBES(TRISOMY13;21)(LAL PATH)"
        },
        {
            "type":"LB","value":1547,
            "label":"FISH FOR BCR/ABL(LAL PATH)"
        },
        {
            "type":"LB","value":1548,
            "label":"FISH FOR BLADDER CANCER RECURRANCE(LAL PATH)"
        },
        {
            "type":"LB","value":1549,
            "label":"FISH FOR DEL 13Q OR LSI D 13S319(LAL PATH)"
        },
        {
            "type":"LB","value":1550,
            "label":"FISH FOR FANCONI'S ANEMIA(LAL PATH)"
        },
        {
            "type":"LB","value":1551,
            "label":"FISH FOR INV(16) OR LSI CBFB(LAL PATH)"
        },
        {
            "type":"LB","value":1552,
            "label":"FISH FOR MDS PANEL CHROMOSOMES 5,7,8&20Q(LAL PATH)"
        },
        {
            "type":"LB","value":1553,
            "label":"FISH FOR MULTIPLE MYELOME(5 PROBES)(LAL PATH)"
        },
        {
            "type":"LB","value":1554,
            "label":"FISH FOR ONCOLOGY 1P AND 19Q CODELETION(LAL PATH)"
        },
        {
            "type":"LB","value":1555,
            "label":"FISH FOR ONCOLOGY EGFR GENE AMPLIFICATION(LALPATH)"
        },
        {
            "type":"LB","value":1556,
            "label":"FISH FOR OPPOSITE SEX BMT(XX/XY)(LAL PATH)"
        },
        {
            "type":"LB","value":1557,
            "label":"FISH FOR T(11;14) OR LSI IGH/CCNDI(LAL PATH)"
        },
        {
            "type":"LB","value":1558,
            "label":"FLOW CYTOMETRY CD19 PAN B CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1559,
            "label":"FLOW CYTOMETRY CD 1A (LALPATH)"
        },
        {
            "type":"LB","value":1560,
            "label":"FLOW CYTOMETRY CD2 PAN T CELL MARKER (LALPATH)"
        },
        {
            "type":"LB","value":1561,
            "label":"FLOW CYTOMETRY CD20 PAN B CELL MARKER (LALPATH)"
        },
        {
            "type":"LB","value":1562,
            "label":"FLOW CYTOMETRY CD22 PAN B CELL MARKER (LALPATH)"
        },
        {
            "type":"LB","value":1563,
            "label":"FLOW CYTOMETRY CD23 CLL SEGREGATIONMARKER(LALPATH)"
        },
        {
            "type":"LB","value":1564,
            "label":"FLOW CYTOMETRY CD25 HAIRY CELL/NHL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1565,
            "label":"FLOW CYTOMETRY CD3 PAN T CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1566,
            "label":"FLOW CYTOMETRY CD33 MYELOID CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1567,
            "label":"FLOW CYTOMETRY CD34 PRECURSOR CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1568,
            "label":"FLOW CYTOMETRY CD38 PLASMA CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1569,
            "label":"FLOW CYTOMETRY CD42A MEGAKARYOCYTIC MARKER(LALPATH"
        },
        {
            "type":"LB","value":1570,
            "label":"FLOW CYTOMETRY CD45 LCA(LALPATH)"
        },
        {
            "type":"LB","value":1571,
            "label":"FLOW CYTOMETRY CD5 T CELL/B CELL SUBSET(LALPATH)"
        },
        {
            "type":"LB","value":1572,
            "label":"FLOW CYTOMETRY CD61 MEGAKARYOCYTIC CELL (LALPATH)"
        },
        {
            "type":"LB","value":1573,
            "label":"FLOW CYTOMETRY CD64 (LALPATH)"
        },
        {
            "type":"LB","value":1574,
            "label":"FLOW CYTOMETRY CD7 PAN T CELL MARKER (LALPATH)"
        },
        {
            "type":"LB","value":1575,
            "label":"FLOW CYTOMETRY CD79A B LYMPHOID MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1576,
            "label":"FLOW CYTOMETRY CD79B B LYMPHOID MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1577,
            "label":"FLOW CYTOMETRY TDT PRECURSOR CELL MARKER(LALPATH)"
        },
        {
            "type":"LB","value":1578,
            "label":"FLT3 GENE MUTATION(LAL PATH)"
        },
        {
            "type":"LB","value":1579,
            "label":"LEUKEMIA GENETIC PROFILE-ANY 6 MARKERS PCR(LALPATH"
        },
        {
            "type":"LB","value":1580,
            "label":"LEUKEMIA/LYMPHOMA DIAGNOSTIC PANEL(LALPATH)"
        },
        {
            "type":"LB","value":1581,
            "label":"MSI TESTING (METGENOME)"
        },
        {
            "type":"LB","value":1582,
            "label":"HAM'S TEST(LALPATH)"
        },
        {
            "type":"LB","value":1583,
            "label":"URINE OSMALITY(LALPATH)"
        },
        {
            "type":"LB","value":1584,
            "label":"HLA CROSS MATCH ABC CLASS I TYPING(LALPATH)"
        },
        {
            "type":"LB","value":1585,
            "label":"24 HRS URINARY CORTISOL(LALPATH)"
        },
        {
            "type":"LB","value":1586,
            "label":"HLA DR TYPING PCR(LALPATH)"
        },
        {
            "type":"LB","value":1587,
            "label":"KRAAS MUTATION(LALPATH)"
        },
        {
            "type":"LB","value":1588,
            "label":"INV 16 GENE REARANGEMENTS QUALITATIVE (LALPATH)"
        },
        {
            "type":"LB","value":1589,
            "label":"PLASMA G-6PD QUALITATIVE(METRO)"
        },
        {
            "type":"LB","value":1590,
            "label":"SECOND OPINION (APOLLO)"
        },
        {
            "type":"LB","value":1591,
            "label":"IHC-3 MARKERS"
        },
        {
            "type":"LB","value":1592,
            "label":"EBER-ISH-TATA(TMH)"
        },
        {
            "type":"LB","value":1593,
            "label":"MSI TESTING (IHC)(ONQUEST)"
        },
        {
            "type":"LB","value":1594,
            "label":"FLUID FOR BILE PIGMENT & SALT"
        },
        {
            "type":"LB","value":1595,
            "label":"IHC-MSI(MLH1,MSH2,MSH6,PMS2)"
        },
        {
            "type":"LB","value":1596,
            "label":"C KIT MUTATION(4 EXONS)(MEDGENOME)"
        },
        {
            "type":"LB","value":1597,
            "label":"PROCESSING CHARGE FOR CAMP SMEARS"
        },
        {
            "type":"LB","value":1598,
            "label":"IRMA-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1599,
            "label":"BRAF-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1600,
            "label":"PDGFRA-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1601,
            "label":"PTEN-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1602,
            "label":"KIT-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1603,
            "label":"RET ONCOGENE-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1604,
            "label":"APC(FAMILIAL ADENOMATOUS POLYPOSIS)-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1605,
            "label":"BRCA1-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1606,
            "label":"BRCA2-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1607,
            "label":"BRCA 1 & 2 TOGETHER-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1608,
            "label":"STK11(PEUTZ-JEGER'S SYNDROME)-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1609,
            "label":"VHL GENE-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1610,
            "label":"IDH1-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1611,
            "label":"TP53-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1612,
            "label":"PIK3CA-PCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1613,
            "label":"ROS1 GENE FUSION-RTPCR(MEDGENOME)"
        },
        {
            "type":"LB","value":1614,
            "label":"CD4 COUNT(LALPATH)"
        },
        {
            "type":"LB","value":1615,
            "label":"EBER-RISH(EBV)"
        },
        {
            "type":"LB","value":1616,
            "label":"RT-PCR FOR PML - RARA(QUANTITATIVE)"
        },
        {
            "type":"LB","value":1617,
            "label":"FISH FOR C-MYC(FFPE)"
        },
        {
            "type":"LB","value":1618,
            "label":"FISH FOR C-MYC(BLOOD/BONE MARROW)"
        },
        {
            "type":"LB","value":1619,
            "label":"IHC ALK (D5F3)"
        },
        {
            "type":"LB","value":1620,
            "label":"SLIDE REVIEW WITH IHC(TMH)"
        },
        {
            "type":"LB","value":1621,
            "label":"IHC - B CELL LYMPHOMA"
        },
        {
            "type":"LB","value":1622,
            "label":"IHC - T CELL LYMPHOMA"
        },
        {
            "type":"LB","value":1623,
            "label":"IHC - LYMPHOMA MINI"
        },
        {
            "type":"LB","value":1624,
            "label":"IHC - KAPPA AND LAMBDA"
        },
        {
            "type":"LB","value":1625,
            "label":"IHC-LYMPHOMA (COMPREHENSIVE) PANEL"
        },
        {
            "type":"LB","value":1626,
            "label":"IHC (5-8) MARKERS"
        },
        {
            "type":"LB","value":1627,
            "label":"AML COMPREHENSIVE PROGNOSTIC PANEL(FISH)"
        },
        {
            "type":"LB","value":1628,
            "label":"AML MINI(FISH) PANEL"
        },
        {
            "type":"LB","value":1629,
            "label":"CLL COMPREHENSIVE PANEL(FISH)"
        },
        {
            "type":"LB","value":1630,
            "label":"MULTIPLE MYELOMA COMPREHENSIVE PANEL"
        },
        {
            "type":"LB","value":1631,
            "label":"FLT3 (PCR)(ONQUEST)"
        },
        {
            "type":"LB","value":1632,
            "label":"FLT3,NPM1(PCR)(ONQUEST)"
        },
        {
            "type":"LB","value":1633,
            "label":"FLT3,NPM1,CEBPA(PCR)(ONQUEST)"
        },
        {
            "type":"LB","value":1634,
            "label":"MRD (PANEL)(ONQUEST)"
        },
        {
            "type":"LB","value":1635,
            "label":"BRUSH SMEAR"
        },
        {
            "type":"LB","value":1636,
            "label":"UNSTAINED SLIDES FOR OPINION(MORE THAN 5 SLIDES)"
        },
        {
            "type":"LB","value":1637,
            "label":"FISH FOR 1P19Q DELETION(LALPATH)"
        },
        {
            "type":"LB","value":1638,
            "label":"IHC MDM2"
        },
        {
            "type":"LB","value":1639,
            "label":"IHC P16"
        },
        {
            "type":"LB","value":1640,
            "label":"IHC INI1"
        },
        {
            "type":"LB","value":1641,
            "label":"IHC ERG"
        },
        {
            "type":"LB","value":1642,
            "label":"IHC HER2 NEU"
        },
        {
            "type":"LB","value":1643,
            "label":"IHC TLE1"
        },
        {
            "type":"LB","value":1644,
            "label":"IHC TFE3"
        },
        {
            "type":"LB","value":1645,
            "label":"BTA STAT (URINE)"
        },
        {
            "type":"LB","value":1646,
            "label":"BCR-ABL PCR(QUALITATIVE)"
        },
        {
            "type":"LB","value":1647,
            "label":"IHC ALK1"
        },
        {
            "type":"LB","value":1648,
            "label":"IHC BCL2"
        },
        {
            "type":"LB","value":1649,
            "label":"IHC BCL6"
        },
        {
            "type":"LB","value":1650,
            "label":"IHC BETA HCG"
        },
        {
            "type":"LB","value":1651,
            "label":"IHC CALCITONIN"
        },
        {
            "type":"LB","value":1652,
            "label":"IHC CALDESMON"
        },
        {
            "type":"LB","value":1653,
            "label":"IHC CALPONIN"
        },
        {
            "type":"LB","value":1654,
            "label":"IHC CD68"
        },
        {
            "type":"LB","value":1655,
            "label":"IHC CD10"
        },
        {
            "type":"LB","value":1656,
            "label":"IHC CD138"
        },
        {
            "type":"LB","value":1657,
            "label":"IHC CD15"
        },
        {
            "type":"LB","value":1658,
            "label":"IHC CD20"
        },
        {
            "type":"LB","value":1659,
            "label":"IHC CD21"
        },
        {
            "type":"LB","value":1660,
            "label":"IHC CD23"
        },
        {
            "type":"LB","value":1661,
            "label":"IHC CD30"
        },
        {
            "type":"LB","value":1662,
            "label":"IHC CD31"
        },
        {
            "type":"LB","value":1663,
            "label":"IHC CD4"
        },
        {
            "type":"LB","value":1664,
            "label":"IHC CD34"
        },
        {
            "type":"LB","value":1665,
            "label":"IHC CD3"
        },
        {
            "type":"LB","value":1666,
            "label":"IHC CD56"
        },
        {
            "type":"LB","value":1667,
            "label":"IHC CD5"
        },
        {
            "type":"LB","value":1668,
            "label":"IHC CD79 A"
        },
        {
            "type":"LB","value":1669,
            "label":"IHC CD8"
        },
        {
            "type":"LB","value":1670,
            "label":"IHC CD99"
        },
        {
            "type":"LB","value":1671,
            "label":"IHC CDII7"
        },
        {
            "type":"LB","value":1672,
            "label":"IHC CDX2"
        },
        {
            "type":"LB","value":1673,
            "label":"IHC CEA"
        },
        {
            "type":"LB","value":1674,
            "label":"IHC CHROMOGRANIN"
        },
        {
            "type":"LB","value":1675,
            "label":"IHC CK14"
        },
        {
            "type":"LB","value":1676,
            "label":"IHC CK19"
        },
        {
            "type":"LB","value":1677,
            "label":"IHC CK20"
        },
        {
            "type":"LB","value":1678,
            "label":"IHC CK5"
        },
        {
            "type":"LB","value":1679,
            "label":"IHC CK7"
        },
        {
            "type":"LB","value":1680,
            "label":"IHC CYCLIN D1"
        },
        {
            "type":"LB","value":1681,
            "label":"IHC DESMIN"
        },
        {
            "type":"LB","value":1682,
            "label":"IHC DOG1"
        },
        {
            "type":"LB","value":1683,
            "label":"IHC E CADHERIN"
        },
        {
            "type":"LB","value":1684,
            "label":"IHC EMA"
        },
        {
            "type":"LB","value":1685,
            "label":"IHC ER"
        },
        {
            "type":"LB","value":1686,
            "label":"IHC ERG1"
        },
        {
            "type":"LB","value":1687,
            "label":"IHC GALECTIN3"
        },
        {
            "type":"LB","value":1688,
            "label":"IHC GCDFP 15"
        },
        {
            "type":"LB","value":1689,
            "label":"IHC GLYPICAN3"
        },
        {
            "type":"LB","value":1690,
            "label":"IHC HMB 45"
        },
        {
            "type":"LB","value":1691,
            "label":"IHC INHIBIN"
        },
        {
            "type":"LB","value":1692,
            "label":"IHC KI67"
        },
        {
            "type":"LB","value":1693,
            "label":"IHC LAMBDA"
        },
        {
            "type":"LB","value":1694,
            "label":"IHC LCA"
        },
        {
            "type":"LB","value":1695,
            "label":"IHC MLH1"
        },
        {
            "type":"LB","value":1696,
            "label":"IHC MPO"
        },
        {
            "type":"LB","value":1697,
            "label":"IHC MSH2"
        },
        {
            "type":"LB","value":1698,
            "label":"IHC MSH6"
        },
        {
            "type":"LB","value":1699,
            "label":"IHC MUM1"
        },
        {
            "type":"LB","value":1700,
            "label":"IHC MYOGENIN"
        },
        {
            "type":"LB","value":1701,
            "label":"IHC NAPSIN A"
        },
        {
            "type":"LB","value":1702,
            "label":"IHC P53"
        },
        {
            "type":"LB","value":1703,
            "label":"IHC P63"
        },
        {
            "type":"LB","value":1704,
            "label":"IHC PAX5"
        },
        {
            "type":"LB","value":1705,
            "label":"IHC PLAP"
        },
        {
            "type":"LB","value":1706,
            "label":"IHC PMS2"
        },
        {
            "type":"LB","value":1707,
            "label":"IHC PR"
        },
        {
            "type":"LB","value":1708,
            "label":"IHC S 100"
        },
        {
            "type":"LB","value":1709,
            "label":"IHC SALL 4"
        },
        {
            "type":"LB","value":1710,
            "label":"IHC SMA"
        },
        {
            "type":"LB","value":1711,
            "label":"IHC SMOOTHELIN"
        },
        {
            "type":"LB","value":1712,
            "label":"IHC SYNAPTOPHYSIN"
        },
        {
            "type":"LB","value":1713,
            "label":"IHC TDT"
        },
        {
            "type":"LB","value":1714,
            "label":"IHC THYROGLOBULIN"
        },
        {
            "type":"LB","value":1715,
            "label":"IHC TTF1"
        },
        {
            "type":"LB","value":1716,
            "label":"IHC WT1"
        },
        {
            "type":"LB","value":1717,
            "label":"IHC FLI1"
        },
        {
            "type":"LB","value":1718,
            "label":"IHC GFAP"
        },
        {
            "type":"LB","value":1719,
            "label":"RET ONCOGENE(EXON - 10 11)(MEDGENOME)"
        },
        {
            "type":"LB","value":1720,
            "label":"BRCA REFLEX PANEL(CORE DIAGNOSTICS)"
        },
        {
            "type":"LB","value":1721,
            "label":"BRCA MINI PANEL(CORE DIAGNOSTICS)"
        },
        {
            "type":"LB","value":1722,
            "label":"BRAF MUTATION V600(GENE)"
        },
        {
            "type":"LB","value":1723,
            "label":"N-RAS(CORE)"
        },
        {
            "type":"LB","value":1724,
            "label":"FROZEN(OUTSIDE)"
        },
        {
            "type":"LB","value":1725,
            "label":"FROZEN MARGINS(OUTSIDE)"
        },
        {
            "type":"LB","value":1726,
            "label":"K RAS MUTATION"
        },
        {
            "type":"LB","value":1727,
            "label":"BCR-ABL PCR(QUANTITATIVE)"
        },
        {
            "type":"LB","value":1001,
            "label":"24 HRS URINE VMA(METRO)"
        },
        {
            "type":"LB","value":1002,
            "label":"PLASMA CHROMOGRANIN-A(METRO)"
        },
        {
            "type":"LB","value":1003,
            "label":"SERUM LITHIUM(METRO)"
        },
        {
            "type":"LB","value":1004,
            "label":"ANTITHYROID ANTIBODIES (TPO AND ATA)(METRO)"
        },
        {
            "type":"LB","value":1005,
            "label":"ANTI THYROID PEROXIDASE ANTIBODIES(ANTI TPO) (MET)"
        },
        {
            "type":"LB","value":1006,
            "label":"VASOPRESSIN(ADH)(METRO)"
        },
        {
            "type":"LB","value":1007,
            "label":"SERUM GROWTH HORMONE(METRO POLIS)"
        },
        {
            "type":"LB","value":1008,
            "label":"PLEURAL FLUID FOR TRIGLYCERIDES"
        },
        {
            "type":"LB","value":1009,
            "label":"RANDOM URINE METANEPHRINS(LALPATH)"
        },
        {
            "type":"LB","value":1010,
            "label":"PLASMA CATECHOLMINS(LALPATH)"
        },
        {
            "type":"LB","value":1011,
            "label":"24 HRS URINE 17 HYDROXY CORTICOSTERIODS(LALPATH)"
        },
        {
            "type":"LB","value":1012,
            "label":"SERUM 17 HYDROXY PREGESTRONE(LALPATH)"
        },
        {
            "type":"LB","value":1013,
            "label":"SERUM TESTOSTRONE(LALPATH)"
        },
        {
            "type":"LB","value":1014,
            "label":"24 HRS URINARY HIAA(LALPATH)"
        },
        {
            "type":"LB","value":1015,
            "label":"SERUM ACE LEVELS(LALPATH)"
        },
        {
            "type":"LB","value":1016,
            "label":"SERUM ACIDS PHOSPATASE TOTAL & PROSTATIC(LALPATH)"
        },
        {
            "type":"LB","value":1017,
            "label":"PLASMA ADRENALINE(LALPATH)"
        },
        {
            "type":"LB","value":1018,
            "label":"ACTH PLASMA(LALPATH)"
        },
        {
            "type":"LB","value":1019,
            "label":"SERUM ALDOSTERONE(LALPATH)"
        },
        {
            "type":"LB","value":1020,
            "label":"SERUM THYROGLOBULIN(LALPATH)"
        },
        {
            "type":"LB","value":1021,
            "label":"SERUM CA 72-4(LALPATH)"
        },
        {
            "type":"LB","value":1022,
            "label":"SERUM  CALCITONIN(LALPATH)"
        },
        {
            "type":"LB","value":1023,
            "label":"CALCULUS(SRONE ANALYSIS GALL BLADDER)(LALPATH)"
        },
        {
            "type":"LB","value":1024,
            "label":"CALCULUS(SRONE ANALYSIS URINARY STONE)(LALPATH)"
        },
        {
            "type":"LB","value":1025,
            "label":"URINE CATECHOLAMINES(LALPATH)"
        },
        {
            "type":"LB","value":1026,
            "label":"SERUM CERULOPLASIMIN(LALPATH)"
        },
        {
            "type":"LB","value":1027,
            "label":"PLASMA CHROMOGRANIN(LALPATH)"
        },
        {
            "type":"LB","value":1028,
            "label":"SERUM CK-MM(LALPATH)"
        },
        {
            "type":"LB","value":1029,
            "label":"SERUM COPPER BY ATOMIC ABSOROPTION(LALPATH)"
        },
        {
            "type":"LB","value":1030,
            "label":"SERUM CORTISOL(LALPATH)"
        },
        {
            "type":"LB","value":1031,
            "label":"SERUM C PEPTIDE(LALPATH)"
        },
        {
            "type":"LB","value":1032,
            "label":"SERUM CPK TOTAL(LALPATH)"
        },
        {
            "type":"LB","value":1033,
            "label":"CYCLOSPORIN BLOOD(LALPATH)"
        },
        {
            "type":"LB","value":1034,
            "label":"SERUM CYSTANIN C(LALPATH)"
        },
        {
            "type":"LB","value":1035,
            "label":"SERUM ERYTHROPOIETIN(EPO)(LALPATH)"
        },
        {
            "type":"LB","value":1036,
            "label":"SERUM FERITIN(LALPATH)"
        },
        {
            "type":"LB","value":1037,
            "label":"SERUM FOLIC ACID(LALPATH)"
        },
        {
            "type":"LB","value":1038,
            "label":"SERUM FREE T3(LALPATH)"
        },
        {
            "type":"LB","value":1039,
            "label":"SERUM FREE T4(LALPATH)"
        },
        {
            "type":"LB","value":1040,
            "label":"SERUM FREE TESTOSTEREONE(LALPATH)"
        },
        {
            "type":"LB","value":1041,
            "label":"SERUM GASTRIN(LALPATH)"
        },
        {
            "type":"LB","value":1042,
            "label":"SERUM HAPTOGLOBIN(LALPATH)"
        },
        {
            "type":"LB","value":1043,
            "label":"SERUM HOMOCYSTEINE(LALPATH)"
        },
        {
            "type":"LB","value":1044,
            "label":"SERUM  INHIBIN A(LALPATH)"
        },
        {
            "type":"LB","value":1045,
            "label":"SERUM  INHIBIN B(LALPATH)"
        },
        {
            "type":"LB","value":1046,
            "label":"SERUM INSULIN FASTING(LALPATH)"
        },
        {
            "type":"LB","value":1047,
            "label":"SERUM PARATHYROID HARMONE(INTACT PTH)(LALPATH)"
        },
        {
            "type":"LB","value":1048,
            "label":"24 HRS URINE KAPPA LIGHT CHAIN(LALPATH)"
        },
        {
            "type":"LB","value":1049,
            "label":"SERUM LH(LALPATH)"
        },
        {
            "type":"LB","value":1050,
            "label":"SERUM LIPASE(LALPATH)"
        },
        {
            "type":"LB","value":1051,
            "label":"24 HRS URINE METANEPHRINS(LALPATH)"
        },
        {
            "type":"LB","value":1052,
            "label":"24 HRS URINE MICROALBUMIN(LALPATH)"
        },
        {
            "type":"LB","value":1053,
            "label":"MICRO ALBUMIN URINE(SPOT) (LALPATH)"
        },
        {
            "type":"LB","value":1054,
            "label":"SERUM NT PRO BNP(LALPATH)"
        },
        {
            "type":"LB","value":1055,
            "label":"SERUM ESTRADIOL(E2)(LALPATH)"
        },
        {
            "type":"LB","value":1056,
            "label":"SERUM OESTRIOL(E3)(LALPATH)"
        },
        {
            "type":"LB","value":1057,
            "label":"SERUM PHENYTOIN(LALPATH)"
        },
        {
            "type":"LB","value":1058,
            "label":"PLASMA RENIN-DIRECT(LALPATH)"
        },
        {
            "type":"LB","value":1059,
            "label":"SERUM PROLACTIN(LALPATH)"
        },
        {
            "type":"LB","value":1060,
            "label":"24 HRS URINE ELECTROPHERESIS(LALPATH)"
        },
        {
            "type":"LB","value":1061,
            "label":"SERUM TIBC-DIRECT(IRON STUDIES)(LALPATH)"
        },
        {
            "type":"LB","value":1062,
            "label":"SERUM TRANSFERRIN(LALPATH)"
        },
        {
            "type":"LB","value":1063,
            "label":"24 HRS URINE VMA(LALPATH)"
        },
        {
            "type":"LB","value":1064,
            "label":"FDP(FIBRINOGEN DEGRADATION PRODUCTS)(LALPATH)"
        },
        {
            "type":"LB","value":1065,
            "label":"HB ELECTROPHORESIS(LALPATH)"
        },
        {
            "type":"LB","value":1066,
            "label":"URINE IMMUNOFIXATION QUANTITATIVE(METRO)"
        },
        {
            "type":"LB","value":1067,
            "label":"URINARY FREELIGHT CHAINS(METRO)"
        },
        {
            "type":"LB","value":1068,
            "label":"SERUM METHOTREXATE (SPECTRA)"
        },
        {
            "type":"LB","value":1069,
            "label":"CA 27.29';(LAL PATH)"
        },
        {
            "type":"LB","value":1070,
            "label":"ARYL SULPHATASE A(LALPATH)"
        },
        {
            "type":"LB","value":1071,
            "label":"TPMT ENZYME ACTIVITY(METRO)"
        },
        {
            "type":"LB","value":1072,
            "label":"ALFA-1 ANTITRYPSIN(QUANTITATIVE)(LALPATH)"
        },
        {
            "type":"LB","value":1073,
            "label":"24 HOURS URINE CALCIUM(METROPOLIS)"
        },
        {
            "type":"LB","value":1074,
            "label":"SERUM CPK(SPECT)"
        },
        {
            "type":"LB","value":1075,
            "label":"PLASMA-FREE METANEPHRINES(METRO)"
        },
        {
            "type":"LB","value":1076,
            "label":"24HRS URINE HOMOVANILLIC ACID(HVA)(LALPATH)"
        },
        {
            "type":"LB","value":1077,
            "label":"ANTI THYROGLOBULIN ANTIBODY(ATG)"
        },
        {
            "type":"LB","value":1078,
            "label":"VITAMIN B-12"
        },
        {
            "type":"LB","value":1079,
            "label":"INSULIN LIKE GROWTH FACTOR(IGF-I) (METRO)"
        },
        {
            "type":"LB","value":1080,
            "label":"SERUM FREE LIGHT CHAINS(METRO)"
        },
        {
            "type":"LB","value":1081,
            "label":"FSH & LH(LALPATH)"
        },
        {
            "type":"LB","value":1082,
            "label":"FIBRINOGEN(SPECT)"
        },
        {
            "type":"LB","value":1083,
            "label":"SERUM ADA"
        },
        {
            "type":"LB","value":1084,
            "label":"ANTI MULLERIAN HORMONE(LALPATH)"
        },
        {
            "type":"LB","value":1085,
            "label":"SERUM INHIBIN (REPRODUCTIVE MARKER) A(LALPATH)"
        },
        {
            "type":"LB","value":1086,
            "label":"AEROBIC CULTURES"
        },
        {
            "type":"LB","value":1087,
            "label":"AFB CULTURE"
        },
        {
            "type":"LB","value":1088,
            "label":"AFB STAINING"
        },
        {
            "type":"LB","value":1089,
            "label":"BLOOD CULTURE"
        },
        {
            "type":"LB","value":1090,
            "label":"CATHERTER TIPS FOR C/S"
        },
        {
            "type":"LB","value":1091,
            "label":"CD4 CD8 & VIRAL LOAD"
        },
        {
            "type":"LB","value":1092,
            "label":"DENGUE IGG"
        },
        {
            "type":"LB","value":1093,
            "label":"FLUID FOR FUNGAL CULTURE & SENSIVITY"
        },
        {
            "type":"LB","value":1094,
            "label":"FUNGAL CULTURE"
        },
        {
            "type":"LB","value":1095,
            "label":"FUNGAL ELEMENTS"
        },
        {
            "type":"LB","value":1096,
            "label":"FUNGAL STAINS"
        },
        {
            "type":"LB","value":1097,
            "label":"GRAM STAINING"
        },
        {
            "type":"LB","value":1098,
            "label":"HBE ANTIGEN"
        },
        {
            "type":"LB","value":1099,
            "label":"HLA-B27Y"
        },
        {
            "type":"LB","value":1100,
            "label":"IGE"
        },
        {
            "type":"LB","value":1101,
            "label":"MANTOUX"
        },
        {
            "type":"LB","value":1102,
            "label":"MYCO BACTERIAL CULTURE"
        },
        {
            "type":"LB","value":1103,
            "label":"PUS CULTURE"
        },
        {
            "type":"LB","value":1104,
            "label":"R.A.FACTOR"
        },
        {
            "type":"LB","value":1105,
            "label":"SERUM A.S.O.TITRE"
        },
        {
            "type":"LB","value":1106,
            "label":"SLE CAPSULE"
        },
        {
            "type":"LB","value":1107,
            "label":"SPUTUM CULTURE"
        },
        {
            "type":"LB","value":1108,
            "label":"STOOL CULTURE"
        },
        {
            "type":"LB","value":1109,
            "label":"SWAB CULTURE"
        },
        {
            "type":"LB","value":1110,
            "label":"URINE CULTURE"
        },
        {
            "type":"LB","value":1111,
            "label":"VCA-IGG"
        },
        {
            "type":"LB","value":1112,
            "label":"VCA-IGM"
        },
        {
            "type":"LB","value":1113,
            "label":"PREGNANCY TEST"
        },
        {
            "type":"LB","value":1114,
            "label":"HBEAG (VIMTA)"
        },
        {
            "type":"LB","value":1115,
            "label":"HBSAG (ELISA)"
        },
        {
            "type":"LB","value":1116,
            "label":"HBSAG (SPOT)"
        },
        {
            "type":"LB","value":1117,
            "label":"HCV(ELISA)"
        },
        {
            "type":"LB","value":1118,
            "label":"HCV(SPOT)"
        },
        {
            "type":"LB","value":1119,
            "label":"HEPATITIS A VIRUS IGM (HAV)"
        },
        {
            "type":"LB","value":1120,
            "label":"HIV 1 & 2 (ELISA)"
        },
        {
            "type":"LB","value":1121,
            "label":"HIV 1 & 2(SPOT)"
        },
        {
            "type":"LB","value":1122,
            "label":"HIV ( WESTERN BLOT)"
        },
        {
            "type":"LB","value":1123,
            "label":"HLA B27"
        },
        {
            "type":"LB","value":1124,
            "label":"VIRAL SCREENING"
        },
        {
            "type":"LB","value":1125,
            "label":"CRP"
        },
        {
            "type":"LB","value":1126,
            "label":"FLUID FOR CULTURE"
        },
        {
            "type":"LB","value":1127,
            "label":"ANTI MILO CHONDRIAL ABS"
        },
        {
            "type":"LB","value":1128,
            "label":"ANTI HCV"
        },
        {
            "type":"LB","value":1129,
            "label":"AMOEBIC SEROLOGY"
        },
        {
            "type":"LB","value":1130,
            "label":"DENGUE IGG IGM"
        },
        {
            "type":"LB","value":1131,
            "label":"HTLV - I (RBX)"
        },
        {
            "type":"LB","value":1132,
            "label":"FUNGAL CULTURE AND SENSITVITY"
        },
        {
            "type":"LB","value":1134,
            "label":"ANTI HBE ELISA (VIMTA)"
        },
        {
            "type":"LB","value":1135,
            "label":"SERUM PROCALCITONIN"
        },
        {
            "type":"LB","value":1136,
            "label":"ANTI HBC - IGM  (VIMTA)"
        },
        {
            "type":"LB","value":1137,
            "label":"TB PCR FROM PARAFFIN BLOCK(RBX)"
        },
        {
            "type":"LB","value":1138,
            "label":"DENGUE DUO RAPID TEST"
        },
        {
            "type":"LB","value":1139,
            "label":"RAPID TEST FOR CHIKUNGUNYA VIRUS"
        },
        {
            "type":"LB","value":1140,
            "label":"POST FUMIGATION SWABS"
        },
        {
            "type":"LB","value":1141,
            "label":"ANA"
        },
        {
            "type":"LB","value":1142,
            "label":"RAPID H.PYLORI TEST"
        },
        {
            "type":"LB","value":1143,
            "label":"QC FOR BLOOD CULTURE"
        },
        {
            "type":"LB","value":1144,
            "label":"QC FOR SWAB CULTURE"
        },
        {
            "type":"LB","value":1145,
            "label":"HERPES SIMPLEX VIRUS II (HSV)-IGG(THYRO)"
        },
        {
            "type":"LB","value":1146,
            "label":"SERUM GALACTOMANNAN ASSAY(NIMS)"
        },
        {
            "type":"LB","value":1147,
            "label":"QUALITATIVE PCR FOR EPSTEIN BARR VIRUS(METROPOLIS"
        },
        {
            "type":"LB","value":1148,
            "label":"CSF/SERUM TBPCR (METROPOLIS)"
        },
        {
            "type":"LB","value":1149,
            "label":"CMV IGM"
        },
        {
            "type":"LB","value":1150,
            "label":"CMV IGG"
        },
        {
            "type":"LB","value":1151,
            "label":"ACE-ANGIOTENSIN CONVERTING ENZYME(METRO)"
        },
        {
            "type":"LB","value":1152,
            "label":"ADENO-V IGM(METRO)"
        },
        {
            "type":"LB","value":1153,
            "label":"AFB CULTURE & SENSIVITY-10 DRUGS(METRO)"
        },
        {
            "type":"LB","value":1154,
            "label":"AFB CULTURE(METRO)"
        },
        {
            "type":"LB","value":1155,
            "label":"AFB CULTURE BY RADIOMETRIC METHOD(METRO)"
        },
        {
            "type":"LB","value":1156,
            "label":"AMEBIC SEROLOGY(METRO)"
        },
        {
            "type":"LB","value":1157,
            "label":"ANA BY IFA(METRO)"
        },
        {
            "type":"LB","value":1158,
            "label":"ANAEROBIC CULTURE(METRO)"
        },
        {
            "type":"LB","value":1159,
            "label":"ANA-TITRES(METRO) BY ELISA"
        },
        {
            "type":"LB","value":1160,
            "label":"ANTI DS DNA(METRO)"
        },
        {
            "type":"LB","value":1161,
            "label":"ANTI HBC-IGM(METRO)"
        },
        {
            "type":"LB","value":1162,
            "label":"ANTI HBE ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1163,
            "label":"ANTI MITOCHONDIVIAL ANTIBODIES(AMA)(METRO)"
        },
        {
            "type":"LB","value":1164,
            "label":"ANTI PHOSPHOLIPID ANTIBODY-IGG(METRO)"
        },
        {
            "type":"LB","value":1165,
            "label":"ANTI SMOOTH MUSCLE ANTIBODIES(ASMA)(METRO)"
        },
        {
            "type":"LB","value":1166,
            "label":"ANTI DS DNA LEVELS(METRO)"
        },
        {
            "type":"LB","value":1167,
            "label":"ANTIPERIETAL ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1168,
            "label":"BRUCELLA IGG(ELISA)(METRO)"
        },
        {
            "type":"LB","value":1169,
            "label":"BRUCELLA IGM(ELISA)(METRO)"
        },
        {
            "type":"LB","value":1170,
            "label":"C-ANCA(METRO)"
        },
        {
            "type":"LB","value":1171,
            "label":"CHLAMYDIA TRACHOMATIS IGG (METRO)"
        },
        {
            "type":"LB","value":1172,
            "label":"CHLAMYDIA TRACHOMATIS IGM (METRO)"
        },
        {
            "type":"LB","value":1173,
            "label":"CMV IGG(METRO)"
        },
        {
            "type":"LB","value":1174,
            "label":"CMV IGM(METRO)"
        },
        {
            "type":"LB","value":1175,
            "label":"CMV PCR QUANTITATIVE(METRO)"
        },
        {
            "type":"LB","value":1176,
            "label":"CRYPTOCOCCAL ANTIGEN(METRO)"
        },
        {
            "type":"LB","value":1177,
            "label":"CYSTICERCOSIS(METRO)IgG ANTIBODY"
        },
        {
            "type":"LB","value":1178,
            "label":"DENGUE IGM(METRO)"
        },
        {
            "type":"LB","value":1179,
            "label":"DENGUE (METRO)"
        },
        {
            "type":"LB","value":1180,
            "label":"EBV(IFA)(METRO)"
        },
        {
            "type":"LB","value":1181,
            "label":"EBV IGG & IGM(METRO)"
        },
        {
            "type":"LB","value":1182,
            "label":"ECHINOCOCCUS IGG(METRO)"
        },
        {
            "type":"LB","value":1183,
            "label":"ENTEROVIRUS PCR(METRO)"
        },
        {
            "type":"LB","value":1184,
            "label":"ENTEROVIRUS SEROLOGY(METRO)"
        },
        {
            "type":"LB","value":1185,
            "label":"FILARIAL ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1186,
            "label":"DENGUE IGG(METRO)"
        },
        {
            "type":"LB","value":1187,
            "label":"HANTA VIRUS-IGM(METRO)"
        },
        {
            "type":"LB","value":1188,
            "label":"HBEAG(METRO)"
        },
        {
            "type":"LB","value":1189,
            "label":"HBV DNA QUANTITATIVE VIRAL LOAD(METRO)"
        },
        {
            "type":"LB","value":1190,
            "label":"HCV GENOTYPING(METRO)"
        },
        {
            "type":"LB","value":1191,
            "label":"HCV-RNA PCR QUANTITATIVE(METRO)"
        },
        {
            "type":"LB","value":1192,
            "label":"HIV II VIRAL LOAD(METRO)"
        },
        {
            "type":"LB","value":1193,
            "label":"HIV-1 VIRAL LOAD(METRO)"
        },
        {
            "type":"LB","value":1194,
            "label":"HLA-B27Y(METRO) (FLOW CYTOMETRY)"
        },
        {
            "type":"LB","value":1195,
            "label":"HSV 1& 2 IGG & IGM(METRO)"
        },
        {
            "type":"LB","value":1196,
            "label":"HSV PCR(METRO)"
        },
        {
            "type":"LB","value":1197,
            "label":"HTLV I & II ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1198,
            "label":"HYDATID SEROLOGY(METRO)"
        },
        {
            "type":"LB","value":1199,
            "label":"IGE TOTAL(METRO)"
        },
        {
            "type":"LB","value":1200,
            "label":"LEPTOSPIRA IGG(METRO)"
        },
        {
            "type":"LB","value":1201,
            "label":"LEPTOSPIRA IGM(METRO)"
        },
        {
            "type":"LB","value":1202,
            "label":"LUPUS ANTICOGULANT(METRO)"
        },
        {
            "type":"LB","value":1203,
            "label":"MYCOBACTERIAL CULTURE&SENSITIVITY FOR 5 DRUGS(METR"
        },
        {
            "type":"LB","value":1204,
            "label":"MYCOPLASMA SEROLOGY(METRO)"
        },
        {
            "type":"LB","value":1205,
            "label":"P-ANCA(METRO)"
        },
        {
            "type":"LB","value":1206,
            "label":"PARVO VIRUS IGG(METRO)"
        },
        {
            "type":"LB","value":1207,
            "label":"PARVO VIRUS IGM(METRO)"
        },
        {
            "type":"LB","value":1208,
            "label":"QUANTIFERON TB TEST(METRO)"
        },
        {
            "type":"LB","value":1209,
            "label":"R.A FACTOR IGA TITRE(METRO)"
        },
        {
            "type":"LB","value":1210,
            "label":"RSV(RESPIRATORY SYNCITIAL VIRUS)-IGM(METRO)"
        },
        {
            "type":"LB","value":1211,
            "label":"RUBELLA IGG(METRO)"
        },
        {
            "type":"LB","value":1212,
            "label":"RUBELLA IGM(METRO)"
        },
        {
            "type":"LB","value":1213,
            "label":"SERUM CERULOPLASMIN(METRO)"
        },
        {
            "type":"LB","value":1214,
            "label":"SERUM GALACTOMANNAN ASSAY(METRO)"
        },
        {
            "type":"LB","value":1215,
            "label":"SERUM IGA LEVELS(METRO)"
        },
        {
            "type":"LB","value":1216,
            "label":"TB PCR (BLOOD/FRESH TISSUE)(METRO)"
        },
        {
            "type":"LB","value":1217,
            "label":"TOTAL HBC ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1218,
            "label":"TOXOPLASMA IGG(METRO)"
        },
        {
            "type":"LB","value":1219,
            "label":"TOXOPLASMA IGM(METRO)"
        },
        {
            "type":"LB","value":1220,
            "label":"TYPHI DOT IGM(METRO)"
        },
        {
            "type":"LB","value":1221,
            "label":"VZV FOR PCR(METRO)"
        },
        {
            "type":"LB","value":1222,
            "label":"WEIL-FELIX TEST(METRO)"
        },
        {
            "type":"LB","value":1223,
            "label":"C-ANCA,P-ANCA(METRO)"
        },
        {
            "type":"LB","value":1224,
            "label":"TB PCR FROM PARAFFIN BLOCK(LAL PATH)"
        },
        {
            "type":"LB","value":1225,
            "label":"ANTI LKM(METRO)"
        },
        {
            "type":"LB","value":1226,
            "label":"ANTI SMOOTH MUSCLE(METRO)"
        },
        {
            "type":"LB","value":1227,
            "label":"PR3 ANCA(METRO)"
        },
        {
            "type":"LB","value":1228,
            "label":"SERUM IGG LEVELS(METRO)"
        },
        {
            "type":"LB","value":1229,
            "label":"24 HR URINARY CREATININE CLEARANCE"
        },
        {
            "type":"LB","value":1230,
            "label":"24 HR URINARY PROTEINS"
        },
        {
            "type":"LB","value":1231,
            "label":"FLUID FOR ADA"
        },
        {
            "type":"LB","value":1232,
            "label":"SERUM B2 MICROGLOBULIN"
        },
        {
            "type":"LB","value":1233,
            "label":"URINE BENCE JONES PROTEINS"
        },
        {
            "type":"LB","value":1234,
            "label":"SERUM BETA HCG"
        },
        {
            "type":"LB","value":1817,
            "label":"Random Donor Platelets RDP A Positive"
        },
        {
            "type":"LB","value":1236,
            "label":"BLOOD UREA"
        },
        {
            "type":"LB","value":1237,
            "label":"PLASMA GLUCOSE FASTING SUGAR"
        },
        {
            "type":"LB","value":1238,
            "label":"SERUM GLOBULIN"
        },
        {
            "type":"LB","value":1240,
            "label":"SERUM PHOSPHORUS"
        },
        {
            "type":"LB","value":1241,
            "label":"SERUM POTASSIUM"
        },
        {
            "type":"LB","value":1242,
            "label":"RANDOM BLOOD SUGAR"
        },
        {
            "type":"LB","value":1243,
            "label":"SERUM AFP"
        },
        {
            "type":"LB","value":1244,
            "label":"SERUM ALBUMIN"
        },
        {
            "type":"LB","value":1245,
            "label":"SERUM ALKALINE PHOSPHATASE ALP"
        },
        {
            "type":"LB","value":1246,
            "label":"SERUM ALT SGPT"
        },
        {
            "type":"LB","value":1247,
            "label":"SERUM AMYLASE"
        },
        {
            "type":"LB","value":1248,
            "label":"SERUM AST SGOT"
        },
        {
            "type":"LB","value":1249,
            "label":"SERUM BILRUBIN TOTAL"
        },
        {
            "type":"LB","value":1250,
            "label":"SERUM CA 125"
        },
        {
            "type":"LB","value":1251,
            "label":"SERUM CA 15-3"
        },
        {
            "type":"LB","value":1252,
            "label":"SERUM CA-19.9"
        },
        {
            "type":"LB","value":1253,
            "label":"SERUM CALCIUM"
        },
        {
            "type":"LB","value":1254,
            "label":"SERUM CEA"
        },
        {
            "type":"LB","value":1255,
            "label":"SERUM CHOLESTEROL TOTAL"
        },
        {
            "type":"LB","value":1256,
            "label":"SERUM CPK - MB"
        },
        {
            "type":"LB","value":1257,
            "label":"SERUM CREATININE"
        },
        {
            "type":"LB","value":1258,
            "label":"SERUM GAMMA GT"
        },
        {
            "type":"LB","value":1259,
            "label":"SERUM INORGANIC PHOSPHORUS"
        },
        {
            "type":"LB","value":1260,
            "label":"SERUM MAGNESIUM"
        },
        {
            "type":"LB","value":1261,
            "label":"SERUM PSA FOR MEN"
        },
        {
            "type":"LB","value":1262,
            "label":"SERUM TRIGLYCERIDES"
        },
        {
            "type":"LB","value":1263,
            "label":"SERUM URIC ACID"
        },
        {
            "type":"LB","value":1264,
            "label":"SERUM T3"
        },
        {
            "type":"LB","value":1265,
            "label":"SERUM T4"
        },
        {
            "type":"LB","value":1266,
            "label":"SERUM TOTAL PROTIENS"
        },
        {
            "type":"LB","value":1267,
            "label":"SERUM TSH"
        },
        {
            "type":"LB","value":1268,
            "label":"SERUM HDL CHOLESTEROL"
        },
        {
            "type":"LB","value":1269,
            "label":"SERUM LDL"
        },
        {
            "type":"LB","value":1270,
            "label":"SERUM SODIUM"
        },
        {
            "type":"LB","value":1271,
            "label":"SERUM CHLORIDES"
        },
        {
            "type":"LB","value":1818,
            "label":"Random Donor Platelets RDP A Negativ"
        },
        {
            "type":"LB","value":1819,
            "label":"Random Donor Platelets RDP  B Positive"
        },
        {
            "type":"LB","value":1274,
            "label":"SERUM LACTATE DEHYDROGENASE(LDH)"
        },
        {
            "type":"LB","value":1275,
            "label":"URINE FOR VMA(VIMTA)"
        },
        {
            "type":"LB","value":1276,
            "label":"PLASMA GLUCOSE POST PRANDIAL"
        },
        {
            "type":"LB","value":1277,
            "label":"URINE OSMOLARITY"
        },
        {
            "type":"LB","value":1278,
            "label":"URINE FOR SODIUM(SPOT)"
        },
        {
            "type":"LB","value":1279,
            "label":"URINE FOR POTASSIUM(SPOT)"
        },
        {
            "type":"LB","value":1280,
            "label":"GLYCOSYLATED HEMOGLOBIN(HBA 1C)"
        },
        {
            "type":"LB","value":1281,
            "label":"SERUM PROTEIN ELECTROPHORSIS"
        },
        {
            "type":"LB","value":1282,
            "label":"FLUID PROTEINS(URINE/CSF/OTHER FLUIDS)"
        },
        {
            "type":"LB","value":1283,
            "label":"SERUM THYROGLOBULIN"
        },
        {
            "type":"LB","value":1284,
            "label":"FDP(FIBRINOGEN DEGRADATION PRODUCTS)"
        },
        {
            "type":"LB","value":1820,
            "label":"Random Donor Platelets RDP B Negative"
        },
        {
            "type":"LB","value":1286,
            "label":"URINARY PROTEIN-SPOT"
        },
        {
            "type":"LB","value":1287,
            "label":"URINARY CREATININE-SPOT"
        },
        {
            "type":"LB","value":1288,
            "label":"TROPONIN I- High Sensitive"
        },
        {
            "type":"LB","value":1289,
            "label":"FLUID FOR PROTEINS"
        },
        {
            "type":"LB","value":1842,
            "label":"No of cells counted"
        },
        {
            "type":"LB","value":1291,
            "label":"FLUID FOR CHLORIDES"
        },
        {
            "type":"LB","value":1292,
            "label":"D-DIMER"
        },
        {
            "type":"LB","value":1293,
            "label":"CSF FOR ADA LEVELS"
        },
        {
            "type":"LB","value":1294,
            "label":"URINE CREATININE"
        },
        {
            "type":"LB","value":1295,
            "label":"FLUID CREATININE"
        },
        {
            "type":"LB","value":1821,
            "label":"Random Donor Platelets RDP AB Positive"
        },
        {
            "type":"LB","value":1298,
            "label":"FLUID FOR GLUCOSE"
        },
        {
            "type":"LB","value":1733,
            "label":"Haemoglobin"
        },
        {
            "type":"LB","value":1300,
            "label":"FLUID FOR ALBUMIN"
        },
        {
            "type":"LB","value":1301,
            "label":"FLUID FOR LDH"
        },
        {
            "type":"LB","value":1302,
            "label":"NT-PRO BNP(SPECTRA)"
        },
        {
            "type":"LB","value":1303,
            "label":"AMMONIA (HEPARINIZED PLASMA)(SPECTRA)"
        },
        {
            "type":"LB","value":1304,
            "label":"FLUID  AMYLASE"
        },
        {
            "type":"LB","value":1305,
            "label":"Serum 25 - OH Vitamin D -Total"
        },
        {
            "type":"LB","value":1306,
            "label":"PLASMA LACTATE"
        },
        {
            "type":"LB","value":1307,
            "label":"SERUM OSMOLALITY"
        },
        {
            "type":"LB","value":1308,
            "label":"URINE FOR OSMOLALITY"
        },
        {
            "type":"LB","value":1309,
            "label":"POCT/IV"
        },
        {
            "type":"LB","value":1310,
            "label":"PLASMA CATECHOLAMINES(METRO)"
        },
        {
            "type":"LB","value":1311,
            "label":"24 HRS URINE 17-HYDROXY CORTICOSTEROIDS(METRO)"
        },
        {
            "type":"LB","value":1312,
            "label":"SERUM 17-HYDROXY PROGESTERONE(METRO)"
        },
        {
            "type":"LB","value":1313,
            "label":"SERUM TESTOSTERONE(METRO)"
        },
        {
            "type":"LB","value":1314,
            "label":"24 HRS URINARY HIAA (METRO)"
        },
        {
            "type":"LB","value":1315,
            "label":"SERUM ACE LEVELS(METRO)"
        },
        {
            "type":"LB","value":1316,
            "label":"SERUM ACID PHOSPHOTASE TOTAL AND PROSTATIC(METRO)"
        },
        {
            "type":"LB","value":1317,
            "label":"PLASMA ADRENALINE(METRO)"
        },
        {
            "type":"LB","value":1318,
            "label":"24 HRS URINARY ADRENALINE(METRO)"
        },
        {
            "type":"LB","value":1319,
            "label":"ACTH PLASMA(METRO)"
        },
        {
            "type":"LB","value":1320,
            "label":"SERUM ALDOSTERONE (METRO)"
        },
        {
            "type":"LB","value":1321,
            "label":"SERUM THYROGLOBULIN ANTIBODY(ATA)(METRO)"
        },
        {
            "type":"LB","value":1322,
            "label":"SERUM CA 72-4(METRO)"
        },
        {
            "type":"LB","value":1323,
            "label":"SERUM CALCITONIN(METRO)"
        },
        {
            "type":"LB","value":1324,
            "label":"CALCULUS (STONE) ANALYSIS GALL BLADDER(METRO)"
        },
        {
            "type":"LB","value":1325,
            "label":"CALCULUS (STONE) ANALYSIS URINARY STONE(METRO)"
        },
        {
            "type":"LB","value":1326,
            "label":"URINE CATECHOLAMINES(METRO)"
        },
        {
            "type":"LB","value":1327,
            "label":"SERUM CERULOPLASMIN(METRO)"
        },
        {
            "type":"LB","value":1328,
            "label":"PLASMA CHROMOGRANIN(METRO)"
        },
        {
            "type":"LB","value":1329,
            "label":"SERUM CK-MM(METRO)"
        },
        {
            "type":"LB","value":1330,
            "label":"24 HRS URINE COPPER BY ATOMIC CLEARANCE(METRO)"
        },
        {
            "type":"LB","value":1331,
            "label":"SERUM COPPER BY BIOCHEMICAL METHOD(METRO)"
        },
        {
            "type":"LB","value":1332,
            "label":"SERUM CORTISOL(METRO)"
        },
        {
            "type":"LB","value":1333,
            "label":"SERUM C-PEPTIDE (METRO)"
        },
        {
            "type":"LB","value":1334,
            "label":"CYCLOSPORIN BLOOD(METRO)"
        },
        {
            "type":"LB","value":1335,
            "label":"SERUM CYSTATIN C(METRO)"
        },
        {
            "type":"LB","value":1336,
            "label":"PLASMA DOPAMINE(METRO)"
        },
        {
            "type":"LB","value":1337,
            "label":"24 HRS URINE DOPAMINE(METRO)"
        },
        {
            "type":"LB","value":1338,
            "label":"SERUM E2-ESTRADIOL(METRO)"
        },
        {
            "type":"LB","value":1339,
            "label":"SERUM ERYTHROPOIETIN(EPO)(METRO)"
        },
        {
            "type":"LB","value":1340,
            "label":"SERUM FERRITIN(METRO)"
        },
        {
            "type":"LB","value":1341,
            "label":"SERUM FOLIC ACID(METRO)"
        },
        {
            "type":"LB","value":1342,
            "label":"SERUM FREE T3(METRO)"
        },
        {
            "type":"LB","value":1343,
            "label":"SERUM FREE T4(METRO)"
        },
        {
            "type":"LB","value":1344,
            "label":"SERUM FREE TESTOSTERONE(METRO)"
        },
        {
            "type":"LB","value":1345,
            "label":"SERUM GASTRIN(METRO)"
        },
        {
            "type":"LB","value":1346,
            "label":"SERUM HAPTOGLOBIN(METRO)"
        },
        {
            "type":"LB","value":1347,
            "label":"SERUM HOMOCYSTEINE (METRO)"
        },
        {
            "type":"LB","value":1348,
            "label":"SERUM INHIBIN A (METRO)"
        },
        {
            "type":"LB","value":1349,
            "label":"SERUM INHIBIN B (METRO)"
        },
        {
            "type":"LB","value":1350,
            "label":"SERUM INSULIN FASTING(METRO)"
        },
        {
            "type":"LB","value":1351,
            "label":"SERUM PARATHYROID HARMONE (INTACT PTH)(METRO)"
        },
        {
            "type":"LB","value":1352,
            "label":"SERUM IRON(BIOCHEMICAL)(METRO)"
        },
        {
            "type":"LB","value":1353,
            "label":"24 HRS URINE KAPPA LIGHT CHAINS(METRO)"
        },
        {
            "type":"LB","value":1354,
            "label":"SERUM LIPASE(METRO)"
        },
        {
            "type":"LB","value":1355,
            "label":"24 HRS URINE METANEPHRINES(METRO)"
        },
        {
            "type":"LB","value":1356,
            "label":"24 HRS URINE MICROALBUMIN(METRO)"
        },
        {
            "type":"LB","value":1357,
            "label":"MICRO ALBUMIN URINE(SPOT)(METRO)"
        },
        {
            "type":"LB","value":1358,
            "label":"PLASMA NOR-ADRENALINE(METRO)"
        },
        {
            "type":"LB","value":1359,
            "label":"24 HRS URINE NOR-ADRENALINE(METRO)"
        },
        {
            "type":"LB","value":1360,
            "label":"PLASMA NOR-METANEPHRINE(METRO)"
        },
        {
            "type":"LB","value":1361,
            "label":"24 HRS URINE NOR-METANEPHRINE(METRO)"
        },
        {
            "type":"LB","value":1362,
            "label":"SERUM OESTRADIOL(E2)(METRO)"
        },
        {
            "type":"LB","value":1363,
            "label":"SERUM PHENYTOIN(METRO)"
        },
        {
            "type":"LB","value":1364,
            "label":"PLASMA RENIN - DIRECT(METRO)"
        },
        {
            "type":"LB","value":1365,
            "label":"SERUM PROLACTIN(METRO)"
        },
        {
            "type":"LB","value":1366,
            "label":"24 HRS URINE ELECTROPHERESIS(METRO)"
        },
        {
            "type":"LB","value":1367,
            "label":"SERUM TIBC- DIRECT(METRO)"
        },
        {
            "type":"LB","value":1368,
            "label":"SERUM TRANSFERRIN(METRO)"
        },
        {
            "type":"LB","value":1369,
            "label":"SERUM CCP(METRO)"
        },
        {
            "type":"LB","value":1370,
            "label":"ANTI HAV-IGM(SPOT)"
        },
        {
            "type":"LB","value":1371,
            "label":"ANTI HEV-IGM(SPOT)"
        },
        {
            "type":"LB","value":1372,
            "label":"EBV ANTIBODIES TO VCA,IGG,IGM;(LALPATH)"
        },
        {
            "type":"LB","value":1373,
            "label":"HBV DNA(QUALITATIVE)(METRO)"
        },
        {
            "type":"LB","value":1374,
            "label":"HCV RNA(QUALITATIVE)(METRO)"
        },
        {
            "type":"LB","value":1375,
            "label":"ANTI CCP (LALPATH)"
        },
        {
            "type":"LB","value":1376,
            "label":"HBE ANTIBODY(METRO)"
        },
        {
            "type":"LB","value":1377,
            "label":"ANTI RO (LAL PATH)"
        },
        {
            "type":"LB","value":1378,
            "label":"ANA BY IF(LAL PATH)"
        },
        {
            "type":"LB","value":1379,
            "label":"HIV 1 VIRAL LOAD AND CD3,CD4/CD8(IDP-2)(LALPATH)"
        },
        {
            "type":"LB","value":1380,
            "label":"CMV DNA PCR(QUALITATIVE)(LALPATH)"
        },
        {
            "type":"LB","value":1381,
            "label":"CLOSTRIDIUM DIFFICILE TOXIN A & B STOOL(MTERO)"
        },
        {
            "type":"LB","value":1382,
            "label":"CD4/CD8 COUNT(LALPATH)"
        },
        {
            "type":"LB","value":1383,
            "label":"TB PCR(QUALITITATIVE)"
        },
        {
            "type":"LB","value":1384,
            "label":"HAV-IGM ANTIBODIES(METRO)"
        },
        {
            "type":"LB","value":1385,
            "label":"TB GOLD(QUANTIFERON)(LALAPTH)"
        },
        {
            "type":"LB","value":1386,
            "label":"H1 N1 PCR(IPM)"
        },
        {
            "type":"LB","value":1387,
            "label":"HSV 1 & 2 QUALITATIVE PCR (LALPATH)"
        },
        {
            "type":"LB","value":1388,
            "label":"ANAE"
        },
        {
            "type":"LB","value":1389,
            "label":"AUTOIMMUNE ENCEPHALITI PANEL"
        },
        {
            "type":"LB","value":1390,
            "label":"NEURONAL ANTIBODY PROFILE(METRO)"
        },
        {
            "type":"LB","value":1391,
            "label":"HEPATITIS B CORE(LALPATH)"
        },
        {
            "type":"LB","value":1392,
            "label":"FISH FOR N-MYC(TMH)"
        },
        {
            "type":"LB","value":1393,
            "label":"IHC-BREAST PROGNOSIS PRO-I(ERPR AND HER-2NEW KI67)"
        },
        {
            "type":"LB","value":1822,
            "label":"Random Donor Platelets RDP AB Negative"
        },
        {
            "type":"LB","value":1395,
            "label":"URINE FOR BILE PIGMENTS"
        },
        {
            "type":"LB","value":1396,
            "label":"URINE FOR KETONES"
        },
        {
            "type":"LB","value":1397,
            "label":"URINE FOR PH"
        },
        {
            "type":"LB","value":1398,
            "label":"URINE FOR SUGAR"
        },
        {
            "type":"LB","value":1399,
            "label":"BRUSH CYTOLOGY"
        },
        {
            "type":"LB","value":1400,
            "label":"CYTOLOGY AND CELL COUNT - CSF"
        },
        {
            "type":"LB","value":1401,
            "label":"FLUID CYTOLOGY(PLEURAL FLUID & ASCITIC FLUID)"
        },
        {
            "type":"LB","value":1402,
            "label":"FNAC - FINE NEEDLE ASPIRATION CYTOLOGY(PROCEDURE+R"
        },
        {
            "type":"LB","value":1403,
            "label":"PAPSMEAR"
        },
        {
            "type":"LB","value":1404,
            "label":"SPUTUM CYTOLOGY"
        },
        {
            "type":"LB","value":1405,
            "label":"ABSOLUTE EOSINOPHIL COUNT"
        },
        {
            "type":"LB","value":1406,
            "label":"ABSOLUTE NEUTROPHIL COUNT"
        },
        {
            "type":"LB","value":1408,
            "label":"CYTOCHEMICAL ADDITIONAL STAIN"
        },
        {
            "type":"LB","value":1409,
            "label":"CYTOCHEMICAL STAINS"
        },
        {
            "type":"LB","value":1410,
            "label":"HB ELECTROPHERESIS"
        },
        {
            "type":"LB","value":1411,
            "label":"ERYTHROCYTE SEDIMENTATION RATE(ESR)"
        },
        {
            "type":"LB","value":1412,
            "label":"HAEMOGLOBIN ESTIMATION"
        },
        {
            "type":"LB","value":1413,
            "label":"LAP SCORE"
        },
        {
            "type":"LB","value":1414,
            "label":"MALARIAL PARASITE"
        },
        {
            "type":"LB","value":1415,
            "label":"Packed Cell Volume"
        },
        {
            "type":"LB","value":1416,
            "label":"PERIPHERAL SMEAR FOR ABNORMAL CELLS"
        },
        {
            "type":"LB","value":1417,
            "label":"Platelet Count"
        },
        {
            "type":"LB","value":1418,
            "label":"RETICULOCYTE COUNT"
        },
        {
            "type":"LB","value":1419,
            "label":"SICKLING TEST"
        },
        {
            "type":"LB","value":1420,
            "label":"WBC COUNT"
        },
        {
            "type":"LB","value":1421,
            "label":"RBC COUNT"
        },
        {
            "type":"LB","value":1422,
            "label":"HISTOPATHOLOGY(BIOPSY)- LARGE"
        },
        {
            "type":"LB","value":1423,
            "label":"HISTOPATHOLOGY(BIOPSY)- MEDIUM"
        },
        {
            "type":"LB","value":1424,
            "label":"HISTOPATHOLOGY BIOPSY SMALL"
        },
        {
            "type":"LB","value":1425,
            "label":"BONE MARROW ASPIRATION"
        },
        {
            "type":"LB","value":1426,
            "label":"BONE MARROW BIOPSY"
        },
        {
            "type":"LB","value":1427,
            "label":"DUPLICATE BLOCK"
        },
        {
            "type":"LB","value":1428,
            "label":"DUPLICATE REPORT"
        },
        {
            "type":"LB","value":1429,
            "label":"DUPLICATE SLIDE"
        },
        {
            "type":"LB","value":1430,
            "label":"DUPLICATE SLIDE (FULL SET)"
        },
        {
            "type":"LB","value":1431,
            "label":"FROZEN"
        },
        {
            "type":"LB","value":1432,
            "label":"FROZEN FOR MARGINS & DIAGNOSIS"
        },
        {
            "type":"LB","value":1433,
            "label":"PCR"
        },
        {
            "type":"LB","value":1434,
            "label":"SLIDE REVIEW(ONLY SLIDES)"
        },
        {
            "type":"LB","value":1435,
            "label":"SLIDES/BLOCKS FOR REVIEW (< 4 NOS)"
        },
        {
            "type":"LB","value":1436,
            "label":"SLIDES/BLOCKS FOR REVIEW (>4 NOS)"
        },
        {
            "type":"LB","value":1437,
            "label":"SPEICAL STAINS"
        },
        {
            "type":"LB","value":1438,
            "label":"ERPR"
        },
        {
            "type":"LB","value":1439,
            "label":"IHC-NHL-PANEL CD3 CD20 CD45 CD30"
        },
        {
            "type":"LB","value":1440,
            "label":"IMMUNO PHENO TYPING-ALL PANEL"
        },
        {
            "type":"LB","value":1441,
            "label":"IMMUNO PHENO TYPING-AML PANEL"
        },
        {
            "type":"LB","value":1442,
            "label":"IHC 1 MARKER"
        },
        {
            "type":"LB","value":1443,
            "label":"IHC LYMPHOMA(MINI) PANEL"
        },
        {
            "type":"LB","value":1444,
            "label":"IHC SPINDLE CELL PANEL"
        },
        {
            "type":"LB","value":1445,
            "label":"IHC ROUND CELL PANEL"
        },
        {
            "type":"LB","value":1446,
            "label":"URINE MICROSCOPY"
        },
        {
            "type":"LB","value":1447,
            "label":"URINE METACHROMARTIC GRANULES"
        },
        {
            "type":"LB","value":1448,
            "label":"ENDOSCOPIC/BRUSH SMEARS"
        },
        {
            "type":"LB","value":1731,
            "label":"Bleeding Time"
        },
        {
            "type":"LB","value":1732,
            "label":"Clotting Time"
        },
        {
            "type":"LB","value":1823,
            "label":"Random Donor Platelets RDP  O Positive"
        },
        {
            "type":"LB","value":1734,
            "label":"Red Cell Count"
        },
        {
            "type":"LB","value":1735,
            "label":"Neutrophils"
        },
        {
            "type":"LB","value":1736,
            "label":"Lymphocyte"
        },
        {
            "type":"LB","value":1737,
            "label":"Monocyte"
        },
        {
            "type":"LB","value":1738,
            "label":"Eosinophil"
        },
        {
            "type":"LB","value":1739,
            "label":"Basophil"
        },
        {
            "type":"LB","value":1740,
            "label":"ESR"
        },
        {
            "type":"LB","value":1744,
            "label":"T790M"
        },
        {
            "type":"LB","value":1745,
            "label":"Del 19"
        },
        {
            "type":"LB","value":1746,
            "label":"L858R"
        },
        {
            "type":"LB","value":1747,
            "label":"L861Q"
        },
        {
            "type":"LB","value":1748,
            "label":"G719X"
        },
        {
            "type":"LB","value":1749,
            "label":"S768I"
        },
        {
            "type":"LB","value":1750,
            "label":"3 Insertions"
        },
        {
            "type":"LB","value":1751,
            "label":"Specific Gravity"
        },
        {
            "type":"LB","value":1752,
            "label":"Proteins"
        },
        {
            "type":"LB","value":1753,
            "label":"Blood"
        },
        {
            "type":"LB","value":1754,
            "label":"Bile Pigments"
        },
        {
            "type":"LB","value":1755,
            "label":"Urobilinogen"
        },
        {
            "type":"LB","value":1756,
            "label":"Leucocytes"
        },
        {
            "type":"LB","value":1757,
            "label":"Nitrites"
        },
        {
            "type":"LB","value":1758,
            "label":"PUS Cells"
        },
        {
            "type":"LB","value":1759,
            "label":"RBCs"
        },
        {
            "type":"LB","value":1760,
            "label":"Epthelial Cells"
        },
        {
            "type":"LB","value":1761,
            "label":"Total Count (spermatozoa)"
        },
        {
            "type":"LB","value":1762,
            "label":"MCV"
        },
        {
            "type":"LB","value":1763,
            "label":"MCH"
        },
        {
            "type":"LB","value":1764,
            "label":"MCHC"
        },
        {
            "type":"LB","value":1765,
            "label":"Serum Total IGA"
        },
        {
            "type":"LB","value":1766,
            "label":"Serum Total IgG"
        },
        {
            "type":"LB","value":1767,
            "label":"Serum Total IgM"
        },
        {
            "type":"LB","value":1768,
            "label":"Kappa Light Chain"
        },
        {
            "type":"LB","value":1769,
            "label":"Lamda Light Chain"
        },
        {
            "type":"LB","value":1770,
            "label":"Kappa Lambda Ratio"
        },
        {
            "type":"LB","value":1771,
            "label":"Fluid Protein"
        },
        {
            "type":"LB","value":1772,
            "label":"Fluid Glucose"
        },
        {
            "type":"LB","value":1824,
            "label":"Random Donor Platelets  RDP O Negative"
        },
        {
            "type":"LB","value":1774,
            "label":"After 1hr of 100gm glucose load"
        },
        {
            "type":"LB","value":1775,
            "label":"After 2 hour"
        },
        {
            "type":"LB","value":1776,
            "label":"After 3 hours"
        },
        {
            "type":"LB","value":1777,
            "label":"Blood Urea Nitrogen(Calculated)"
        },
        {
            "type":"LB","value":1778,
            "label":"SERUM BILRUBIN CONJUGATED"
        },
        {
            "type":"LB","value":1779,
            "label":"Serum VLDL"
        },
        {
            "type":"LB","value":1780,
            "label":"Cholesterol/HDL Ratio"
        },
        {
            "type":"LB","value":1782,
            "label":"A/G Ratio"
        },
        {
            "type":"LB","value":1783,
            "label":"Volume"
        },
        {
            "type":"LB","value":1784,
            "label":"Color"
        },
        {
            "type":"LB","value":1785,
            "label":"Appearance"
        },
        {
            "type":"LB","value":1825,
            "label":"Fresh Frozen Plasma FFP  A Positve"
        },
        {
            "type":"LB","value":1787,
            "label":"Crystals"
        },
        {
            "type":"LB","value":1788,
            "label":"Casts"
        },
        {
            "type":"LB","value":1789,
            "label":"Other"
        },
        {
            "type":"LB","value":1790,
            "label":"Time of collection"
        },
        {
            "type":"LB","value":1791,
            "label":"Quantity (Semen)"
        },
        {
            "type":"LB","value":1792,
            "label":"Color (Semen)"
        },
        {
            "type":"LB","value":1793,
            "label":"Appearance (Semen)"
        },
        {
            "type":"LB","value":1794,
            "label":"Odour"
        },
        {
            "type":"LB","value":1795,
            "label":"Liquefication Time"
        },
        {
            "type":"LB","value":1796,
            "label":"pH"
        },
        {
            "type":"LB","value":1797,
            "label":"Total Count"
        },
        {
            "type":"LB","value":1798,
            "label":"Active forward Motility"
        },
        {
            "type":"LB","value":1799,
            "label":"Sluggish Motility"
        },
        {
            "type":"LB","value":1800,
            "label":"Immotile"
        },
        {
            "type":"LB","value":1801,
            "label":"Abnormal Forms"
        },
        {
            "type":"LB","value":1802,
            "label":"Pus Cells (Semen)"
        },
        {
            "type":"LB","value":1803,
            "label":"RBCs (Semen)"
        },
        {
            "type":"LB","value":1804,
            "label":"Histocytes"
        },
        {
            "type":"LB","value":1805,
            "label":"Metamyelocyte"
        },
        {
            "type":"LB","value":1806,
            "label":"Myelocyte"
        },
        {
            "type":"LB","value":1807,
            "label":"Promyelocyte"
        },
        {
            "type":"LB","value":1808,
            "label":"Blast"
        },
        {
            "type":"LB","value":1809,
            "label":"RDW"
        },
        {
            "type":"LB","value":1810,
            "label":"MPV"
        },
        {
            "type":"LB","value":1811,
            "label":"Peripheral Smear"
        },
        {
            "type":"LB","value":1812,
            "label":"Band Forms"
        },
        {
            "type":"LB","value":1813,
            "label":"Fasting Urine Sugar"
        },
        {
            "type":"LB","value":1814,
            "label":"Urine Glucose after 1 hr"
        },
        {
            "type":"LB","value":1815,
            "label":"Urine Glucose after 2 hr"
        },
        {
            "type":"LB","value":1816,
            "label":"Urine Glucose after 3 hr"
        },
        {
            "type":"LB","value":1826,
            "label":"Fresh Frozen Plasma FFP  A Negative"
        },
        {
            "type":"LB","value":1827,
            "label":"Fresh Frozen Plasma FFP  B Positive"
        },
        {
            "type":"LB","value":1828,
            "label":"Fresh Frozen Plasma FFP  B Negative"
        },
        {
            "type":"LB","value":1829,
            "label":"Fresh Frozen Plasma FFP  AB Positive"
        },
        {
            "type":"LB","value":1830,
            "label":"Fresh Frozen Plasma FFP  AB Negative"
        },
        {
            "type":"LB","value":1831,
            "label":"Fresh Frozen Plasma FFP  O Positive"
        },
        {
            "type":"LB","value":1832,
            "label":"Fresh Frozen Plasma FFP  O Negative"
        },
        {
            "type":"LB","value":1833,
            "label":"Packed Red Blood Cells PRBC  A Positve"
        },
        {
            "type":"LB","value":1834,
            "label":"Packed Red Blood Cells PRBC  A Negative"
        },
        {
            "type":"LB","value":1835,
            "label":"Packed Red Blood Cells PRBC  B Positive"
        },
        {
            "type":"LB","value":1836,
            "label":"Packed Red Blood Cells PRBC  B Negative"
        },
        {
            "type":"LB","value":1837,
            "label":"Packed Red Blood Cells PRBC  AB Positive"
        },
        {
            "type":"LB","value":1838,
            "label":"Packed Red Blood Cells PRBC  AB Negative"
        },
        {
            "type":"LB","value":1839,
            "label":"Packed Red Blood Cells PRBC  O Positive"
        },
        {
            "type":"LB","value":1840,
            "label":"Packed Red Blood Cells PRBC  O Negative"
        },
        {
            "type":"LB","value":1841,
            "label":"Cryoprecipitate O negative"
        },
        {
            "type":"LB","value":1843,
            "label":"FLUID FOR SUGARS"
        },
        {
            "type":"LB","value":1844,
            "label":"CRYO BAGS"
        },
        {
            "type":"LB","value":1845,
            "label":"DMSO 100 ML"
        },
        {
            "type":"LB","value":1846,
            "label":"HARVESTING OF STEM CELLS"
        },
        {
            "type":"LB","value":1847,
            "label":"PACKED CELLS WITH REPLACEMENT"
        },
        {
            "type":"LB","value":1848,
            "label":"PLATELET FILTER"
        },
        {
            "type":"LB","value":1849,
            "label":"HUMAN PLASMA"
        },
        {
            "type":"LB","value":1850,
            "label":"R B C FILTER LEUKOCYTE RENOVAL FILTER"
        },
        {
            "type":"LB","value":1851,
            "label":"WHOLE BLOOD WITH REPLACEMENT"
        },
        {
            "type":"LB","value":1852,
            "label":"PLATELET PHERESIS PPWS A Positive"
        },
        {
            "type":"LB","value":1853,
            "label":"PLATELET PHERESIS PPWOS A +ve without Screening"
        },
        {
            "type":"LB","value":1854,
            "label":"PLATELET PHERESIS PPWOS B +ve Without Screening"
        },
        {
            "type":"LB","value":1855,
            "label":"PLATELET PHERESIS PPWOS B -ve Without Screening"
        },
        {
            "type":"LB","value":1856,
            "label":"PLATELET PHERESIS PPWOS A+ve Without Screening"
        },
        {
            "type":"LB","value":1857,
            "label":"PLATELET PHERESIS PPWOS AB +VE Without Screening"
        },
        {
            "type":"LB","value":1858,
            "label":"PLATELET PHERESIS PPWOS AB -VE Without Screening"
        },
        {
            "type":"LB","value":1859,
            "label":"PLATELET PHERESIS PPWOS O +ve Without Screening"
        },
        {
            "type":"LB","value":1860,
            "label":"PLATELET PHERESIS PPWOS O -ve Without Screening"
        },
        {
            "type":"LB","value":1861,
            "label":"Cryoprecipitate A Positve"
        },
        {
            "type":"LB","value":1862,
            "label":"Cryoprecipitate A Negative"
        },
        {
            "type":"LB","value":1863,
            "label":"Cryoprecipitate  B Positive"
        },
        {
            "type":"LB","value":1864,
            "label":"Cryoprecipitate B Negative"
        },
        {
            "type":"LB","value":1865,
            "label":"Cryoprecipitate AB Positive"
        },
        {
            "type":"LB","value":1866,
            "label":"Cryoprecipitate AB Negative"
        },
        {
            "type":"LB","value":1867,
            "label":"Cryoprecipitate  O Positive"
        },
        {
            "type":"LB","value":1868,
            "label":"PLATELET PHERESIS PPWS B Positive"
        },
        {
            "type":"LB","value":1869,
            "label":"PLATELET PHERESIS PPWS B Negative"
        },
        {
            "type":"LB","value":1870,
            "label":"PLATELET PHERESIS PPWS AB Positive"
        },
        {
            "type":"LB","value":1871,
            "label":"PLATELET PHERESIS PPWS AB Negative"
        },
        {
            "type":"LB","value":1872,
            "label":"PLATELET PHERESIS PPWS O Positive"
        },
        {
            "type":"LB","value":1873,
            "label":"PLATELET PHERESIS PPWS O Negative"
        },
        {
            "type":"LB","value":1874,
            "label":"PROTHROMBIN TIME PT"
        },
        {
            "type":"LB","value":1875,
            "label":"ACTIVATED PARTIAL THROMBO PLASTIN TIME (APTT)"
        },
        {
            "type":"LB","value":1876,
            "label":"HISTOPATHOLOGY BIOPSY TONGUE and RND"
        },
        {
            "type":"LB","value":1877,
            "label":"Test(Prothrombin Time)"
        },
        {
            "type":"LB","value":1878,
            "label":"Control"
        },
        {
            "type":"LB","value":1879,
            "label":"INR"
        },
        {
            "type":"LB","value":1880,
            "label":"Test (APTT)"
        },
        {
            "type":"LB","value":1881,
            "label":"SERUM CALCITONIN(LALPATH)"
        },
        {
            "type":"LB","value":1882,
            "label":"EGFR MUTATION"
        },
        {
            "type":"LB","value":1883,
            "label":"FIBRINOGEN"
        },
        {
            "type":"LB","value":1884,
            "label":"URINARY PROTEIN/CREATININE RATIO"
        },
        {
            "type":"LB","value":1885,
            "label":"IHC LYMPHOMA(CMC VELLORE)"
        },
        {
            "type":"LB","value":1886,
            "label":"AFB-XPERT PANEL (FLUID)(METRO)"
        },
        {
            "type":"LB","value":1887,
            "label":"STOOL EXAMINATION - OCCULT BLOOD"
        },
        {
            "type":"LB","value":1888,
            "label":"BRCA1 & 2 (STRAND)"
        },
        {
            "type":"LB","value":1889,
            "label":"WIDAL"
        },
        {
            "type":"LB","value":1890,
            "label":"PLATELET PHERESIS PPWS A Negative"
        },
        {
            "type":"LB","value":1891,
            "label":"HLA DRB TYPING(SPECTRA)"
        },
        {
            "type":"LB","value":1892,
            "label":"HLA C LOCI(SPECTRA)"
        },
        {
            "type":"LB","value":1893,
            "label":"HLA DQB TYPING(SPECTRA)"
        },
        {
            "type":"LB","value":1894,
            "label":"ANTIHBC"
        },
        {
            "type":"LB","value":1895,
            "label":"HLA TYPING,(HISTOGENETICS)"
        },
        {
            "type":"LB","value":1896,
            "label":"MUTATION ANALYSIS FOR N-RAS (MP))"
        },
        {
            "type":"LB","value":1897,
            "label":"NGS COLON PANEL(SOMATIC)(STRAND)"
        },
        {
            "type":"LB","value":1898,
            "label":"NGS PANEL(HEREDIATARY/GERMLINE PANEL)(STRAND)"
        },
        {
            "type":"LB","value":1899,
            "label":"HUMAN PAPILLOMA. V PCR"
        },
        {
            "type":"LB","value":1900,
            "label":"Total IgM"
        },
        {
            "type":"LB","value":1901,
            "label":"STRESS GENETICS (GENE LAB) (STRESS)"
        },
        {
            "type":"LB","value":1902,
            "label":"C KIT MUTATION(PCR SEQUENCING METHOD)(SRL)"
        },
        {
            "type":"LB","value":1903,
            "label":"MUTATION ANALYSIS FOR N-RAS"
        },
        {
            "type":"LB","value":1904,
            "label":"GFR ESTIMATE(CALCULATED)"
        },
        {
            "type":"LB","value":1905,
            "label":"EBV IGM ANTIBODIES TO VIRAL CAPSID ANTIGEN(VCA)(METRO)"
        },
        {
            "type":"LB","value":1906,
            "label":"FISH FOR ROS-1"
        },
        {
            "type":"LB","value":1911,
            "label":"FLUID FOR CREATININE"
        },
        {
            "type":"LB","value":1908,
            "label":"Fasting Plasma Glucose"
        },
        {
            "type":"LB","value":1909,
            "label":"After 1hr of 75gm glucose load"
        },
        {
            "type":"LB","value":1910,
            "label":"After 2hrs of 75gm glucose load"
        },
        {
            "type":"LB","value":1912,
            "label":"MRD FOR MULTIPLE MYLOMA(ONQUEST)"
        },
        {
            "type":"LB","value":1913,
            "label":"FLUID FOR BILRUBIN"
        },
        {
            "type":"LB","value":1914,
            "label":"SERUM GROWTH HORMONE(LALPATH)"
        },
        {
            "type":"LB","value":1915,
            "label":"ANTI DS DNA(LALPATH)"
        },
        {
            "type":"LB","value":1916,
            "label":"MYCOPLASMA PNEMONIA IgG ANTIBODY SERUM(METRO)"
        },
        {
            "type":"LB","value":1917,
            "label":"MYCOPLASMA PNEMONIA IgM ANTIBODY SERUM(METRO)"
        },
        {
            "type":"LB","value":1918,
            "label":"CMV IgG & IgM ANTIBODY(METRO)"
        },
        {
            "type":"LB","value":1919,
            "label":"HLA B27 PCR(METRO)"
        },
        {
            "type":"LB","value":1920,
            "label":"C-ANCA, P-ANGA(LALPATH)"
        },
        {
            "type":"LB","value":1921,
            "label":"TOXOPLASMA IGG ANTIBODY(METRO)"
        },
        {
            "type":"LB","value":1922,
            "label":"P-ANCA(LALPATH)"
        },
        {
            "type":"LB","value":1923,
            "label":"TBPCR(LALPATH)"
        },
        {
            "type":"LB","value":1924,
            "label":"ANTI MITOCHONDIAL ANTIBODIES(LALPATH)"
        },
        {
            "type":"LB","value":1925,
            "label":"ANA BY ELISA(METRO)"
        },
        {
            "type":"LB","value":1926,
            "label":"C-ANCA(LALPATH)"
        },
        {
            "type":"LB","value":1927,
            "label":"ANTI PHOSPHOLIPID ANTIBODY IgG(LALPATH)"
        },
        {
            "type":"LB","value":1928,
            "label":"LUNG PANEL-1(EGFR & ALK-D5F3)"
        },
        {
            "type":"LB","value":1929,
            "label":"LUNG PANEL-2(EGFR MUTATION, ALK-D5F3 & ROS)"
        },
        {
            "type":"LB","value":1930,
            "label":"HUMANPAPILLOAM.V+LBC"
        },
        {
            "type":"LB","value":1931,
            "label":"MUTATION SPECIFIC TEST-MST(STRAND)"
        },
        {
            "type":"LB","value":1932,
            "label":"CMV RT PCR(Quantitative)(RANBAXY)"
        },
        {
            "type":"LB","value":1933,
            "label":"EBV RT PCR(Quantitative)(RANBAXY)"
        },
        {
            "type":"LB","value":1934,
            "label":"CYCLOSPORINE(SPECTRA)"
        },
        {
            "type":"LB","value":1935,
            "label":"PGDFRA(Gene Lab)"
        },
        {
            "type":"LB","value":1936,
            "label":"FLUID FOR LIPASE(SPECTRA)"
        },
        {
            "type":"LB","value":1937,
            "label":"SERUM LIPASE(SPECTRA)"
        },
        {
            "type":"LB","value":1938,
            "label":"TORCH PANEL(LALPATH)"
        },
        {
            "type":"LB","value":1939,
            "label":"GENE XPERT MTB/RIF"
        },
        {
            "type":"LB","value":1940,
            "label":"HELICOBACTER PYLORI ANTIGEN STOOL(LALPATH)"
        },
        {
            "type":"LB","value":1941,
            "label":"CHIMERISM(BASE LINE)(GENE LAB)"
        },
        {
            "type":"LB","value":1942,
            "label":"POST TX CHIMERISM(RECEPIENT) (GENE LAB)"
        },
        {
            "type":"LB","value":1943,
            "label":"SERUM ANTI GANGLIOSIDE ANTIBODIES IgM(METRO)"
        },
        {
            "type":"LB","value":1944,
            "label":"SERUM ANTI GANGLIOSIDE ANTIBODIES IgG(METRO)"
        },
        {
            "type":"LB","value":1945,
            "label":"IHC- ANDROGEN RECEPTOR"
        },
        {
            "type":"LB","value":1946,
            "label":"FLUID FOR CHYLOMICRONS (METRO)"
        },
        {
            "type":"LB","value":1947,
            "label":"Serum CK-MB(Mass),(Spectra)"
        },
        {
            "type":"LB","value":1948,
            "label":"ANTI THYROID ANTIBODIES - ANTI TPO(SPECTRA)"
        },
        {
            "type":"LB","value":1949,
            "label":"CANCER TRACK FOR LUNG CANCER TRACT(DATAR GENETICS)"
        },
        {
            "type":"LB","value":1950,
            "label":"X Y CHIMERISM - FISH(GENE LAB)"
        },
        {
            "type":"LB","value":1951,
            "label":"VDRL"
        },
        {
            "type":"LB","value":1952,
            "label":"PDGFRA(GENE LAB)"
        },
        {
            "type":"LB","value":1953,
            "label":"SERUM IMMUNOFIXATION ELECTROPHORESIS(IFE)(LALPATH)"
        },
        {
            "type":"LB","value":1954,
            "label":"GENEXPERT MTB WITH PIFAMOICIN RESISTANCE, QUALITATIVE, PCR(LALPATH)"
        },
        {
            "type":"LB","value":1955,
            "label":"ANA PROFILE(METRO)"
        },
        {
            "type":"LB","value":1956,
            "label":"Women Hereditary Cancer panel(BOC)(Datar genetics)"
        },
        {
            "type":"LB","value":1957,
            "label":"SLIDE REVIEW(CMC VELLORE)"
        },
        {
            "type":"LB","value":1958,
            "label":"CRYOGLOBULINS PANEL(LALPATH)"
        },
        {
            "type":"LB","value":1959,
            "label":"HLA TYPING(genelab)"
        },
        {
            "type":"LB","value":1960,
            "label":"IHC-IDH(CORE DIAGNOSTICS)"
        },
        {
            "type":"LB","value":1961,
            "label":"MGMT(CORE DIAGNOSTICS)"
        },
        {
            "type":"LB","value":1962,
            "label":"CSF FOR GLUCOSE"
        },
        {
            "type":"LB","value":1963,
            "label":"CSF FOR PROTIENS"
        },
        {
            "type":"LB","value":1964,
            "label":"CSF FOR CHLORIDES"
        },
        {
            "type":"LB","value":1965,
            "label":"VITAMIN E, TOCOPHEROL(LALPATH)"
        },
        {
            "type":"LB","value":1966,
            "label":"MSI/NGS-MACRO INSTABILITY ANALYSIS(DATAR GENETICS)"
        },
        {
            "type":"LB","value":1967,
            "label":"SERUM B12"
        },
        {
            "type":"LB","value":1968,
            "label":"SERUM CPK-MB(SPECTRA)"
        },
        {
            "type":"LB","value":1969,
            "label":"ANY FAMILIAR CANCER SEQUENCING (DATA GENETICS)"
        },
        {
            "type":"LB","value":1970,
            "label":"IHC-1 MARKER(OUTSIDE)"
        },
        {
            "type":"LB","value":1971,
            "label":"T Cell Clonality (ONCQUEST)"
        },
        {
            "type":"LB","value":1972,
            "label":"Out Side Blood Bag(Screening Charges)"
        },
        {
            "type":"LB","value":1973,
            "label":"LRBS Filter"
        },
        {
            "type":"LB","value":1974,
            "label":"Washed RBS Charges"
        },
        {
            "type":"LB","value":1975,
            "label":"VIRAL SCREENING (OUTSIDE BAG)"
        },
        {
            "type":"LB","value":1976,
            "label":"IHC FOR CDH17"
        },
        {
            "type":"LB","value":1977,
            "label":"IgG4 SUB CLASS SERUM (METRO)"
        },
        {
            "type":"LB","value":1978,
            "label":"PNH Screening(Spectra)"
        },
        {
            "type":"LB","value":1979,
            "label":"SPOT URINARY ELECTROLYTES"
        },
        {
            "type":"LB","value":1980,
            "label":"24 HRS URINARY ELECTROLYTES"
        },
        {
            "type":"LB","value":1981,
            "label":"DPD GENE MUTATION(ONQUEST)"
        },
        {
            "type":"LB","value":1982,
            "label":"LUNG CANCER FUSION GENE ANALYSIS(DATAR GENETICS)"
        },
        {
            "type":"LB","value":1983,
            "label":"FISH FOR N-MYC(CORE)"
        },
        {
            "type":"LB","value":1984,
            "label":"IHC-MSI PANEL (CORE)"
        },
        {
            "type":"LB","value":1985,
            "label":"SLIDE REVIEW WITH IHC ANCILLARY WORKUP(TMH)"
        },
        {
            "type":"LB","value":1986,
            "label":"LBC"
        },
        {
            "type":"LB","value":1987,
            "label":"HLA TYPING (GENE LAB)"
        },
        {
            "type":"LB","value":1988,
            "label":"WAFER CHARGES"
        },
        {
            "type":"LB","value":1989,
            "label":"BLOOD IRRADIATION(CARE HITECH))"
        },
        {
            "type":"LB","value":1990,
            "label":"LEUCODEPLETED RBC(LRBC) FILTER"
        },
        {
            "type":"LB","value":1991,
            "label":"LEUCODEPLETED RBC WITH REPLACEMENT(LRBCR)"
        },
        {
            "type":"LB","value":1992,
            "label":"BRCA1+2(Datar Genetics)"
        },
        {
            "type":"LB","value":1993,
            "label":"LIQUID BIOPSY LUNG CANCER(DATAR GENETICS)"
        },
        {
            "type":"LB","value":1994,
            "label":"CMV IGM(ELISA)"
        },
        {
            "type":"LB","value":1995,
            "label":"PRIMARY IMMUNO DEFICIENCY PANEL(SPECTRA)"
        },
        {
            "type":"LB","value":1996,
            "label":"IHC-BRAF V600"
        },
        {
            "type":"LB","value":1997,
            "label":"SERUM FREE TESTOSTERONE(SPECTRA)"
        },
        {
            "type":"LB","value":1998,
            "label":"SERUM TOTAL TESTOSTERONE(SPECTRA)"
        },
        {
            "type":"LB","value":1999,
            "label":"HUMAN SEX HARMONE BINDING GLOBULIN(SHBG)(SPECTRA)"
        },
        {
            "type":"LB","value":2000,
            "label":"EWS - MOLECULAR WORKUP(CENTRE OF EXCELLENCE)"
        },
        {
            "type":"LB","value":2001,
            "label":"MENS HEREDITARY CANCER PANEL(DATAR GENETICS)"
        },
        {
            "type":"LB","value":2002,
            "label":"IHC-NUT(CENTER OF EXCELLENCE)"
        },
        {
            "type":"LB","value":2003,
            "label":"STONE ANALYSIS(LALPATH)"
        },
        {
            "type":"LB","value":2004,
            "label":"24 HOURS URINE CATECHOLAMINES(LALPATH)"
        },
        {
            "type":"LB","value":2005,
            "label":"HIV 1&2 - ANTIBODY (WESTERN BLOT)"
        },
        {
            "type":"LB","value":2006,
            "label":"IHC-CA 19.9 (SRL DIAGNOSTICS)"
        },
        {
            "type":"LB","value":2007,
            "label":"ANTI TPO ANTIBODIES(LALPATH)"
        },
        {
            "type":"LB","value":2008,
            "label":"SERUM IMMUNOFIXATION ELECTROPHORESIS(IFE)(METRO)"
        },
        {
            "type":"LB","value":2009,
            "label":"PROCESSING CHARGES(EGFR)"
        },
        {
            "type":"LB","value":2010,
            "label":"MPN PANEL BY NGS (GENE LAB)"
        },
        {
            "type":"LB","value":2011,
            "label":"T-CELL GENE CLONALITY(CHENNAI APOLLO)"
        },
        {
            "type":"LB","value":2012,
            "label":"B-CELL GENE CLONALITY(CHENNAI APOLLO)"
        },
        {
            "type":"LB","value":2013,
            "label":"CIRCULATING TUMOR CELLS DETECTION(DATAR GENETICS)"
        },
        {
            "type":"LB","value":2014,
            "label":"CANCER TRACK-LUNG CANCER(BASIC PANEL MUTAT)(DATAR)"
        },
        {
            "type":"LB","value":2015,
            "label":"HLA TYPING HIGH RESOLUTION (MEDGENOME)"
        },
        {
            "type":"LB","value":2016,
            "label":"MET AMPLIFICATION (FISH) CORE DIAGNOSTICS"
        },
        {
            "type":"LB","value":2017,
            "label":"SERUM ESTROGEN LEVELS - TOTAL(LALPATH)"
        },
        {
            "type":"LB","value":2018,
            "label":"VNTR-PCR(GENE LAB)"
        },
        {
            "type":"LB","value":2019,
            "label":"Brief Clinical History"
        },
        {
            "type":"LB","value":2020,
            "label":"Source of specimen"
        },
        {
            "type":"LB","value":2021,
            "label":"Specimen Adequacy"
        },
        {
            "type":"LB","value":2022,
            "label":"Patient & specimen identification"
        },
        {
            "type":"LB","value":2023,
            "label":"Technical interopretability"
        },
        {
            "type":"LB","value":2024,
            "label":"Well-preserved cells occupying >25% of the slide"
        },
        {
            "type":"LB","value":2025,
            "label":"Cellular composition sampling of transform zone"
        },
        {
            "type":"LB","value":2026,
            "label":"rrrr"
        },
        {
            "type":"LB","value":2027,
            "label":"tttt t5656"
        },
        {
            "type":"LB","value":2028,
            "label":"SERUM BILRUBIN UNCONJUGATED"
        },
        {
            "type":"LB","value":2029,
            "label":"yyy"
        },
        {
            "type":"LB","value":2030,
            "label":"lab service creation"
        },
        {
            "type":"LB","value":2031,
            "label":"ewewewew"
        },
        {
            "type":"LB","value":2032,
            "label":"dolo"
        },
        {
            "type":"LB","value":2033,
            "label":"PAPSMEAR(CAMP)"
        },
        {
            "type":"LB","value":2034,
            "label":"Ck Editor"
        },
        {
            "type":"LB","value":2035,
            "label":"Ck Editor1"
        },
        {
            "type":"LB","value":2036,
            "label":"SERUM FSH"
        },
        {
            "type":"LB","value":2037,
            "label":"Serum LH"
        },
        {
            "type":"LB","value":2038,
            "label":"Serum FT4"
        },
        {
            "type":"LB","value":2039,
            "label":"Serum Anti-TPO"
        },
        {
            "type":"LB","value":2040,
            "label":"SERUM E2"
        },
        {
            "type":"LB","value":2041,
            "label":"SERUM METHOTREXATE"
        },
        {
            "type":"LB","value":2042,
            "label":"Serum FT3"
        },
        {
            "type":"LB","value":2043,
            "label":"Serum Ferritin"
        },
        {
            "type":"LB","value":2044,
            "label":"Serum Lipase"
        },
        {
            "type":"LB","value":2045,
            "label":"PROSTATE CORE BIOPSY(HPE)"
        },
        {
            "type":"LB","value":2046,
            "label":"test455"
        },
        {
            "type":"LB","value":2047,
            "label":"MM MATERIAL"
        },
        {
            "type":"LB","value":2048,
            "label":"Test Parameter"
        },
        {
            "type":"LB","value":2049,
            "label":"Toxoplasma"
        },
        {
            "type":"LB","value":2052,
            "label":"rad"
        },
        {
            "type":"LB","value":2051,
            "label":"Alpha 1 globulin"
        },
        {
            "type":"LB","value":2053,
            "label":"teswww"
        },
        {
            "type":"LB","value":2054,
            "label":"vcvcv"
        },
        {
            "type":"LB","value":2055,
            "label":"CYTOGENETICS(LILAC)"
        },
        {
            "type":"LB","value":2056,
            "label":"ERPR/HER2NEU(LARGE BIOPSY)"
        },
        {
            "type":"LB","value":2057,
            "label":"ERPR/HER2NEU(SB+SR)"
        },
        {
            "type":"LB","value":2058,
            "label":"XYZ57"
        },
        {
            "type":"LB","value":2059,
            "label":"lab test"
        },
        {
            "type":"LB","value":2060,
            "label":"platelets"
        },
        {
            "type":"LB","value":2061,
            "label":"Hepatitis E virus(HEV) RT-PCR, Qualitative (Metro)"
        },
        {
            "type":"LB","value":2062,
            "label":"Atypical Cell"
        },
        {
            "type":"LB","value":2063,
            "label":"cardiology55"
        },
        {
            "type":"LB","value":2064,
            "label":"SERUM IFE/IT(QUALITATIVE)"
        },
        {
            "type":"LB","value":2065,
            "label":"Serum Ife"
        },
        {
            "type":"LB","value":2066,
            "label":"IFE Serum 34"
        },
        {
            "type":"LB","value":2067,
            "label":"Serum Immunofixaion IT/Quantitative"
        },
        {
            "type":"LB","value":2070,
            "label":"cyto1"
        },
        {
            "type":"LB","value":2069,
            "label":"serum IFE/IT(Quantitaive)"
        },
        {
            "type":"LB","value":2071,
            "label":"cyto2"
        },
        {
            "type":"LB","value":2072,
            "label":"MRD for Multiple Myeloma"
        },
        {
            "type":"LB","value":2073,
            "label":"New test for testing1"
        },
        {
            "type":"LB","value":2074,
            "label":"Test3"
        },
        {
            "type":"LB","value":2075,
            "label":"katyhya"
        },
        {
            "type":"LB","value":2076,
            "label":"New Master"
        },
        {
            "type":"LB","value":2077,
            "label":"New master for test"
        },
        {
            "type":"LB","value":2078,
            "label":"test5656"
        },
        {
            "type":"LB","value":2079,
            "label":"Diagnostics"
        },
        {
            "type":"LB","value":2080,
            "label":"Culture & sensitive"
        },
        {
            "type":"LB","value":2081,
            "label":"Single test"
        },
        {
            "type":"LB","value":2082,
            "label":"Single test1"
        },
        {
            "type":"LB","value":2083,
            "label":"BLOOD GROUPING & RH TYPING"
        }
    ]