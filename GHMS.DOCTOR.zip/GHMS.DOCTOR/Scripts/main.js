
  $('#name').keyup(function() {
  $('#display').val($('#name').val());
});
        var mbColors = ['#e0ffee', '#fffbe0', '#ffe0e0', '#e0ffe2', '#8fc0c2', '#8f9ac2'];
        var mcColors = ['#212121', '#212121', '#212121', '#212121', '#212121', '#212121'];
        //var mdColors = ['#212121', '#212121', '#212121', '#212121', '#212121', '#212121'];
                
function showModal(){

  var randomize = Math.floor(Math.random()*mbColors.length);
  var randomize1 = Math.floor(Math.random()*mcColors.length);
  //var randomize2 = Math.floor(Math.random()*mdColors.length);
  $('.modal-content').css("background-color", mbColors[randomize]);
  //$('.lazur-bg').css("background-color", mbColors[randomize2]);
  $('.modal-content').css("color", mcColors[randomize1]);

}
// $('.clickMe').click(function() {
//     $(this).parent().find("div:eq(0)").fadeToggle("fast");
// });
$('#click').click(function()
{   

    $("#clickEvent").toggle();     
});

function showModal(id) {

      $('#example-textarea').val('')
      $("#id-text").val(id);
      $('#myModal').toggle();
      
      
}
$('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});

$('.example-default-value').each(function() {


    var default_value = this.value;
    $(this).focus(function() {
        if(this.value == default_value) {
            this.value = '';
        }
    });
    $(this).blur(function() {
        if(this.value == '') {
            this.value = default_value;
        }
    });
});

function example_append() {

    var tar_id = $("#id-text").val();
    $("#"+tar_id).val( $('#example-textarea').val() );
    $('#myModal').hide();
    $('#example-textarea').removeAttr('value');
}

$("#somebutton").click(function () {
  $("#notes-main").append('<li><div class="rotate-1 lazur-bg note"><small>12:03:28 12-04-2014</small><h4>Awesome title</h4><p class="min"></p></div></li>');
});

$(document).ready(function() {
  
	var nice = $("html").niceScroll();  // The document page (body)
	
    $("#boxscroll4").niceScroll("#boxscroll4 .wrapper",{boxzoom:true});  // hw acceleration enabled when using wrapper
    
  });





   $(".s-y").hide();
   $(".moreInfo").hide();
   $(".reportdetail").hide();
   $(".reportdetail1").hide();
   $(".reportdetail2").hide();
   $(".tbl-note").hide();
   $(".btnDiagnostic").hide();
   $('#tbldiagnostics').hide();
   $(".btnMedicine").hide();
   $('#tblmedicines').hide();
   $(".patclose").click(function() {
       $(".s-x").hide();
       $(".s-y").fadeIn(100);
   });
   $(".viewmore").click(function() {
       $(".moreInfo").fadeToggle("fast");
   });
   $(".viewreport").click(function() {
       $(".reportdetail").fadeToggle("fast");
   });
   $(".viewreport1").click(function() {
       $(".reportdetail1").fadeToggle("fast");
   });
   $(".viewreport2").click(function() {
       $(".reportdetail2").fadeToggle("fast");
   });
   $(".btn-note").click(function() {
       $("#txt-note").val('');
       $(".tbl-note-hd").hide();
       $(".tbl-note").show("fast");
   });


   function goBack() {
       window.history.back();
   }


   $(document).ready(function() {
       $(".sel").change(function() {
           $(this).find("option:selected").each(function() {
               var optionValue = $(this).attr("value");
               if (optionValue) {
                   $(".sbox").not("." + optionValue).hide();
                   $("." + optionValue).show();
               } else {
                   $(".sbox").hide();
               }
           });
       }).change();
   });




   $(document).ready(function() {
       //toggle the componenet with class accordion_body
       $(".accordion_head").click(function() {
           if ($('.accordion_body').is(':visible')) {
               $(".accordion_body").stop(true).slideUp(100);
               $(".plusminus").text('+').stop(true);
               $(".accordion_body").slideUp(100);
           }
           $(this).next(".accordion_body").toggle().stop(true);
           $(this).children(".plusminus").stop(true).text('-');
       });
   });


   $(function() {              
   
       $("#srchDiagnostic").autocomplete({
           source: diagnosticTags,
           select: addDiagnostic,                   
       });
   
       function addDiagnostic(event, ui) {
             event.preventDefault();
             $('#tbldiagnostics').show();
             $(".btnDiagnostic").show();
             $(this).val('');                     
             $('.el2').append('<tr class="upload_docs"><th><label>'+ui.item.label+'</label></th><th><input class="form-control"></th><th><a class="removeb2"><i class="icon-trash ic2x"></i></a></tr>' +  '');
       }
   
       $(document).on('click', '.removeb2', function(events) {                       
               $(this).parent().parent().remove();                    
               
               if($('.el2').children('tr').length == 0){
                   $(".btnDiagnostic").hide();
                   $('#tbldiagnostics').hide();
               }
   
       });
     
       $("#srchMedicines").autocomplete({
           source: medicineTags,
           select: addMedicine,                   
       });
   
       function addMedicine(event, ui) {
             event.preventDefault();
             $('#tblmedicines').show();
             $(".btnMedicine").show();
             $(this).val('');                     
             $('.el3').append('<tr class="upload_docs"><th><label>'+ui.item.label+'</label></th><th><select><option value="-1">-select-</option><option value="0">OD</option><option value="1">BD</option><option value="2">TID</option><option value="3">QD</option><option value="4">Other</option></select></th><th><input type="number" class="form-control"></th><th><input type="number" class="form-control"></th><th><input type="text" class="form-control"></th><th><a class="removeb3"><i class="icon-trash ic2x"></i></a></tr>' +  '');
       }
   
       $(document).on('click', '.removeb3', function(events) {                       
               $(this).parent().parent().remove();
               
               if($('.el3').children('tr').length == 0){
                   $(".btnMedicine").hide();
                   $('#tblmedicines').hide();
               }
   
       });
   });


    $(function() {
          $( 'ul.sidebar-menu li a' ).on( 'click', function() {
                $( this ).parent().find( 'li a.actm' ).removeClass( 'actm' );
                $( this ).addClass( 'actm' );
          });
    });

$('.popper').popover({
// trigger: "hover",
    placement: 'bottom',
    container: 'body',
    html: true,
    content: function () {
        return $(this).next('.popper-content').html();
    }
});
$(function() {
  $('[data-toggle="popover"]').popover({
    html: true,
    content: function() {
      return $('#popover-content').html();
    }
  });
});

$(function () {
        $("#chkPassport").click(function () {
            if ($(this).is(":checked")) {
                $("#dvPassport").show();
                $("#AddPassport").hide();
            } else {
                $("#dvPassport").hide();
                $("#AddPassport").show();
            }
        });
    });
