var medicineTags =[
    {
        "type":"DG","value": 1001,
        "label": "1 BCOMPLEX  2 ASCORBIC ACID"
    },
    {
        "type":"DG","value": 1002,
        "label": "A CAL SOLU   B  PHOSPHATE SOLU"
    },
    {
        "type":"DG","value": 1003,
        "label": "ABIRATERONE ACETATE"
    },
    {
        "type":"DG","value": 1004,
        "label": "ACACLOFENAC AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1005,
        "label": "ACEBROPHYLLINE"
    },
    {
        "type":"DG","value": 1006,
        "label": "ACECLOFEMAC AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1007,
        "label": "ACECLOFENAC"
    },
    {
        "type":"DG","value": 1008,
        "label": "ACECLOFENAC AND DROTAVERINE HCL"
    },
    {
        "type":"DG","value": 1009,
        "label": "ACECLOFENAC AND SERRATIOPEPTIDASE"
    },
    {
        "type":"DG","value": 1010,
        "label": "ACECLOFENAC PARACETAMOL SERRATIOPEPTIDAS"
    },
    {
        "type":"DG","value": 1011,
        "label": "ACECLOFENAC PARACETAMOL THIOCOLCHICOSIDE"
    },
    {
        "type":"DG","value": 1012,
        "label": "ACETAMINOPHEN"
    },
    {
        "type":"DG","value": 1013,
        "label": "ACETAMINOPHEN AND CAFFEINE"
    },
    {
        "type":"DG","value": 1014,
        "label": "ACETAMINOPHEN AND TRAMADOL HCL"
    },
    {
        "type":"DG","value": 1015,
        "label": "ACETAMINOPHEN D PROPOXYPHENE DICYCLOMINE"
    },
    {
        "type":"DG","value": 1016,
        "label": "ACETAZOLAMIDE"
    },
    {
        "type":"DG","value": 1017,
        "label": "ACETYL CYSTIENE"
    },
    {
        "type":"DG","value": 1018,
        "label": "ACICLOVIR"
    },
    {
        "type":"DG","value": 1019,
        "label": "ACICLOVIR INTRAVENOUS"
    },
    {
        "type":"DG","value": 1020,
        "label": "ADEMETIONINE"
    },
    {
        "type":"DG","value": 1021,
        "label": "ADENOSINE"
    },
    {
        "type":"DG","value": 1022,
        "label": "ADFOVIR DIPIVOXIL"
    },
    {
        "type":"DG","value": 1023,
        "label": "ADO TRASTUZUMAB EMTANSINE"
    },
    {
        "type":"DG","value": 1024,
        "label": "ADRENALINE BITARTRATE"
    },
    {
        "type":"DG","value": 1025,
        "label": "ADRENOCHROM MONOSEMICARBZON MENADION SOD"
    },
    {
        "type":"DG","value": 1026,
        "label": "AGAR AND LIQUID PARAFFIN"
    },
    {
        "type":"DG","value": 1027,
        "label": "ALBENDAZOLE 400MG"
    },
    {
        "type":"DG","value": 1028,
        "label": "ALDESLEUKIN"
    },
    {
        "type":"DG","value": 1029,
        "label": "ALENDRONATE SODIUM"
    },
    {
        "type":"DG","value": 1030,
        "label": "ALFACALCIDOL"
    },
    {
        "type":"DG","value": 1031,
        "label": "ALFUZOSIN HCL"
    },
    {
        "type":"DG","value": 1032,
        "label": "all"
    },
    {
        "type":"DG","value": 1033,
        "label": "ALLOPURINOL"
    },
    {
        "type":"DG","value": 1034,
        "label": "ALOE VERA RUBIA CORDIFOLIA CHAMOMILLA"
    },
    {
        "type":"DG","value": 1035,
        "label": "ALPHA  BETA ARTEETHER"
    },
    {
        "type":"DG","value": 1036,
        "label": "ALPHA GALACTOSIDASE PAPAYA EXTRACTS"
    },
    {
        "type":"DG","value": 1037,
        "label": "ALPHALIPOIC ACID MINERALS VITAMINS"
    },
    {
        "type":"DG","value": 1038,
        "label": "ALPRAZOLAM"
    },
    {
        "type":"DG","value": 1039,
        "label": "ALPROCONTIN"
    },
    {
        "type":"DG","value": 1040,
        "label": "ALUMINA  MAGNESIA AND SIMETHICONE"
    },
    {
        "type":"DG","value": 1041,
        "label": "AMANTADINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1042,
        "label": "AMBROXOL HCL PSEUDOEPHEDRINE GUAIPHENESI"
    },
    {
        "type":"DG","value": 1043,
        "label": "AMBROXOL HCL SALBUTAMOL"
    },
    {
        "type":"DG","value": 1044,
        "label": "AMBROXOL HCL SR AND LEVOCETRIZINE DI HCL"
    },
    {
        "type":"DG","value": 1045,
        "label": "AMBROXOL HCL TERBUTALINE AND GUAIPHENESI"
    },
    {
        "type":"DG","value": 1046,
        "label": "AMBROXOL HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1047,
        "label": "AMIDRONE"
    },
    {
        "type":"DG","value": 1048,
        "label": "AMIFOSTINE"
    },
    {
        "type":"DG","value": 1049,
        "label": "AMIKACIN SULPHATE"
    },
    {
        "type":"DG","value": 1050,
        "label": "AMILORIDE HCL FUROSEMIDE"
    },
    {
        "type":"DG","value": 1051,
        "label": "AMINO ACID SOLUTION"
    },
    {
        "type":"DG","value": 1052,
        "label": "AMINO ACID SORBITOL WITH FAT EMULSION"
    },
    {
        "type":"DG","value": 1053,
        "label": "AMINO ACIDS  ELECTROLYTES DEXTROSE"
    },
    {
        "type":"DG","value": 1054,
        "label": "AMINO ACIDS AND SORBITOL"
    },
    {
        "type":"DG","value": 1055,
        "label": "AMINO ACIDS FOR PARENTERAL NUTRITION"
    },
    {
        "type":"DG","value": 1056,
        "label": "AMINOPHYLLINE"
    },
    {
        "type":"DG","value": 1057,
        "label": "AMITRYPTILINE HCL"
    },
    {
        "type":"DG","value": 1058,
        "label": "AMLODIPINE"
    },
    {
        "type":"DG","value": 1059,
        "label": "AMLODIPINE AND ATENOLOL"
    },
    {
        "type":"DG","value": 1060,
        "label": "AMLODIPINE AND LISINOPRIL"
    },
    {
        "type":"DG","value": 1061,
        "label": "AMLODIPINE BESILATE"
    },
    {
        "type":"DG","value": 1062,
        "label": "AMLODIPINE BESYLATE"
    },
    {
        "type":"DG","value": 1063,
        "label": "AMLODIPINE BESYLATE AND ATENOLOL"
    },
    {
        "type":"DG","value": 1064,
        "label": "AMLODIPINE BESYLATE ATENOLOL"
    },
    {
        "type":"DG","value": 1065,
        "label": "AMLODIPINE HYDROCHLOROTHIAZIDE"
    },
    {
        "type":"DG","value": 1066,
        "label": "AMORPHOUS HYDROGEL WOULD DRESSING"
    },
    {
        "type":"DG","value": 1067,
        "label": "AMOXICILLIN AND CLAVULANIC ACID"
    },
    {
        "type":"DG","value": 1068,
        "label": "AMOXICILLIN AND POTASSIUM CLAVULANATE"
    },
    {
        "type":"DG","value": 1069,
        "label": "AMOXYCILLIN"
    },
    {
        "type":"DG","value": 1070,
        "label": "AMOXYCILLIN 250MG AND CLOXACILLIN 250MG"
    },
    {
        "type":"DG","value": 1071,
        "label": "AMOXYCILLIN DICLOXACILLIN LACTO BACILLUS"
    },
    {
        "type":"DG","value": 1072,
        "label": "AMOXYCILLIN POTASSIUM CLAVUNATE"
    },
    {
        "type":"DG","value": 1073,
        "label": "AMOXYCILLIN TRIHYDRATE"
    },
    {
        "type":"DG","value": 1074,
        "label": "AMPHOTERICIN-B"
    },
    {
        "type":"DG","value": 1075,
        "label": "AMPICILLIN"
    },
    {
        "type":"DG","value": 1076,
        "label": "AMPICILLIN 125MG  CLOXACILLIN 125MG"
    },
    {
        "type":"DG","value": 1077,
        "label": "AMPICILLIN 250MG CLOXACILLIN 250MG"
    },
    {
        "type":"DG","value": 1078,
        "label": "AMPICILLIN AND SULBACTAM"
    },
    {
        "type":"DG","value": 1079,
        "label": "AMPICILLIN ORAL SUSPENSION"
    },
    {
        "type":"DG","value": 1080,
        "label": "AMYLASE AND PEPSIN"
    },
    {
        "type":"DG","value": 1081,
        "label": "ANASTROZOLE"
    },
    {
        "type":"DG","value": 1082,
        "label": "ANIDULAFUNGIN"
    },
    {
        "type":"DG","value": 1083,
        "label": "ANSTRAZOLE"
    },
    {
        "type":"DG","value": 1084,
        "label": "ANTI OXIDANT"
    },
    {
        "type":"DG","value": 1085,
        "label": "ANTIOXIDANTS VITAMINS MINERALS"
    },
    {
        "type":"DG","value": 1086,
        "label": "ANTIOXIDANTS WITH MULTIVITAMIN MINERALS"
    },
    {
        "type":"DG","value": 1087,
        "label": "APPETTITE STIMULATING TONIC"
    },
    {
        "type":"DG","value": 1088,
        "label": "APREPITANT"
    },
    {
        "type":"DG","value": 1089,
        "label": "ARSENIC TRIOXIDE"
    },
    {
        "type":"DG","value": 1090,
        "label": "ARTEETHER"
    },
    {
        "type":"DG","value": 1091,
        "label": "ARTESUNATE"
    },
    {
        "type":"DG","value": 1092,
        "label": "ARTESUNATE SULPHADOXINE PYRIMETHAMINE IP"
    },
    {
        "type":"DG","value": 1093,
        "label": "ASCORBIC ACID"
    },
    {
        "type":"DG","value": 1094,
        "label": "ASPIRIN DELAYED RELEASE"
    },
    {
        "type":"DG","value": 1095,
        "label": "ATENOLOL"
    },
    {
        "type":"DG","value": 1096,
        "label": "ATENOLOL AND AMLODIPINE"
    },
    {
        "type":"DG","value": 1097,
        "label": "ATENOLOL AND INDAPAMIDE"
    },
    {
        "type":"DG","value": 1098,
        "label": "ATORVASTATIN"
    },
    {
        "type":"DG","value": 1099,
        "label": "ATRACURIUM BESYLATE"
    },
    {
        "type":"DG","value": 1100,
        "label": "ATROPINE SULPHATE"
    },
    {
        "type":"DG","value": 1101,
        "label": "ATROVASTATIN ASPIRIN"
    },
    {
        "type":"DG","value": 1102,
        "label": "AXITINIB"
    },
    {
        "type":"DG","value": 1103,
        "label": "AYURVADIC EXTRACT"
    },
    {
        "type":"DG","value": 1104,
        "label": "AZACTIDINE"
    },
    {
        "type":"DG","value": 1105,
        "label": "AZITHROMYCIN"
    },
    {
        "type":"DG","value": 1106,
        "label": "AZTREONAM"
    },
    {
        "type":"DG","value": 1107,
        "label": "B COMPLEX"
    },
    {
        "type":"DG","value": 1108,
        "label": "B COMPLEX FOLIC ACID NIACINAMIDE"
    },
    {
        "type":"DG","value": 1109,
        "label": "B COMPLEX FORTE  VITAMIN C"
    },
    {
        "type":"DG","value": 1110,
        "label": "B COMPLEX VIT C  D PANTHENOL NIACINAMIDE"
    },
    {
        "type":"DG","value": 1111,
        "label": "B COMPLEX VITAMIN C A D E"
    },
    {
        "type":"DG","value": 1112,
        "label": "B COMPLEX WITH ZINC"
    },
    {
        "type":"DG","value": 1113,
        "label": "BACILLUS CALMETTE GUERIN BCG"
    },
    {
        "type":"DG","value": 1114,
        "label": "BACLOFEN"
    },
    {
        "type":"DG","value": 1115,
        "label": "BALOFLOXACIN"
    },
    {
        "type":"DG","value": 1116,
        "label": "BCG FOR IMMUNOTHERAPY"
    },
    {
        "type":"DG","value": 1117,
        "label": "BECLOMETHASONE AND LEVOSALBUTAMOL"
    },
    {
        "type":"DG","value": 1118,
        "label": "BECLOMETHASONE CLOTRIMAZOLE NEOMYCIN"
    },
    {
        "type":"DG","value": 1119,
        "label": "BENDAMUSTINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1120,
        "label": "BENFOTIAMINE"
    },
    {
        "type":"DG","value": 1121,
        "label": "BENZATHINE PENICILLIN"
    },
    {
        "type":"DG","value": 1122,
        "label": "BENZOCAINE"
    },
    {
        "type":"DG","value": 1123,
        "label": "BENZOXIUM CHLORIDE AND LIDOCAINE HCL"
    },
    {
        "type":"DG","value": 1124,
        "label": "BENZYDAMINE HCL"
    },
    {
        "type":"DG","value": 1125,
        "label": "BENZYLPENICILLIN SODIUM"
    },
    {
        "type":"DG","value": 1126,
        "label": "BETADINE"
    },
    {
        "type":"DG","value": 1127,
        "label": "BETAHISTINE HCL"
    },
    {
        "type":"DG","value": 1128,
        "label": "BETAMETHASONE AND CLIOQUINOL"
    },
    {
        "type":"DG","value": 1129,
        "label": "BETAMETHASONE CLOTRIMAZOLE NEOMYCINE"
    },
    {
        "type":"DG","value": 1130,
        "label": "BETAMETHASONE DIPROPIONATE"
    },
    {
        "type":"DG","value": 1131,
        "label": "BETAMETHASONE SODIUM"
    },
    {
        "type":"DG","value": 1132,
        "label": "BETAMETHASONE VALERATE"
    },
    {
        "type":"DG","value": 1133,
        "label": "BETAMETHASONE VALERATE AND NEOMYCIN"
    },
    {
        "type":"DG","value": 1134,
        "label": "BETAMETHASONE VALERATE NEOMYCIN"
    },
    {
        "type":"DG","value": 1135,
        "label": "BETHANACOL CHLORIDE"
    },
    {
        "type":"DG","value": 1136,
        "label": "BEVACIZUMAB"
    },
    {
        "type":"DG","value": 1137,
        "label": "BICALTUMIDE"
    },
    {
        "type":"DG","value": 1138,
        "label": "BICALUTAMIDE"
    },
    {
        "type":"DG","value": 1139,
        "label": "BIPHASIC ISOPHANE  AND SOLUBLE INSULIN"
    },
    {
        "type":"DG","value": 1140,
        "label": "BIPHASIC ISOPHANE INSULIN"
    },
    {
        "type":"DG","value": 1141,
        "label": "BISACODYL"
    },
    {
        "type":"DG","value": 1142,
        "label": "BISOPROLOL"
    },
    {
        "type":"DG","value": 1143,
        "label": "BISOPROLOL  FUMARATE  HYDROCHLOROTHIAZID"
    },
    {
        "type":"DG","value": 1144,
        "label": "BLEOMYCIN SULPHATE"
    },
    {
        "type":"DG","value": 1145,
        "label": "BORTEZOMIB POWDER"
    },
    {
        "type":"DG","value": 1146,
        "label": "BROMHEXINE HCL"
    },
    {
        "type":"DG","value": 1147,
        "label": "BROMHEXINE HCL TERBUTALIINE SUL GUAIPHEN"
    },
    {
        "type":"DG","value": 1148,
        "label": "BROMHEXN PHENYLEPINEPHRIN CHLORPHENIRAMI"
    },
    {
        "type":"DG","value": 1149,
        "label": "BROMOCRIPTINE"
    },
    {
        "type":"DG","value": 1150,
        "label": "BROMOHEXINE AND AMOXYCILLIN"
    },
    {
        "type":"DG","value": 1151,
        "label": "BROMOHEXINE GUAIPHENESIN PHENYLEPHRINE"
    },
    {
        "type":"DG","value": 1152,
        "label": "BROMOHEXINE HCL GUAIPHENESIN AND CPM"
    },
    {
        "type":"DG","value": 1153,
        "label": "BUCLIZINE HCL"
    },
    {
        "type":"DG","value": 1154,
        "label": "BUDESONIDE"
    },
    {
        "type":"DG","value": 1155,
        "label": "BUPIVACAINE"
    },
    {
        "type":"DG","value": 1156,
        "label": "BUPIVACAINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1157,
        "label": "BUPRENORPHINE HCL"
    },
    {
        "type":"DG","value": 1158,
        "label": "BUPRENORPHINE TRANSDERMAL PATCH"
    },
    {
        "type":"DG","value": 1159,
        "label": "BUSULFAN"
    },
    {
        "type":"DG","value": 1160,
        "label": "BUTORPHANOL TARTRATE"
    },
    {
        "type":"DG","value": 1161,
        "label": "CA CITRATE MG HYDROXID ZN SULPHAT VITD3"
    },
    {
        "type":"DG","value": 1162,
        "label": "CA CITRATE VITD3 MG ZINC MINERALS"
    },
    {
        "type":"DG","value": 1163,
        "label": "CABAZITAXEL"
    },
    {
        "type":"DG","value": 1164,
        "label": "CABERGOLINE"
    },
    {
        "type":"DG","value": 1165,
        "label": "CAL CITRATE FRUCTOLIGOSACCHARIDES VIT"
    },
    {
        "type":"DG","value": 1166,
        "label": "CAL CITRATE MALEATE CALCITROL"
    },
    {
        "type":"DG","value": 1167,
        "label": "CAL GLUCONATE CAL LACTOBIONATE"
    },
    {
        "type":"DG","value": 1168,
        "label": "CALAMINE"
    },
    {
        "type":"DG","value": 1169,
        "label": "CALCITONIN"
    },
    {
        "type":"DG","value": 1170,
        "label": "CALCITROL"
    },
    {
        "type":"DG","value": 1171,
        "label": "CALCITROL CA CARBONATE ZINC SULPHATE"
    },
    {
        "type":"DG","value": 1172,
        "label": "CALCIUM C VITAMIN D3"
    },
    {
        "type":"DG","value": 1173,
        "label": "CALCIUM CARBONATE  CALCITRIOL AND ZINC"
    },
    {
        "type":"DG","value": 1174,
        "label": "CALCIUM CHOLECALCIFEROL"
    },
    {
        "type":"DG","value": 1175,
        "label": "CALCIUM CITRATE MALEATE CALCITROLANDZINC"
    },
    {
        "type":"DG","value": 1176,
        "label": "CALCIUM CITRATE MALETE VITAMIN D3 CHEWAB"
    },
    {
        "type":"DG","value": 1177,
        "label": "CALCIUM CITRATE VITAMIN D3 MAGNESIU ZINC"
    },
    {
        "type":"DG","value": 1178,
        "label": "CALCIUM DOBESILATE  DOCUSATE SODIUM"
    },
    {
        "type":"DG","value": 1179,
        "label": "CALCIUM DOBESILATE LIGNOCAINE HYDROCORT"
    },
    {
        "type":"DG","value": 1180,
        "label": "CALCIUM FOLINATE"
    },
    {
        "type":"DG","value": 1181,
        "label": "CALCIUM GLUCONATE"
    },
    {
        "type":"DG","value": 1182,
        "label": "CALCIUM IRON FOLIC ACID"
    },
    {
        "type":"DG","value": 1183,
        "label": "CALCIUM IRON VITAMIN"
    },
    {
        "type":"DG","value": 1184,
        "label": "CALCIUM OROTATE MAGNESIUM AND VIT D3"
    },
    {
        "type":"DG","value": 1185,
        "label": "CALCIUM POLYSTERENE SULPHONATE"
    },
    {
        "type":"DG","value": 1186,
        "label": "CALCIUM VITD3  ZINC MANGNESIUMOXIDE Mn"
    },
    {
        "type":"DG","value": 1187,
        "label": "CALCIUM WITH SOY ISOFLAVONE  AND IPROFLA"
    },
    {
        "type":"DG","value": 1188,
        "label": "CALCIUM WITH VITAMIN D"
    },
    {
        "type":"DG","value": 1189,
        "label": "CALCIUM WITH VITAMIND3 AND MINERALS"
    },
    {
        "type":"DG","value": 1190,
        "label": "CAMPHOR CHLORTHYMOL EUCALYPTUS MENTHOL"
    },
    {
        "type":"DG","value": 1191,
        "label": "CAMULOFIN DIHYDROCHLORIDE DICLOFENAC Na"
    },
    {
        "type":"DG","value": 1192,
        "label": "CAMYLOFIN DIHYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1193,
        "label": "CAMYLOFIN DIHYDROCHLORIDE DICLOFENAC"
    },
    {
        "type":"DG","value": 1194,
        "label": "CAMYLOFIN DIHYDROCHLORIDE NIMESULIDE"
    },
    {
        "type":"DG","value": 1195,
        "label": "CAMYLOFIN DIHYDROCHLORIDE PARACETAMOL"
    },
    {
        "type":"DG","value": 1196,
        "label": "CAPECITABINE"
    },
    {
        "type":"DG","value": 1197,
        "label": "CARBAMZEPINE"
    },
    {
        "type":"DG","value": 1198,
        "label": "CARBIMAZOLE"
    },
    {
        "type":"DG","value": 1199,
        "label": "CARBOCISTEIUNE"
    },
    {
        "type":"DG","value": 1200,
        "label": "CARBOHYDRATES MINERALS ZINC LACTIC ACID"
    },
    {
        "type":"DG","value": 1201,
        "label": "CARBONYL IRON  ZINC  AND FOLIC ACID"
    },
    {
        "type":"DG","value": 1202,
        "label": "CARBOPLATIN"
    },
    {
        "type":"DG","value": 1203,
        "label": "CARBOPROST TROMETHAMINE"
    },
    {
        "type":"DG","value": 1204,
        "label": "CARMUSTIN"
    },
    {
        "type":"DG","value": 1205,
        "label": "CARMUSTINE"
    },
    {
        "type":"DG","value": 1206,
        "label": "CAROTENOIDS AND LYCOPENE"
    },
    {
        "type":"DG","value": 1207,
        "label": "CAROTENOIDS ANTIOXIDANTS VITS MINERALS"
    },
    {
        "type":"DG","value": 1208,
        "label": "CARROT EXTRACT BETA CAROTIN VIT C E ZINC"
    },
    {
        "type":"DG","value": 1209,
        "label": "CARVEDILOL"
    },
    {
        "type":"DG","value": 1210,
        "label": "CASPOFUNGIN ACETATE"
    },
    {
        "type":"DG","value": 1211,
        "label": "CEFADROXIL"
    },
    {
        "type":"DG","value": 1212,
        "label": "CEFADROXIL AND CLAVUNATE"
    },
    {
        "type":"DG","value": 1213,
        "label": "CEFAPODOXIME PROXETIL"
    },
    {
        "type":"DG","value": 1214,
        "label": "CEFAZOLIN"
    },
    {
        "type":"DG","value": 1215,
        "label": "CEFAZOLINE"
    },
    {
        "type":"DG","value": 1216,
        "label": "CEFDINIR"
    },
    {
        "type":"DG","value": 1217,
        "label": "CEFDITOREN PIVOXIL"
    },
    {
        "type":"DG","value": 1218,
        "label": "CEFEPIME"
    },
    {
        "type":"DG","value": 1219,
        "label": "CEFEPIME 1GM AND TAZOBACTAM 125MG"
    },
    {
        "type":"DG","value": 1220,
        "label": "CEFEPIME AND TAZOBACTUM"
    },
    {
        "type":"DG","value": 1221,
        "label": "CEFETAMED PIVOXIL"
    },
    {
        "type":"DG","value": 1222,
        "label": "CEFETAMED PIVOXIL CLAVULANIC ACID"
    },
    {
        "type":"DG","value": 1223,
        "label": "CEFIXIME"
    },
    {
        "type":"DG","value": 1224,
        "label": "CEFIXIME AND AZITHROMYCIN"
    },
    {
        "type":"DG","value": 1225,
        "label": "CEFIXIME AND CLOXACILLIN"
    },
    {
        "type":"DG","value": 1226,
        "label": "CEFIXIME AND LINEZOLID"
    },
    {
        "type":"DG","value": 1227,
        "label": "CEFIXIME AND OFLOXACIN"
    },
    {
        "type":"DG","value": 1228,
        "label": "CEFIXIME AND ORNIDAZOLE"
    },
    {
        "type":"DG","value": 1229,
        "label": "CEFIXIME DICLOXACILLIN LACTIC ACID"
    },
    {
        "type":"DG","value": 1230,
        "label": "CEFOPERAZONE AND TAZOBACTAM"
    },
    {
        "type":"DG","value": 1231,
        "label": "CEFOPERAZONE SOD"
    },
    {
        "type":"DG","value": 1232,
        "label": "CEFOPERAZONE SULBACTAM"
    },
    {
        "type":"DG","value": 1233,
        "label": "CEFOPERAZONE WITH SULBACTAM"
    },
    {
        "type":"DG","value": 1234,
        "label": "CEFOTAXIME"
    },
    {
        "type":"DG","value": 1235,
        "label": "CEFOTAXINE AND SULBACTAN"
    },
    {
        "type":"DG","value": 1236,
        "label": "CEFPIROME"
    },
    {
        "type":"DG","value": 1237,
        "label": "CEFPIROME SULFATE"
    },
    {
        "type":"DG","value": 1238,
        "label": "CEFTAZIDIME"
    },
    {
        "type":"DG","value": 1239,
        "label": "CEFTAZIDIME AND TAZOBACTAM"
    },
    {
        "type":"DG","value": 1240,
        "label": "CEFTIZOXIME"
    },
    {
        "type":"DG","value": 1241,
        "label": "CEFTRIAXONE"
    },
    {
        "type":"DG","value": 1242,
        "label": "CEFTRIAXONE AND SULBACTAM"
    },
    {
        "type":"DG","value": 1243,
        "label": "CEFTRIAXONE AND TAZOBACTAM"
    },
    {
        "type":"DG","value": 1244,
        "label": "CEFTRIAXONE AND VANCOMYCIN"
    },
    {
        "type":"DG","value": 1245,
        "label": "CEFUROXIME"
    },
    {
        "type":"DG","value": 1246,
        "label": "CEFUROXIME AND POTASSIUM CLAVULANATE"
    },
    {
        "type":"DG","value": 1247,
        "label": "CEFUROXIME AXETIL   POT CLAVUNATE"
    },
    {
        "type":"DG","value": 1248,
        "label": "CEFUROXIME SODIUM"
    },
    {
        "type":"DG","value": 1249,
        "label": "CEFUROXIME TRIHYDRADE"
    },
    {
        "type":"DG","value": 1250,
        "label": "CELECOXIB"
    },
    {
        "type":"DG","value": 1251,
        "label": "CEPAE HEPARIN SODIUM AND ALLANTOIN"
    },
    {
        "type":"DG","value": 1252,
        "label": "CEPHALEXIN"
    },
    {
        "type":"DG","value": 1253,
        "label": "CETIRIZINE"
    },
    {
        "type":"DG","value": 1254,
        "label": "CETIRIZINE HCL AMBROXOL HCL"
    },
    {
        "type":"DG","value": 1255,
        "label": "CETIRIZINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1256,
        "label": "CETIRIZINE HYDROCHLORIDE PHENYLPROPANOLA"
    },
    {
        "type":"DG","value": 1257,
        "label": "CETRIZINE HCL AND AMBROXOL HCL"
    },
    {
        "type":"DG","value": 1258,
        "label": "CETUXIMAB"
    },
    {
        "type":"DG","value": 1259,
        "label": "CHLORAMBUCIL"
    },
    {
        "type":"DG","value": 1260,
        "label": "CHLORDIAZEPOXIDE"
    },
    {
        "type":"DG","value": 1261,
        "label": "CHLORHEXIDINE"
    },
    {
        "type":"DG","value": 1262,
        "label": "CHLORHEXIDINE GAUZE"
    },
    {
        "type":"DG","value": 1263,
        "label": "CHLOROQUINE PHOSPHATE"
    },
    {
        "type":"DG","value": 1264,
        "label": "CHLORPHENIRAMINE MELEATE AND CODEINE PH"
    },
    {
        "type":"DG","value": 1265,
        "label": "CHLORPHENIRAMNE MELEATE DEXTROMETHORPHEN"
    },
    {
        "type":"DG","value": 1266,
        "label": "CHLORPROMAZINE HCL"
    },
    {
        "type":"DG","value": 1267,
        "label": "CHOLECALCIFEROL CHEWABLE"
    },
    {
        "type":"DG","value": 1268,
        "label": "CHOLECALCIFEROL GRANULES"
    },
    {
        "type":"DG","value": 1269,
        "label": "CHOLINE SALICYLATE AND BENZALKONIUM CHLO"
    },
    {
        "type":"DG","value": 1270,
        "label": "CINNARIZINE"
    },
    {
        "type":"DG","value": 1271,
        "label": "CIPROFLOXACIN"
    },
    {
        "type":"DG","value": 1272,
        "label": "CIPROFLOXACIN 500MG AND ORNIDAZOLE 500MG"
    },
    {
        "type":"DG","value": 1273,
        "label": "CIPROFLOXACIN 500MG TINIDAZOLE 600MG"
    },
    {
        "type":"DG","value": 1274,
        "label": "CIPROFLOXACIN AND ORNIDAZOLE"
    },
    {
        "type":"DG","value": 1275,
        "label": "CIPROFLOXACIN DEXAMETHASONE"
    },
    {
        "type":"DG","value": 1276,
        "label": "CIRIZOTINIB"
    },
    {
        "type":"DG","value": 1277,
        "label": "CISAPRIDE"
    },
    {
        "type":"DG","value": 1278,
        "label": "CISAPRIDE AND METHYL POLYSILOXANE"
    },
    {
        "type":"DG","value": 1279,
        "label": "CISPLATIN"
    },
    {
        "type":"DG","value": 1280,
        "label": "CITICOLINE"
    },
    {
        "type":"DG","value": 1281,
        "label": "CLADRIBINE"
    },
    {
        "type":"DG","value": 1282,
        "label": "CLARITHROMYCIN"
    },
    {
        "type":"DG","value": 1283,
        "label": "CLARITHROMYCIN LACTOBIONATE"
    },
    {
        "type":"DG","value": 1284,
        "label": "CLINDAMYCIN"
    },
    {
        "type":"DG","value": 1285,
        "label": "CLINDAMYCIN HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1286,
        "label": "CLITRIMAZOLE AND BECLOMETHASONE"
    },
    {
        "type":"DG","value": 1287,
        "label": "CLOBAZAM"
    },
    {
        "type":"DG","value": 1288,
        "label": "CLONAZEPAM"
    },
    {
        "type":"DG","value": 1289,
        "label": "CLONIDINE"
    },
    {
        "type":"DG","value": 1290,
        "label": "CLONIDINE HCL"
    },
    {
        "type":"DG","value": 1291,
        "label": "CLONIDINE HYDROCHLORIDE HYDROCHLOROTHIAZ"
    },
    {
        "type":"DG","value": 1292,
        "label": "CLOPIDAGRE"
    },
    {
        "type":"DG","value": 1293,
        "label": "CLOPIDOGREL"
    },
    {
        "type":"DG","value": 1294,
        "label": "CLOPIDOGREL AND ASPIRIN"
    },
    {
        "type":"DG","value": 1295,
        "label": "CLOTRIMAZOLE"
    },
    {
        "type":"DG","value": 1296,
        "label": "CLOTRIMAZOLE  BECLOMETHASONE"
    },
    {
        "type":"DG","value": 1297,
        "label": "CLOTRIMAZOLE  LIGNOCAINE"
    },
    {
        "type":"DG","value": 1298,
        "label": "CLOTRIMAZOLE BECLOMETHASONE NEOMYCIN"
    },
    {
        "type":"DG","value": 1299,
        "label": "CLOTRIMAZOLE LOZENGES"
    },
    {
        "type":"DG","value": 1300,
        "label": "CODEINE PHOSPHATE CHLORPHENIRAMINE MALEA"
    },
    {
        "type":"DG","value": 1301,
        "label": "CODEINE SULFATE"
    },
    {
        "type":"DG","value": 1302,
        "label": "COLISTIMETHATE SODIUM"
    },
    {
        "type":"DG","value": 1303,
        "label": "COLLOIDAL IODINE"
    },
    {
        "type":"DG","value": 1304,
        "label": "COLOSTRUM SACCHAROMYCES BOULARDI"
    },
    {
        "type":"DG","value": 1305,
        "label": "COMPOUND BENZOIC ACID"
    },
    {
        "type":"DG","value": 1306,
        "label": "CONJUGATED ESTROGENS"
    },
    {
        "type":"DG","value": 1307,
        "label": "coppersulpate"
    },
    {
        "type":"DG","value": 1308,
        "label": "COTRIMOXAZOLE"
    },
    {
        "type":"DG","value": 1309,
        "label": "COUGH LOZENGES"
    },
    {
        "type":"DG","value": 1310,
        "label": "CYCLOPHOSPHAMIDE"
    },
    {
        "type":"DG","value": 1311,
        "label": "CYCLOPHOSPHOMIDE"
    },
    {
        "type":"DG","value": 1312,
        "label": "CYCLOSPORINE"
    },
    {
        "type":"DG","value": 1313,
        "label": "CYPROHEPTADINE HCL"
    },
    {
        "type":"DG","value": 1314,
        "label": "CYPROHEPTADINE HCL TRICHOLINE SORBITOL"
    },
    {
        "type":"DG","value": 1315,
        "label": "CYTARABINE"
    },
    {
        "type":"DG","value": 1316,
        "label": "D MANNOSE CRANBERRY  HIBISCUS"
    },
    {
        "type":"DG","value": 1317,
        "label": "D METHORPHINE PHENYLEPHRINE CPM GUAIPHEN"
    },
    {
        "type":"DG","value": 1318,
        "label": "DACARBAZINE"
    },
    {
        "type":"DG","value": 1319,
        "label": "DACTINOMYCIN"
    },
    {
        "type":"DG","value": 1320,
        "label": "DALTEPARIN SODIUM"
    },
    {
        "type":"DG","value": 1321,
        "label": "DANAZOL"
    },
    {
        "type":"DG","value": 1322,
        "label": "DAPTOMYCIN"
    },
    {
        "type":"DG","value": 1323,
        "label": "DARBEPOETIN ALFA"
    },
    {
        "type":"DG","value": 1324,
        "label": "DASATINIB"
    },
    {
        "type":"DG","value": 1325,
        "label": "DAUNORUBICIN"
    },
    {
        "type":"DG","value": 1326,
        "label": "DECITABINE"
    },
    {
        "type":"DG","value": 1327,
        "label": "DEFLAZACORT"
    },
    {
        "type":"DG","value": 1328,
        "label": "DEGARELIX"
    },
    {
        "type":"DG","value": 1329,
        "label": "DENOSUMAB"
    },
    {
        "type":"DG","value": 1330,
        "label": "DEXAMETHASONE"
    },
    {
        "type":"DG","value": 1331,
        "label": "DEXAMETHORPHAN HCL TRIPROLIDINE PHENYLEP"
    },
    {
        "type":"DG","value": 1332,
        "label": "DEXMEDETOMIDINE"
    },
    {
        "type":"DG","value": 1333,
        "label": "DEXOMETHORPHAN AND CPM"
    },
    {
        "type":"DG","value": 1334,
        "label": "DEXTRAN 40"
    },
    {
        "type":"DG","value": 1335,
        "label": "DEXTRAN 40 IN NACL"
    },
    {
        "type":"DG","value": 1336,
        "label": "DEXTRO METHORPHAN HYDROBROMIDE"
    },
    {
        "type":"DG","value": 1337,
        "label": "DEXTROMETHORPHAN  TRIPROLIDINE  PHENYLE"
    },
    {
        "type":"DG","value": 1338,
        "label": "DEXTROMETHORPHAN HBR  CPM AND GUAIPHENES"
    },
    {
        "type":"DG","value": 1339,
        "label": "DEXTROMETHORPHAN HBR AMYLMETACRESOLE"
    },
    {
        "type":"DG","value": 1340,
        "label": "DEXTROMETHORPHAN HYDROBROMIDE TRIPROLIDI"
    },
    {
        "type":"DG","value": 1341,
        "label": "DEXTROMETHORPHAN PHENYLEPHRINE CETIRIZIN"
    },
    {
        "type":"DG","value": 1342,
        "label": "DEXTROMETHORPHAN PHENYLEPHRINE CPM"
    },
    {
        "type":"DG","value": 1343,
        "label": "DIASTASE PEPSIN"
    },
    {
        "type":"DG","value": 1344,
        "label": "DIATRIZOATE MEGLUMINE"
    },
    {
        "type":"DG","value": 1345,
        "label": "DIAZEPAM"
    },
    {
        "type":"DG","value": 1346,
        "label": "DICLOFENAC"
    },
    {
        "type":"DG","value": 1347,
        "label": "DICLOFENAC DIETHYAMINE"
    },
    {
        "type":"DG","value": 1348,
        "label": "DICLOFENAC DIETHYLAMMONIUM DICLOFENAC"
    },
    {
        "type":"DG","value": 1349,
        "label": "DICLOFENAC NA AND SERRATIOPEPTIDASE"
    },
    {
        "type":"DG","value": 1350,
        "label": "DICLOFENAC NA PARACETAMOL CHLORZOXAZONE"
    },
    {
        "type":"DG","value": 1351,
        "label": "DICLOFENAC POTASSIUM"
    },
    {
        "type":"DG","value": 1352,
        "label": "DICLOFENAC POTASSIUM AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1353,
        "label": "DICLOFENAC SOD PARACETOMOL"
    },
    {
        "type":"DG","value": 1354,
        "label": "DICLOFENAC SODIUM"
    },
    {
        "type":"DG","value": 1355,
        "label": "DICLOFENAC TRANSDERMAL PATCH"
    },
    {
        "type":"DG","value": 1356,
        "label": "DICLOFENAM SODIUM SUSTAINED RELEASE"
    },
    {
        "type":"DG","value": 1357,
        "label": "DICYCLOMINE HCL AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1358,
        "label": "DICYCLOMINE HCL AND SIMETHICONE"
    },
    {
        "type":"DG","value": 1359,
        "label": "DICYCLOMINE HCL ETHYLMORPHINE HCL"
    },
    {
        "type":"DG","value": 1360,
        "label": "DICYCLOMINE PROPOXYPHN NAPSYLT ACETAMINO"
    },
    {
        "type":"DG","value": 1361,
        "label": "DIETARY SUPLEMENT"
    },
    {
        "type":"DG","value": 1362,
        "label": "DIETHYL CARBAMAZINE CITRATE"
    },
    {
        "type":"DG","value": 1363,
        "label": "DIETHYLAMMONIUM SALT"
    },
    {
        "type":"DG","value": 1364,
        "label": "DIETHYLCARBAMAZINE"
    },
    {
        "type":"DG","value": 1365,
        "label": "DIGESTIVE ENZYMES"
    },
    {
        "type":"DG","value": 1366,
        "label": "DIGOXIN"
    },
    {
        "type":"DG","value": 1367,
        "label": "DILTIAZEM"
    },
    {
        "type":"DG","value": 1368,
        "label": "DILTIAZEM HCL"
    },
    {
        "type":"DG","value": 1369,
        "label": "DILTIAZEM HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1370,
        "label": "DIMETHICONE MAG HYDROXIDE AND ALU HYDROX"
    },
    {
        "type":"DG","value": 1371,
        "label": "DIMETHICONE MGOH DRIED ALOH MG ALSILICAT"
    },
    {
        "type":"DG","value": 1372,
        "label": "DIMETHINDENE MALEATE"
    },
    {
        "type":"DG","value": 1373,
        "label": "DINOPROSTONE"
    },
    {
        "type":"DG","value": 1374,
        "label": "DIPHENHYDRAMINE HCL TERPINE HYDRATE AMMO"
    },
    {
        "type":"DG","value": 1375,
        "label": "DIPHENOXYLATE HCL ATROPINE SULPHATE"
    },
    {
        "type":"DG","value": 1376,
        "label": "DISODIUM FYDROGEN CITRATE"
    },
    {
        "type":"DG","value": 1377,
        "label": "dispersable diclofenac"
    },
    {
        "type":"DG","value": 1378,
        "label": "DIVALPROEX SODIUM DELAYED RELEASE"
    },
    {
        "type":"DG","value": 1379,
        "label": "DOBUTAMINE"
    },
    {
        "type":"DG","value": 1380,
        "label": "DOCETAXEL"
    },
    {
        "type":"DG","value": 1381,
        "label": "DOMPERIDONE"
    },
    {
        "type":"DG","value": 1382,
        "label": "DOMPERIDONE AND OMEPRAZOLE"
    },
    {
        "type":"DG","value": 1383,
        "label": "DOPAMINE HCL"
    },
    {
        "type":"DG","value": 1384,
        "label": "DORIPENEM"
    },
    {
        "type":"DG","value": 1385,
        "label": "dothiepin hcl or DOSULEPIN"
    },
    {
        "type":"DG","value": 1386,
        "label": "DOXIFLURIDINE 200MG."
    },
    {
        "type":"DG","value": 1387,
        "label": "DOXOFYLLINE"
    },
    {
        "type":"DG","value": 1388,
        "label": "DOXORUBICIN"
    },
    {
        "type":"DG","value": 1389,
        "label": "DOXORUBICIN  HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1390,
        "label": "DOXORUBICIN (LIPOSOMAL)"
    },
    {
        "type":"DG","value": 1391,
        "label": "DOXYCYCLINE"
    },
    {
        "type":"DG","value": 1392,
        "label": "DOXYCYCLINE AND LACTIC ACID BACILLUS"
    },
    {
        "type":"DG","value": 1393,
        "label": "DOXYCYCLINE HYCLATE"
    },
    {
        "type":"DG","value": 1394,
        "label": "DOXYLAMINE SUCCINATE PYRIDOXINE HCL"
    },
    {
        "type":"DG","value": 1395,
        "label": "DRIED ALUMINIUM HYDROXIDE MAGNESIUM TRIS"
    },
    {
        "type":"DG","value": 1396,
        "label": "DULCOLOX"
    },
    {
        "type":"DG","value": 1397,
        "label": "DUTASERIDE AND TAMSULOSIN HCL"
    },
    {
        "type":"DG","value": 1398,
        "label": "DUTASTERID AND TAMSULOSIN HCL"
    },
    {
        "type":"DG","value": 1399,
        "label": "EFAVIRENZ  EMTRICITABINE AND TENOFOVIR"
    },
    {
        "type":"DG","value": 1400,
        "label": "EICASAPENTANOIC ACID DOCASOHEXANOIC ACID"
    },
    {
        "type":"DG","value": 1401,
        "label": "EICOSAPENTANOIC ACID DOCOSAHEXANOIC ACID"
    },
    {
        "type":"DG","value": 1402,
        "label": "ELEMENTAL CALCIUM 500MG AND VIT D3 250IU"
    },
    {
        "type":"DG","value": 1403,
        "label": "ELTROMBOPAG OLAMINE"
    },
    {
        "type":"DG","value": 1404,
        "label": "ENAPRIL MALEATE"
    },
    {
        "type":"DG","value": 1405,
        "label": "ENOXAPARIN SODIUM"
    },
    {
        "type":"DG","value": 1406,
        "label": "EPIRUBICIN"
    },
    {
        "type":"DG","value": 1407,
        "label": "EPOETIN BETA"
    },
    {
        "type":"DG","value": 1408,
        "label": "ERIBULIN SOLUTION"
    },
    {
        "type":"DG","value": 1409,
        "label": "ERLOTINIB"
    },
    {
        "type":"DG","value": 1410,
        "label": "ERTAPENEM"
    },
    {
        "type":"DG","value": 1411,
        "label": "ERYTHROMYCIN ESTOLATE"
    },
    {
        "type":"DG","value": 1412,
        "label": "ERYTHROPOIETIN"
    },
    {
        "type":"DG","value": 1413,
        "label": "ERYTHROPOLETIN ALPHA"
    },
    {
        "type":"DG","value": 1414,
        "label": "ESCITALOPRAM OXALATE"
    },
    {
        "type":"DG","value": 1415,
        "label": "ESCITALOPRAM OXALATE AND CLONAZEPAM"
    },
    {
        "type":"DG","value": 1416,
        "label": "ESMOLOL HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1417,
        "label": "ESOMEPRAZOLE"
    },
    {
        "type":"DG","value": 1418,
        "label": "ESOMEPRAZOLE DOMPERADONE"
    },
    {
        "type":"DG","value": 1419,
        "label": "ESSENTIAL AMINO ACIDS VITAMINS METHYLCOB"
    },
    {
        "type":"DG","value": 1420,
        "label": "ESTRAMUSTINE PHOSPHATE 140MG."
    },
    {
        "type":"DG","value": 1421,
        "label": "ESTRIOL"
    },
    {
        "type":"DG","value": 1422,
        "label": "ETAMBUTOL HCL"
    },
    {
        "type":"DG","value": 1423,
        "label": "ETAMSYLATE"
    },
    {
        "type":"DG","value": 1424,
        "label": "ETAMSYLATE AND TRANEXAMIC ACID"
    },
    {
        "type":"DG","value": 1425,
        "label": "ETHAMBUTOL HCL"
    },
    {
        "type":"DG","value": 1426,
        "label": "ETHAMBUTOL ISONIAZIDE RIFAMPICIN"
    },
    {
        "type":"DG","value": 1427,
        "label": "ETHIONAMIDE"
    },
    {
        "type":"DG","value": 1428,
        "label": "ETHMBUTL RIFAMPICN ISONIAZD PYRIZINAMID"
    },
    {
        "type":"DG","value": 1429,
        "label": "ETIOPHYLLIN AND THEOPHYLLIN SUSTAINED RE"
    },
    {
        "type":"DG","value": 1430,
        "label": "ETOFYLLIN AND THEOPHYLLIN"
    },
    {
        "type":"DG","value": 1431,
        "label": "ETOFYLLINE AND THEOPHYLLINE"
    },
    {
        "type":"DG","value": 1432,
        "label": "ETOMIDATE EMULSION"
    },
    {
        "type":"DG","value": 1433,
        "label": "ETOPOSIDE"
    },
    {
        "type":"DG","value": 1434,
        "label": "EUPHORBIA PROSTRATA DRYEXTRACTETHANOLIC"
    },
    {
        "type":"DG","value": 1435,
        "label": "EVEROLIMUS"
    },
    {
        "type":"DG","value": 1436,
        "label": "EXEMESTANE"
    },
    {
        "type":"DG","value": 1437,
        "label": "FACTOR VII"
    },
    {
        "type":"DG","value": 1438,
        "label": "FAMCICLOVIR"
    },
    {
        "type":"DG","value": 1439,
        "label": "FAMOTIDINE"
    },
    {
        "type":"DG","value": 1440,
        "label": "FAROPENEM"
    },
    {
        "type":"DG","value": 1441,
        "label": "FEBUXOSTAL"
    },
    {
        "type":"DG","value": 1442,
        "label": "FENTANYL"
    },
    {
        "type":"DG","value": 1443,
        "label": "FERACRYLUM"
    },
    {
        "type":"DG","value": 1444,
        "label": "FERRIC CARBOXYMALTOSE"
    },
    {
        "type":"DG","value": 1445,
        "label": "FERRIC HYDROXIDE POLYMALTOSE FOLIC ACID"
    },
    {
        "type":"DG","value": 1446,
        "label": "FERROUS  AND ZINC BIGLYCINATE FOLIC ACID"
    },
    {
        "type":"DG","value": 1447,
        "label": "FERROUS ASCORBATE AND FOLIC ACID"
    },
    {
        "type":"DG","value": 1448,
        "label": "FERROUS ASCORBATE FOLIC ACID"
    },
    {
        "type":"DG","value": 1449,
        "label": "FERROUS FUMARATE AND VITAMINB12 AND FOLI"
    },
    {
        "type":"DG","value": 1450,
        "label": "FERROUS FUMARATE FOLIC ACID ZINC SULPHAT"
    },
    {
        "type":"DG","value": 1451,
        "label": "FERROUS SUL FOLIC ACID ZINC B6 B12"
    },
    {
        "type":"DG","value": 1452,
        "label": "FERROUS SULPHATE FOLIC ACID"
    },
    {
        "type":"DG","value": 1453,
        "label": "FEXOFENADINE HCL AND MONTELUKAST"
    },
    {
        "type":"DG","value": 1454,
        "label": "FEXOFENADINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1455,
        "label": "FILGRASTIM"
    },
    {
        "type":"DG","value": 1456,
        "label": "FILGRASTIM RECOMBINANTHUMAN GRANULOCYTE"
    },
    {
        "type":"DG","value": 1457,
        "label": "FINASTERIDE"
    },
    {
        "type":"DG","value": 1458,
        "label": "FLAVOXATE HCL OFLOXACIN"
    },
    {
        "type":"DG","value": 1459,
        "label": "FLUCANOZOLE"
    },
    {
        "type":"DG","value": 1460,
        "label": "FLUDARABINE"
    },
    {
        "type":"DG","value": 1461,
        "label": "FLUDARABINE PHOSPHATE"
    },
    {
        "type":"DG","value": 1462,
        "label": "FLUNARIZINE DIHYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1463,
        "label": "FLUOROMETHOLONE"
    },
    {
        "type":"DG","value": 1464,
        "label": "FLUOROURACIL"
    },
    {
        "type":"DG","value": 1465,
        "label": "FLUOXETINE"
    },
    {
        "type":"DG","value": 1466,
        "label": "FLUPIRTINE MALEATE"
    },
    {
        "type":"DG","value": 1467,
        "label": "FLUTAMIDE"
    },
    {
        "type":"DG","value": 1468,
        "label": "FLUTICASONE PROPIONATE"
    },
    {
        "type":"DG","value": 1469,
        "label": "FLUTICASONE PROPIONATE BENZALKONIUM CHLO"
    },
    {
        "type":"DG","value": 1470,
        "label": "FLUTICASONE PROPIONATR AND MUPIROCIN"
    },
    {
        "type":"DG","value": 1471,
        "label": "FLUVESTRANT"
    },
    {
        "type":"DG","value": 1472,
        "label": "FOLIC ACID"
    },
    {
        "type":"DG","value": 1473,
        "label": "FONDAPARINUX SODIUM"
    },
    {
        "type":"DG","value": 1474,
        "label": "FORMOTEROL FUMARATE BUDESONIDE"
    },
    {
        "type":"DG","value": 1475,
        "label": "FORMOTEROL FUMARATE FLUTICASONE PROPIONA"
    },
    {
        "type":"DG","value": 1476,
        "label": "FORTIFIED MICRONUTRIENTS"
    },
    {
        "type":"DG","value": 1477,
        "label": "FOSAPREPITANT DIMEGLUMINE"
    },
    {
        "type":"DG","value": 1478,
        "label": "FOSCAL WITH ISOFLAVONES IPRIFLAVONES"
    },
    {
        "type":"DG","value": 1479,
        "label": "FOSPHENYTOIN SODIUM"
    },
    {
        "type":"DG","value": 1480,
        "label": "FOSTESTROL"
    },
    {
        "type":"DG","value": 1481,
        "label": "FRAMYCETIN DEXAMETHASONE AND GRAMICIDIN"
    },
    {
        "type":"DG","value": 1482,
        "label": "FRAMYCETIN SULPHATE"
    },
    {
        "type":"DG","value": 1483,
        "label": "FRUSEMIDE"
    },
    {
        "type":"DG","value": 1484,
        "label": "FUNGAL DIASTASE AND PEPSIN"
    },
    {
        "type":"DG","value": 1485,
        "label": "FURAZOLIDINE"
    },
    {
        "type":"DG","value": 1486,
        "label": "FURAZOLIDONE"
    },
    {
        "type":"DG","value": 1487,
        "label": "FURAZOLIDONE AND METRONIDAZOLE"
    },
    {
        "type":"DG","value": 1488,
        "label": "FUROSEMIDE"
    },
    {
        "type":"DG","value": 1489,
        "label": "GABAPENTIN"
    },
    {
        "type":"DG","value": 1490,
        "label": "GABAPENTIN AND MECOBALAMIN"
    },
    {
        "type":"DG","value": 1491,
        "label": "GABAPENTIN AND METHYL COBALINE"
    },
    {
        "type":"DG","value": 1492,
        "label": "GAMA LINOLENIC ACID"
    },
    {
        "type":"DG","value": 1493,
        "label": "GATIFLOXACIN"
    },
    {
        "type":"DG","value": 1494,
        "label": "GATIFLOXACIN ORNIDAZOLE"
    },
    {
        "type":"DG","value": 1495,
        "label": "GEFITINIB"
    },
    {
        "type":"DG","value": 1496,
        "label": "GEMCITABINE"
    },
    {
        "type":"DG","value": 1497,
        "label": "GENTAMICIN"
    },
    {
        "type":"DG","value": 1498,
        "label": "GLIBENCLAMIDE"
    },
    {
        "type":"DG","value": 1499,
        "label": "GLICAZIDE AND METFORMIN HCL"
    },
    {
        "type":"DG","value": 1500,
        "label": "GLIMEPIRIDE"
    },
    {
        "type":"DG","value": 1501,
        "label": "GLIMEPIRIDE AND METFORMIN"
    },
    {
        "type":"DG","value": 1502,
        "label": "GLIMEPIRIDE VOGLIBOSE AND EXTENDED RELEA"
    },
    {
        "type":"DG","value": 1503,
        "label": "GLIPIZIDE AND METFORMIN HCL"
    },
    {
        "type":"DG","value": 1504,
        "label": "GLUCOSAMINE AND CHONDROTIN"
    },
    {
        "type":"DG","value": 1505,
        "label": "GLUTAMINE"
    },
    {
        "type":"DG","value": 1506,
        "label": "GLYCERIN"
    },
    {
        "type":"DG","value": 1507,
        "label": "GLYCOPYROLATE"
    },
    {
        "type":"DG","value": 1508,
        "label": "GOSERELIN ACETATE DEPOT"
    },
    {
        "type":"DG","value": 1509,
        "label": "GRANISETRON HCL"
    },
    {
        "type":"DG","value": 1510,
        "label": "GRANISETRON HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1511,
        "label": "H.G.C.S.F"
    },
    {
        "type":"DG","value": 1512,
        "label": "HAEMOCOAGULASE"
    },
    {
        "type":"DG","value": 1513,
        "label": "HAEMOPHILUS TYPE B CONJUGATE"
    },
    {
        "type":"DG","value": 1514,
        "label": "HALOPERIDOL"
    },
    {
        "type":"DG","value": 1515,
        "label": "HEPARIN"
    },
    {
        "type":"DG","value": 1516,
        "label": "HEPARIN AND BENZYL NICOTINATR"
    },
    {
        "type":"DG","value": 1517,
        "label": "HEPARIN LOCK FLUSH"
    },
    {
        "type":"DG","value": 1518,
        "label": "HEPATITIS B VACCINE"
    },
    {
        "type":"DG","value": 1519,
        "label": "HEPATITS B VACCINE"
    },
    {
        "type":"DG","value": 1520,
        "label": "HIGH PROTEIN AND HIGH CALORIC POWDER"
    },
    {
        "type":"DG","value": 1521,
        "label": "HIGH PROTEIN POWDER FOR DIABETICS"
    },
    {
        "type":"DG","value": 1522,
        "label": "HPE ADMIXTURE 1500 2000 K CAL CE MEDIUM"
    },
    {
        "type":"DG","value": 1523,
        "label": "HPE ADMIXTURE 1500 2000 K CAL CE SMALL"
    },
    {
        "type":"DG","value": 1524,
        "label": "HPE ADMIXTURE 1500 2000 K CAL PERI BIG"
    },
    {
        "type":"DG","value": 1525,
        "label": "HPE ADMIXTURE 1500 2000 K CAL PERI MEDI"
    },
    {
        "type":"DG","value": 1526,
        "label": "HPE ADMIXTURE 1500 2000 K CAL PERI SMALL"
    },
    {
        "type":"DG","value": 1527,
        "label": "HPE ADMIXTURE 2000 2500 K CAL CE MEDIUM"
    },
    {
        "type":"DG","value": 1528,
        "label": "HPE ADMIXTURE 2000 2500 K CAL CEN BIG"
    },
    {
        "type":"DG","value": 1529,
        "label": "HPE ADMIXTURE 2000 2500 K CAL PERI BIG"
    },
    {
        "type":"DG","value": 1530,
        "label": "HUMAN INTRAVENOUS IMMUNOGLOBULIN"
    },
    {
        "type":"DG","value": 1531,
        "label": "HUMAN NORMAL ALBUMIN"
    },
    {
        "type":"DG","value": 1532,
        "label": "HUMAN PAPILLOMAVIRUS VACCINE"
    },
    {
        "type":"DG","value": 1533,
        "label": "HUMAN PLACENTAE EXTRACTION"
    },
    {
        "type":"DG","value": 1534,
        "label": "HYALURONIDASE"
    },
    {
        "type":"DG","value": 1535,
        "label": "HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1536,
        "label": "HYDROCORTISON AND NAPHAZOLINE NITATE"
    },
    {
        "type":"DG","value": 1537,
        "label": "HYDROCORTISONE"
    },
    {
        "type":"DG","value": 1538,
        "label": "HYDROCORTISONE ACETATE"
    },
    {
        "type":"DG","value": 1539,
        "label": "HYDROCORTISONE FRAMYCETIN HEPARINE"
    },
    {
        "type":"DG","value": 1540,
        "label": "HYDROCORTISONE SODIUM SUCCINATE"
    },
    {
        "type":"DG","value": 1541,
        "label": "HYDROLYZED WHEY PROTEIN FAT AS MCT"
    },
    {
        "type":"DG","value": 1542,
        "label": "HYDROXOCOBALAMIN"
    },
    {
        "type":"DG","value": 1543,
        "label": "HYDROXY ETHLY STARCH"
    },
    {
        "type":"DG","value": 1544,
        "label": "HYDROXY PROGESTRONE"
    },
    {
        "type":"DG","value": 1545,
        "label": "HYDROXY UREA"
    },
    {
        "type":"DG","value": 1546,
        "label": "HYDROXYETHYL"
    },
    {
        "type":"DG","value": 1547,
        "label": "HYDROXYPROPYL METHYLCELLULOSE"
    },
    {
        "type":"DG","value": 1548,
        "label": "HYDROXYZINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1549,
        "label": "HYOSCINE BUTYLBROMIDE"
    },
    {
        "type":"DG","value": 1550,
        "label": "HYOSCINE BUTYLBROMIDE AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1551,
        "label": "hyper tension"
    },
    {
        "type":"DG","value": 1552,
        "label": "HYPROMELLOSE OPHTHALMIC SOLUTION"
    },
    {
        "type":"DG","value": 1553,
        "label": "IBANDRONIC ACID"
    },
    {
        "type":"DG","value": 1554,
        "label": "IBUPROFEN"
    },
    {
        "type":"DG","value": 1555,
        "label": "IBUPROFEN  PARA SUSP"
    },
    {
        "type":"DG","value": 1556,
        "label": "IBUPROFEN 400MG PARACETAMOL 325MG"
    },
    {
        "type":"DG","value": 1557,
        "label": "IBUPROFEN AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1558,
        "label": "IBUPROFEN PARACETMOL AND CHLORZOXAZONE"
    },
    {
        "type":"DG","value": 1559,
        "label": "IDARUBICIN"
    },
    {
        "type":"DG","value": 1560,
        "label": "IFOSFAMIDE"
    },
    {
        "type":"DG","value": 1561,
        "label": "ILAPRAZOLE"
    },
    {
        "type":"DG","value": 1562,
        "label": "IMATINIB"
    },
    {
        "type":"DG","value": 1563,
        "label": "IMIPENEM  CILASTATIN"
    },
    {
        "type":"DG","value": 1564,
        "label": "IMIPRAMINE"
    },
    {
        "type":"DG","value": 1565,
        "label": "IMIPRAMINE AND DIAZEPAM"
    },
    {
        "type":"DG","value": 1566,
        "label": "IMMUNE BOSTERS ANTIOXIDANTS VIT MINERAL"
    },
    {
        "type":"DG","value": 1567,
        "label": "INDAPAMIDE SUSTAINED"
    },
    {
        "type":"DG","value": 1568,
        "label": "INFLUENZA VACCINE"
    },
    {
        "type":"DG","value": 1569,
        "label": "INSULIN FLEXPEN"
    },
    {
        "type":"DG","value": 1570,
        "label": "INTERFERON ALPHA"
    },
    {
        "type":"DG","value": 1571,
        "label": "INTRAVENOUS FAT EMULSION FOR INFUSION"
    },
    {
        "type":"DG","value": 1572,
        "label": "IPRATROPIUM BROMIDE AND LEVOSALBUTAMOL"
    },
    {
        "type":"DG","value": 1573,
        "label": "IRINOTECAN HYDROCHLORIDE TRIHYDRATE"
    },
    {
        "type":"DG","value": 1574,
        "label": "IRNOTECAM"
    },
    {
        "type":"DG","value": 1575,
        "label": "IRON B12 B6 NCOTINAMIDE ZINC"
    },
    {
        "type":"DG","value": 1576,
        "label": "IRON B12 FOLIC ACID"
    },
    {
        "type":"DG","value": 1577,
        "label": "IRON PYROPHOSPHATE COMPOUND"
    },
    {
        "type":"DG","value": 1578,
        "label": "IRON SUCROSE"
    },
    {
        "type":"DG","value": 1579,
        "label": "IRON ZINC FOLIC ACID"
    },
    {
        "type":"DG","value": 1580,
        "label": "IRONHCL POLYMLTOSE AND FOLICACID"
    },
    {
        "type":"DG","value": 1581,
        "label": "ISONIAZID"
    },
    {
        "type":"DG","value": 1582,
        "label": "ISOPHANE INSULIN HUMAN SUSPENSION"
    },
    {
        "type":"DG","value": 1583,
        "label": "ISOPRENALINE"
    },
    {
        "type":"DG","value": 1584,
        "label": "ISOSORBIDE MONONITRATE"
    },
    {
        "type":"DG","value": 1585,
        "label": "ISOTRETINOIN"
    },
    {
        "type":"DG","value": 1586,
        "label": "ISOXSUPRINE HCL"
    },
    {
        "type":"DG","value": 1587,
        "label": "ISPAGHULA HUSK"
    },
    {
        "type":"DG","value": 1588,
        "label": "ITOPRIDE HCL"
    },
    {
        "type":"DG","value": 1589,
        "label": "ITRACONAZOLE"
    },
    {
        "type":"DG","value": 1590,
        "label": "IXABEPILONE"
    },
    {
        "type":"DG","value": 1591,
        "label": "KETAMINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1592,
        "label": "ketamine hydrochloride"
    },
    {
        "type":"DG","value": 1593,
        "label": "KETOCONAZOLE"
    },
    {
        "type":"DG","value": 1594,
        "label": "KETORAL TROMETHAMINE"
    },
    {
        "type":"DG","value": 1595,
        "label": "KETOROLAC TROMETHAMINE"
    },
    {
        "type":"DG","value": 1596,
        "label": "L ALANYL  L GLUTAMINE"
    },
    {
        "type":"DG","value": 1597,
        "label": "L ARGININE VITAMIN C AND E GRANULES"
    },
    {
        "type":"DG","value": 1598,
        "label": "L CARNITINE L TARTRATE METHYLCOBALAMIN"
    },
    {
        "type":"DG","value": 1599,
        "label": "L GLUTAMINE GRANULES"
    },
    {
        "type":"DG","value": 1600,
        "label": "L ORNITHINE L ASPARTATE"
    },
    {
        "type":"DG","value": 1601,
        "label": "L ORNITHINE L ASPARTATE PANCREATIN"
    },
    {
        "type":"DG","value": 1602,
        "label": "LABETALOL"
    },
    {
        "type":"DG","value": 1603,
        "label": "LACTIC ACID BACILLUS"
    },
    {
        "type":"DG","value": 1604,
        "label": "LACTIC ACID BACILLUS FORTEFIED WITH VITA"
    },
    {
        "type":"DG","value": 1605,
        "label": "LACTIC ACID VIT B1 B2 B6 NICOTINAMIDE"
    },
    {
        "type":"DG","value": 1606,
        "label": "LACTOBACILLOUS ACIDOPHILLUS BIFIDOBACTER"
    },
    {
        "type":"DG","value": 1607,
        "label": "LACTOBACILUS SPOROGENES FRUCTOOLIGOSACHR"
    },
    {
        "type":"DG","value": 1608,
        "label": "LACTOSE FREE GLUTEIN FREE PROTEIN DIABET"
    },
    {
        "type":"DG","value": 1609,
        "label": "LACTOSE FREE GLUTEN FREE PROTEIN POWDER"
    },
    {
        "type":"DG","value": 1610,
        "label": "LACTULOSE"
    },
    {
        "type":"DG","value": 1611,
        "label": "LAMIVUDINE"
    },
    {
        "type":"DG","value": 1612,
        "label": "LANSOPRAZOLE TINIDAZOLE AND CLARITHROMYC"
    },
    {
        "type":"DG","value": 1613,
        "label": "LAPATINIB DITOSYLATE"
    },
    {
        "type":"DG","value": 1614,
        "label": "L-ASPARAGINASE"
    },
    {
        "type":"DG","value": 1615,
        "label": "LENALIDOMIDE"
    },
    {
        "type":"DG","value": 1616,
        "label": "LENOGRASTIN"
    },
    {
        "type":"DG","value": 1617,
        "label": "LETROZOLE"
    },
    {
        "type":"DG","value": 1618,
        "label": "LETRZOLE"
    },
    {
        "type":"DG","value": 1619,
        "label": "LEUCOVORIN CALCIUM"
    },
    {
        "type":"DG","value": 1620,
        "label": "LEUPROLIDE ACETATE"
    },
    {
        "type":"DG","value": 1621,
        "label": "LEVETIRACETAM"
    },
    {
        "type":"DG","value": 1622,
        "label": "LEVOCARNITINE"
    },
    {
        "type":"DG","value": 1623,
        "label": "LEVOCETIRIZINE DIHYDROCHLORIDE AND AMBRO"
    },
    {
        "type":"DG","value": 1624,
        "label": "LEVOCETIRIZINE DIHYDROVHLORIDE PSEUDOEPH"
    },
    {
        "type":"DG","value": 1625,
        "label": "LEVOCETIRIZINE HCL AND MONTELUKAST"
    },
    {
        "type":"DG","value": 1626,
        "label": "LEVOCETRIZIN HCL PHENYLEPHRINE AMBROXIL"
    },
    {
        "type":"DG","value": 1627,
        "label": "LEVOCETRIZINE"
    },
    {
        "type":"DG","value": 1628,
        "label": "LEVOCETRIZINE HYDROCHORIDE"
    },
    {
        "type":"DG","value": 1629,
        "label": "LEVOCITIRIZINE PSEUPHEDRINE PARACETAMOL"
    },
    {
        "type":"DG","value": 1630,
        "label": "LEVODAPA AND CARBIDOPA CONTROLLED RELEAS"
    },
    {
        "type":"DG","value": 1631,
        "label": "LEVODOPA AND CARBODOPA"
    },
    {
        "type":"DG","value": 1632,
        "label": "LEVODROPROPIZINE"
    },
    {
        "type":"DG","value": 1633,
        "label": "LEVOFLOXACIN"
    },
    {
        "type":"DG","value": 1634,
        "label": "LEVONORGESTREL AND ETHINYLOESTRADIOL"
    },
    {
        "type":"DG","value": 1635,
        "label": "LEVOSALBUTAMOL"
    },
    {
        "type":"DG","value": 1636,
        "label": "LIDOCAINE AND PRILOCAINE"
    },
    {
        "type":"DG","value": 1637,
        "label": "LIDOCAINE HYDROCHLORIDE TOPICAL SOLUTION"
    },
    {
        "type":"DG","value": 1638,
        "label": "LIDOCAINE HYDROCORTISONE  ACETATE"
    },
    {
        "type":"DG","value": 1639,
        "label": "LIDOCAINE HYDROCORTISONE ZINC OXIDE ALLA"
    },
    {
        "type":"DG","value": 1640,
        "label": "LIGNIOCAINE HCL"
    },
    {
        "type":"DG","value": 1641,
        "label": "LIGNOCAINE HCL AND ADRENALINE"
    },
    {
        "type":"DG","value": 1642,
        "label": "LIGNOCAINE HCL AND DEXTROSE"
    },
    {
        "type":"DG","value": 1643,
        "label": "LINCOMYCIN"
    },
    {
        "type":"DG","value": 1644,
        "label": "LINEZOLID"
    },
    {
        "type":"DG","value": 1645,
        "label": "LIPOSOMAL  AMPHOTERICIN"
    },
    {
        "type":"DG","value": 1646,
        "label": "LIPOSOMAL AMPHOTERICIN-B"
    },
    {
        "type":"DG","value": 1647,
        "label": "LISINOPRIL"
    },
    {
        "type":"DG","value": 1648,
        "label": "LIVER FCTOR2  YEAST EXTRACT"
    },
    {
        "type":"DG","value": 1649,
        "label": "LODOCAINE HCL"
    },
    {
        "type":"DG","value": 1650,
        "label": "LOMUSTINE"
    },
    {
        "type":"DG","value": 1651,
        "label": "LOPERAMIDE"
    },
    {
        "type":"DG","value": 1652,
        "label": "LORATADINE AND AMBROXOL HCL"
    },
    {
        "type":"DG","value": 1653,
        "label": "LORAZEPAM"
    },
    {
        "type":"DG","value": 1654,
        "label": "LORNOXICAM"
    },
    {
        "type":"DG","value": 1655,
        "label": "LORNOXICAM  PARACETAMOL"
    },
    {
        "type":"DG","value": 1656,
        "label": "LORNOXICAM AND  PARACETAMOL"
    },
    {
        "type":"DG","value": 1657,
        "label": "LORNOXICAM AND PARACETAMOL"
    },
    {
        "type":"DG","value": 1658,
        "label": "LORNOXICAM PARACETAMOL"
    },
    {
        "type":"DG","value": 1659,
        "label": "LOSARTAN"
    },
    {
        "type":"DG","value": 1660,
        "label": "LOSARTAN POT AND HYDROCHLORTHIAZIDE"
    },
    {
        "type":"DG","value": 1661,
        "label": "LOSARTAN POTASSIUM"
    },
    {
        "type":"DG","value": 1662,
        "label": "LOSARTAN POTASSIUM RAMIPRIL"
    },
    {
        "type":"DG","value": 1663,
        "label": "LUPIDERM"
    },
    {
        "type":"DG","value": 1664,
        "label": "LYCOPENE  MIXED CAROTENE AND WHEAT GERM"
    },
    {
        "type":"DG","value": 1665,
        "label": "LYCOPENE ANTIOXIDANT CAROTENOID CARNITIN"
    },
    {
        "type":"DG","value": 1666,
        "label": "LYCOPENE ARGININ FOLIC ACID ZINC SULPHA"
    },
    {
        "type":"DG","value": 1667,
        "label": "LYCOPENE VIT MINERALS GINSENG GINGKO"
    },
    {
        "type":"DG","value": 1668,
        "label": "LYCOPENE WITH MULTIVITAMIN ANDMULTIMINER"
    },
    {
        "type":"DG","value": 1669,
        "label": "LYCOPENE WITH MULTIVITAMINS ANTIOXIDANT"
    },
    {
        "type":"DG","value": 1670,
        "label": "LYCOPRO COMPLEX VITAMINS MINERALS"
    },
    {
        "type":"DG","value": 1671,
        "label": "LYMPHOCYTE IMMUNE GLOBULIN"
    },
    {
        "type":"DG","value": 1672,
        "label": "MACROGOL"
    },
    {
        "type":"DG","value": 1673,
        "label": "MAGNESIUM HYDROXIDE AND SIMETHICON"
    },
    {
        "type":"DG","value": 1674,
        "label": "MAGNESIUM SULPHATE"
    },
    {
        "type":"DG","value": 1675,
        "label": "MEBENDAZOLE"
    },
    {
        "type":"DG","value": 1676,
        "label": "MEBEVERINE"
    },
    {
        "type":"DG","value": 1677,
        "label": "MECOBALAMIN"
    },
    {
        "type":"DG","value": 1678,
        "label": "MECOBALAMINE  PYRIDOXIN FOLIC ACID A LIN"
    },
    {
        "type":"DG","value": 1679,
        "label": "MECOBALMIN BENTFOTIAMIN FOLIC ACID PYRID"
    },
    {
        "type":"DG","value": 1680,
        "label": "MEDROXYPROGESTERONE ACETATE"
    },
    {
        "type":"DG","value": 1681,
        "label": "MEFENAMIC ACID"
    },
    {
        "type":"DG","value": 1682,
        "label": "MEFENAMIC ACID DICYCLOMINE HCL"
    },
    {
        "type":"DG","value": 1683,
        "label": "MEFLOQUINE HCL AND ARTESUNATE"
    },
    {
        "type":"DG","value": 1684,
        "label": "MEGESTROL  ACETATE"
    },
    {
        "type":"DG","value": 1685,
        "label": "MELPHALAN"
    },
    {
        "type":"DG","value": 1686,
        "label": "MENAPHTHONE SODIUM  BISULPHITE"
    },
    {
        "type":"DG","value": 1687,
        "label": "MENINGOCOCCAL POLYSACCHARIDE"
    },
    {
        "type":"DG","value": 1688,
        "label": "MEPHENTERMIN SULPHATE"
    },
    {
        "type":"DG","value": 1689,
        "label": "MERCAPTOPURINE"
    },
    {
        "type":"DG","value": 1690,
        "label": "MEROPENEM"
    },
    {
        "type":"DG","value": 1691,
        "label": "MEROPENEM AND SULBACTAM"
    },
    {
        "type":"DG","value": 1692,
        "label": "MET CLOPRAMIDE"
    },
    {
        "type":"DG","value": 1693,
        "label": "METFORMIN HCL"
    },
    {
        "type":"DG","value": 1694,
        "label": "METFORMINE"
    },
    {
        "type":"DG","value": 1695,
        "label": "METHDILAZINE AMMONIUM CHLORIDE SODIUM CH"
    },
    {
        "type":"DG","value": 1696,
        "label": "METHOCARBAMOL"
    },
    {
        "type":"DG","value": 1697,
        "label": "METHOTREXATE"
    },
    {
        "type":"DG","value": 1698,
        "label": "METHYL COBALAMIN ALPHA LIPOIC ACID INOSI"
    },
    {
        "type":"DG","value": 1699,
        "label": "METHYLCOBALAMIN"
    },
    {
        "type":"DG","value": 1700,
        "label": "METHYLCOBALAMIN ALPHALIPOICACID VITB1B6"
    },
    {
        "type":"DG","value": 1701,
        "label": "METHYLCOBALAMINE NIACINAMIDE ZINC VIT B1"
    },
    {
        "type":"DG","value": 1702,
        "label": "METHYLPREDNISOLONE"
    },
    {
        "type":"DG","value": 1703,
        "label": "METHYLPREDNISOLONE SODIUM SUCCINATE"
    },
    {
        "type":"DG","value": 1704,
        "label": "METOCLOPRAMIDE"
    },
    {
        "type":"DG","value": 1705,
        "label": "METOCLOPRAMIDE HCL CONTROLED RELEASE"
    },
    {
        "type":"DG","value": 1706,
        "label": "METOCLOPRAMIDE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1707,
        "label": "METOPROLOL ER AND RAMIPRIL"
    },
    {
        "type":"DG","value": 1708,
        "label": "METOPROLOL SUCCINATE ER AMLODIPINE"
    },
    {
        "type":"DG","value": 1709,
        "label": "METOPROLOL SUCCINATE EXTENDED RELEASE"
    },
    {
        "type":"DG","value": 1710,
        "label": "METOPROLOL TARTRATE"
    },
    {
        "type":"DG","value": 1711,
        "label": "METRONIDAZOLE"
    },
    {
        "type":"DG","value": 1712,
        "label": "METRONIDAZOLE AND FURAZOLIDONE"
    },
    {
        "type":"DG","value": 1713,
        "label": "METRONIDAZOLE NORFLOXACILIN"
    },
    {
        "type":"DG","value": 1714,
        "label": "MICONAZOLE NITRATE AND FLUOCINOLONE"
    },
    {
        "type":"DG","value": 1715,
        "label": "MIDAZOLAM"
    },
    {
        "type":"DG","value": 1716,
        "label": "MILK OF MAG  LIQUID PARAFFIN SOD PICOSUL"
    },
    {
        "type":"DG","value": 1717,
        "label": "MILK OF MAGNESIA AND LIQUID PARAFFIN"
    },
    {
        "type":"DG","value": 1718,
        "label": "MITOMYCIN"
    },
    {
        "type":"DG","value": 1719,
        "label": "MITOXANTRONE"
    },
    {
        "type":"DG","value": 1720,
        "label": "MOLGRAMOSTIM"
    },
    {
        "type":"DG","value": 1721,
        "label": "MONO BASIC SOD PHOSPHATE DI SOD HYDROGE"
    },
    {
        "type":"DG","value": 1722,
        "label": "MONOCOMPONENT HUMAN INSULIN"
    },
    {
        "type":"DG","value": 1723,
        "label": "MONTELUKAST SODIUM LEVOCETRIZINE"
    },
    {
        "type":"DG","value": 1724,
        "label": "MORPHINE SULPHATE"
    },
    {
        "type":"DG","value": 1725,
        "label": "MOSAPRIDE CITRATE"
    },
    {
        "type":"DG","value": 1726,
        "label": "MOXIFLOXACIN"
    },
    {
        "type":"DG","value": 1727,
        "label": "MULTI VITAMINE"
    },
    {
        "type":"DG","value": 1728,
        "label": "MULTIVITAMIN  MULTIMINERAL ANTIOXIDANT"
    },
    {
        "type":"DG","value": 1729,
        "label": "MULTIVITAMIN AND MULTIMINERAL SOFTGELATI"
    },
    {
        "type":"DG","value": 1730,
        "label": "MULTIVITAMIN ZINC CHROMIUM"
    },
    {
        "type":"DG","value": 1731,
        "label": "MUPIROCIN"
    },
    {
        "type":"DG","value": 1732,
        "label": "MV WITH CHROMIUM ZINC AND SELENIUM"
    },
    {
        "type":"DG","value": 1733,
        "label": "MYCOPHENOLATE MOFETIL"
    },
    {
        "type":"DG","value": 1734,
        "label": "NADROPARIN CALCIUM"
    },
    {
        "type":"DG","value": 1735,
        "label": "NALIDIXIC ACID"
    },
    {
        "type":"DG","value": 1736,
        "label": "NALOXONE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1737,
        "label": "NANDROLONE DECANOATE"
    },
    {
        "type":"DG","value": 1738,
        "label": "NAPROXEN SODIUM"
    },
    {
        "type":"DG","value": 1739,
        "label": "NEBIVOLOL HCL"
    },
    {
        "type":"DG","value": 1740,
        "label": "NEOMYCIN POLYMYXIN B SULFATE BACITRACIN"
    },
    {
        "type":"DG","value": 1741,
        "label": "NEOSTIGMIN GLYCOPYROLATE"
    },
    {
        "type":"DG","value": 1742,
        "label": "NEOSTIGMINE METHYL SULPHATE"
    },
    {
        "type":"DG","value": 1743,
        "label": "NETILMICIN SULFATE"
    },
    {
        "type":"DG","value": 1744,
        "label": "NICORANDIL"
    },
    {
        "type":"DG","value": 1745,
        "label": "NICOTINE"
    },
    {
        "type":"DG","value": 1746,
        "label": "NICOUMALONE"
    },
    {
        "type":"DG","value": 1747,
        "label": "NIFEDIPINE"
    },
    {
        "type":"DG","value": 1748,
        "label": "NILOTINIB"
    },
    {
        "type":"DG","value": 1749,
        "label": "NIMESULIDE"
    },
    {
        "type":"DG","value": 1750,
        "label": "NIMOTUZUMAB"
    },
    {
        "type":"DG","value": 1751,
        "label": "NITAZOXANIDE"
    },
    {
        "type":"DG","value": 1752,
        "label": "NITOZOXANIDE AND OFLOXACIN"
    },
    {
        "type":"DG","value": 1753,
        "label": "NITROFURANTOIN"
    },
    {
        "type":"DG","value": 1754,
        "label": "NITROGLYCERIN"
    },
    {
        "type":"DG","value": 1755,
        "label": "NOR ADRENALINE BIOTARTIRATE"
    },
    {
        "type":"DG","value": 1756,
        "label": "NORETHINDRONE ACETATE"
    },
    {
        "type":"DG","value": 1757,
        "label": "NORETNISTERONE"
    },
    {
        "type":"DG","value": 1758,
        "label": "NORFLOXACIN"
    },
    {
        "type":"DG","value": 1759,
        "label": "NORFLOXACIN AND BETADEX"
    },
    {
        "type":"DG","value": 1760,
        "label": "NORFLOXACIN TINIDAZOLE  LACTIC ACID BAC"
    },
    {
        "type":"DG","value": 1761,
        "label": "NORMAL HUMAN IMMUNOGLOBULIN (PH+)"
    },
    {
        "type":"DG","value": 1762,
        "label": "NORMAL HUMAN IMMUNOGLOBULIN PH+"
    },
    {
        "type":"DG","value": 1763,
        "label": "NORMAL SALINE"
    },
    {
        "type":"DG","value": 1764,
        "label": "NOSCAPINE CHLORPHENIRAMINE MELEATE AMMON"
    },
    {
        "type":"DG","value": 1765,
        "label": "NUTRITIONAL SUPPLEMENT"
    },
    {
        "type":"DG","value": 1766,
        "label": "OCTREOTIDE"
    },
    {
        "type":"DG","value": 1767,
        "label": "OCTREOTIDE "
    },
    {
        "type":"DG","value": 1768,
        "label": "OFLOXACIN"
    },
    {
        "type":"DG","value": 1769,
        "label": "OFLOXACIN AND ORNIDAZOLE"
    },
    {
        "type":"DG","value": 1770,
        "label": "OFLOXACIN TINIDAZOLE"
    },
    {
        "type":"DG","value": 1771,
        "label": "OLANZAPINE"
    },
    {
        "type":"DG","value": 1772,
        "label": "OLMESARTAN"
    },
    {
        "type":"DG","value": 1773,
        "label": "OLMESARTAN MEDAXONIL AND HCL THIAZIDE"
    },
    {
        "type":"DG","value": 1774,
        "label": "OLMESATRAN MEDOXONIL AND AMLODIPINE"
    },
    {
        "type":"DG","value": 1775,
        "label": "OMEGA 3 FATTY ACID ANTIOXIDENTS MULTI VI"
    },
    {
        "type":"DG","value": 1776,
        "label": "OMEGA 3 FATTY ACIDS WITH DHA EPA VIT C E"
    },
    {
        "type":"DG","value": 1777,
        "label": "OMEGA3 FATTY ACIDS CAROTENOIDS ALPHA LIP"
    },
    {
        "type":"DG","value": 1778,
        "label": "OMEGA3 FATTY ACIDS VIT E WHEAT GERM OIL"
    },
    {
        "type":"DG","value": 1779,
        "label": "OMEPRAZOLE"
    },
    {
        "type":"DG","value": 1780,
        "label": "OMEPRAZOLE MAGNESIUM AND DOMPERIDONE"
    },
    {
        "type":"DG","value": 1781,
        "label": "ONDANSETRON"
    },
    {
        "type":"DG","value": 1782,
        "label": "ONDANSETRON MOUTHDISSOLVING"
    },
    {
        "type":"DG","value": 1783,
        "label": "ORAL REHYDRATION SALT"
    },
    {
        "type":"DG","value": 1784,
        "label": "ORCIPRENALINE"
    },
    {
        "type":"DG","value": 1785,
        "label": "ORNIDAZOLE"
    },
    {
        "type":"DG","value": 1786,
        "label": "ORNIDAZOLE AND OFLOXACIN"
    },
    {
        "type":"DG","value": 1787,
        "label": "OSELTAMIVIR"
    },
    {
        "type":"DG","value": 1788,
        "label": "OSTELTAMINIR"
    },
    {
        "type":"DG","value": 1789,
        "label": "OXALIPLATIN"
    },
    {
        "type":"DG","value": 1790,
        "label": "OXETACAINE DRIED ALU AND MAG HYDROXIDE"
    },
    {
        "type":"DG","value": 1791,
        "label": "OXICONAZOLE NITRATE"
    },
    {
        "type":"DG","value": 1792,
        "label": "OXYBUTYNIN CHLORIDE"
    },
    {
        "type":"DG","value": 1793,
        "label": "OXYMETAZOLINE HCL"
    },
    {
        "type":"DG","value": 1794,
        "label": "OXYTETRACYCLINE"
    },
    {
        "type":"DG","value": 1795,
        "label": "OXYTOCIN"
    },
    {
        "type":"DG","value": 1796,
        "label": "PACCREATIN"
    },
    {
        "type":"DG","value": 1797,
        "label": "PACLITAXEL"
    },
    {
        "type":"DG","value": 1798,
        "label": "PACLITAXEL NANOPARTICLE"
    },
    {
        "type":"DG","value": 1799,
        "label": "PACLITAXEL PROTEIN BOUND PARTICLES"
    },
    {
        "type":"DG","value": 1800,
        "label": "PALONOSETRON"
    },
    {
        "type":"DG","value": 1801,
        "label": "PALONOSETRON HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1802,
        "label": "PANITUMUMAB"
    },
    {
        "type":"DG","value": 1803,
        "label": "PANTAPRAZOLE DOMPERIDONE"
    },
    {
        "type":"DG","value": 1804,
        "label": "PANTAPRAZOLE SOD SESHCL AND DOMOPERIDONE"
    },
    {
        "type":"DG","value": 1805,
        "label": "PANTAPRAZOLE SODIUM"
    },
    {
        "type":"DG","value": 1806,
        "label": "PANTOPRAZOLE"
    },
    {
        "type":"DG","value": 1807,
        "label": "PANTOPRAZOLE  DOMPERIDONE SR"
    },
    {
        "type":"DG","value": 1808,
        "label": "PANTOPRAZOLE SODIUM AND LTOPRIDE HYDROCH"
    },
    {
        "type":"DG","value": 1809,
        "label": "PANTOPRAZOLE SODIUM DELAYED RELEASE"
    },
    {
        "type":"DG","value": 1810,
        "label": "PAPAIN FUNGAL DIASTASE SIMETHICONE EFFER"
    },
    {
        "type":"DG","value": 1811,
        "label": "PAPAVERINE HCL"
    },
    {
        "type":"DG","value": 1812,
        "label": "PARACETAMOL"
    },
    {
        "type":"DG","value": 1813,
        "label": "PARACETAMOL  AND CODEINE PHOSPHATE"
    },
    {
        "type":"DG","value": 1814,
        "label": "PARACETAMOL AND ETODOLAC"
    },
    {
        "type":"DG","value": 1815,
        "label": "PARACETAMOL ANDDOMPERIDONE"
    },
    {
        "type":"DG","value": 1816,
        "label": "PARACETAMOL CPM PHENYLEPHRINE CAFFEINE"
    },
    {
        "type":"DG","value": 1817,
        "label": "PARACETAMOL DICLOFENAC  SERRATIOPEPTIDAS"
    },
    {
        "type":"DG","value": 1818,
        "label": "PARACETAMOL PSEUDOEPHEDINE HCL AND CHLOR"
    },
    {
        "type":"DG","value": 1819,
        "label": "PARACETMOL INTRAVENOUS INFUSION"
    },
    {
        "type":"DG","value": 1820,
        "label": "PARACETMOL PHENYLEPHRIN CHLORPHENIRAMINE"
    },
    {
        "type":"DG","value": 1821,
        "label": "PARADICHLOROBENZENE CHLORBUTOL TURPENTIN"
    },
    {
        "type":"DG","value": 1822,
        "label": "PARENTRAL FAT EMULSION 20 INFUSION"
    },
    {
        "type":"DG","value": 1823,
        "label": "PAROXETINE"
    },
    {
        "type":"DG","value": 1824,
        "label": "PAZOPANIB HCL"
    },
    {
        "type":"DG","value": 1825,
        "label": "PAZUFLOXACIN"
    },
    {
        "type":"DG","value": 1826,
        "label": "PEG L ASPARAGINASE"
    },
    {
        "type":"DG","value": 1827,
        "label": "PEGFILGRASTIM"
    },
    {
        "type":"DG","value": 1828,
        "label": "PEGINTERFERON"
    },
    {
        "type":"DG","value": 1829,
        "label": "PEGYLATED LIPOSOMAL DOXORUBICIN HCL"
    },
    {
        "type":"DG","value": 1830,
        "label": "PEMETREXED"
    },
    {
        "type":"DG","value": 1831,
        "label": "PENTAZOCINE LACTATE"
    },
    {
        "type":"DG","value": 1832,
        "label": "PENTOXIFYLLINE  EXTENDED"
    },
    {
        "type":"DG","value": 1833,
        "label": "PETHIDINE HCL"
    },
    {
        "type":"DG","value": 1834,
        "label": "PHENAZOPYRIDINE HCL"
    },
    {
        "type":"DG","value": 1835,
        "label": "PHENIRAMINE MALEATE"
    },
    {
        "type":"DG","value": 1836,
        "label": "PHENOBARBITONE"
    },
    {
        "type":"DG","value": 1837,
        "label": "PHENTOLAMINE"
    },
    {
        "type":"DG","value": 1838,
        "label": "PHENYLEPHERINE CPM BROMOHEXINE GUAIPHENE"
    },
    {
        "type":"DG","value": 1839,
        "label": "PHENYLEPHRINE AND CPM"
    },
    {
        "type":"DG","value": 1840,
        "label": "PHENYLEPHRINE NAPHAZOLINE MENTHOL CAMPHO"
    },
    {
        "type":"DG","value": 1841,
        "label": "PHENYLPROPANOLAMINE CHLOROPHENIRAMINE"
    },
    {
        "type":"DG","value": 1842,
        "label": "PHENYTOIN"
    },
    {
        "type":"DG","value": 1843,
        "label": "PHENYTOIN SODIUM"
    },
    {
        "type":"DG","value": 1844,
        "label": "PHYTOMENADIONE"
    },
    {
        "type":"DG","value": 1845,
        "label": "PILOCARPINE"
    },
    {
        "type":"DG","value": 1846,
        "label": "PIOGLITAZONE"
    },
    {
        "type":"DG","value": 1847,
        "label": "PIPERACILLIN SOD AND TAZOBACTAM SODIUM"
    },
    {
        "type":"DG","value": 1848,
        "label": "PIRACETAM"
    },
    {
        "type":"DG","value": 1849,
        "label": "PIROXICAM"
    },
    {
        "type":"DG","value": 1850,
        "label": "PLASMA PROTEIN FRACTION"
    },
    {
        "type":"DG","value": 1851,
        "label": "PLERIXAFOR"
    },
    {
        "type":"DG","value": 1852,
        "label": "POLICRESULEN AND CINCHOCAINE HCL"
    },
    {
        "type":"DG","value": 1853,
        "label": "POLY GELINE POLY PEPTIDES WITH ELECTROLY"
    },
    {
        "type":"DG","value": 1854,
        "label": "POLYETHELENE GLYCOL WITH ELECTROLYTES"
    },
    {
        "type":"DG","value": 1855,
        "label": "POLYSACCHARIDE PNEUMOCOCCAL VACCINE"
    },
    {
        "type":"DG","value": 1856,
        "label": "POLYVINYL POLYMER BENZOCAINE CETRIMIDE"
    },
    {
        "type":"DG","value": 1857,
        "label": "POSACONAZOLE ORAL SUSP"
    },
    {
        "type":"DG","value": 1858,
        "label": "POTASSIUM CHLORIDE CONCENTRATE"
    },
    {
        "type":"DG","value": 1859,
        "label": "POTASSIUM MAGNESIUM CITRATE AND VITB6"
    },
    {
        "type":"DG","value": 1860,
        "label": "POVIDONE AND IODINE"
    },
    {
        "type":"DG","value": 1861,
        "label": "POVIDONE IODINE"
    },
    {
        "type":"DG","value": 1862,
        "label": "PRAMIPEXOLE DIHYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1863,
        "label": "PRAMIPEXOLE HCL"
    },
    {
        "type":"DG","value": 1864,
        "label": "PRAZOSIN"
    },
    {
        "type":"DG","value": 1865,
        "label": "PRAZOSIN HCL"
    },
    {
        "type":"DG","value": 1866,
        "label": "PREBIOTIC  AND PROBIOTIC"
    },
    {
        "type":"DG","value": 1867,
        "label": "PREDNISOLONE"
    },
    {
        "type":"DG","value": 1868,
        "label": "PREGABALIN"
    },
    {
        "type":"DG","value": 1869,
        "label": "PREGABALIN MECOBALAMIN ALPHA LOPIC ACID"
    },
    {
        "type":"DG","value": 1870,
        "label": "PREGABALIN METHYLCOBALAMIN"
    },
    {
        "type":"DG","value": 1871,
        "label": "PRENOXDRAXINE HCL"
    },
    {
        "type":"DG","value": 1872,
        "label": "PRIME ROSE OIL"
    },
    {
        "type":"DG","value": 1873,
        "label": "PROCARBAZINE"
    },
    {
        "type":"DG","value": 1874,
        "label": "PROCHLORPERAZINE MALEATE"
    },
    {
        "type":"DG","value": 1875,
        "label": "PROMETHAZINE"
    },
    {
        "type":"DG","value": 1876,
        "label": "PROMETHAZINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1877,
        "label": "PROPARACAINE HCL"
    },
    {
        "type":"DG","value": 1878,
        "label": "PROPOFOL"
    },
    {
        "type":"DG","value": 1879,
        "label": "PROPOXYPHENO NAPSYLATE AND ACETAMINOPHE"
    },
    {
        "type":"DG","value": 1880,
        "label": "PROPRANOLOL HCL"
    },
    {
        "type":"DG","value": 1881,
        "label": "PROPRANOLOL HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1882,
        "label": "PROPYLENE GLYCOL"
    },
    {
        "type":"DG","value": 1883,
        "label": "PROTAMINE SULPHATE"
    },
    {
        "type":"DG","value": 1884,
        "label": "PRULIFLOXACIN"
    },
    {
        "type":"DG","value": 1885,
        "label": "PSEUDOEPHEDRINE HCL BROMHEXINE HCL CPM"
    },
    {
        "type":"DG","value": 1886,
        "label": "PURE CRYSTALLINE ESSENTIAL AMINO ACIDS"
    },
    {
        "type":"DG","value": 1887,
        "label": "PYDROXINE HCL FOLIC ACID"
    },
    {
        "type":"DG","value": 1888,
        "label": "PYRAZENAMIDE"
    },
    {
        "type":"DG","value": 1889,
        "label": "PYRAZINAMIDE"
    },
    {
        "type":"DG","value": 1890,
        "label": "PYRIDOXINE HCL"
    },
    {
        "type":"DG","value": 1891,
        "label": "PYRIDOXINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1892,
        "label": "RABEPRAZOLE SOD WITHSOD BICARBONATEBUFFE"
    },
    {
        "type":"DG","value": 1893,
        "label": "RABEPRAZOLE SODIUM"
    },
    {
        "type":"DG","value": 1894,
        "label": "RABEPRAZOLE SODIUM AND DOMPERIDONE"
    },
    {
        "type":"DG","value": 1895,
        "label": "RABEPRAZOLE SODIUM DOMPERIDONE"
    },
    {
        "type":"DG","value": 1896,
        "label": "RABEPRAZOLE SODIUM EC  LEVOSULPIRIDE SR"
    },
    {
        "type":"DG","value": 1897,
        "label": "RABEPROZOLE"
    },
    {
        "type":"DG","value": 1898,
        "label": "RABIES VACCINE FOR HUMAN USE"
    },
    {
        "type":"DG","value": 1899,
        "label": "RABIPRAZOLE SODIUM AND DOMPERIDONE SR"
    },
    {
        "type":"DG","value": 1900,
        "label": "RACECADROTRIL"
    },
    {
        "type":"DG","value": 1901,
        "label": "RAMIPRIL"
    },
    {
        "type":"DG","value": 1902,
        "label": "RAMIPRIL AND HYDROCHLORTHIAZIDE"
    },
    {
        "type":"DG","value": 1903,
        "label": "RAMOSETRON HCL"
    },
    {
        "type":"DG","value": 1904,
        "label": "RANITIDINE"
    },
    {
        "type":"DG","value": 1905,
        "label": "RANOLAZINE EXTENDED RELEASE TABLETS"
    },
    {
        "type":"DG","value": 1906,
        "label": "RANTIDINE"
    },
    {
        "type":"DG","value": 1907,
        "label": "RASBURICASE"
    },
    {
        "type":"DG","value": 1908,
        "label": "RECECADOTRIL"
    },
    {
        "type":"DG","value": 1909,
        "label": "RECOMBINANT HUMAN ERYTHROPOIETIN ALPHA"
    },
    {
        "type":"DG","value": 1910,
        "label": "RECOMBINANT HUMAN GRANULOCYTE COLONY"
    },
    {
        "type":"DG","value": 1911,
        "label": "RIBOFLAVINE"
    },
    {
        "type":"DG","value": 1912,
        "label": "RICE BRAN COMPOUND"
    },
    {
        "type":"DG","value": 1913,
        "label": "RICE FLOUR SUCROSE VEG FAT MALT EXTRACT"
    },
    {
        "type":"DG","value": 1914,
        "label": "RIFAMPCIN ISONIAZD PYRAZINAMID ETHAMBUTL"
    },
    {
        "type":"DG","value": 1915,
        "label": "RIFAMPICIN"
    },
    {
        "type":"DG","value": 1916,
        "label": "RIFAMPICIN ISONIAZIDE"
    },
    {
        "type":"DG","value": 1917,
        "label": "RIFAXIMIN"
    },
    {
        "type":"DG","value": 1918,
        "label": "RISPERIDONE"
    },
    {
        "type":"DG","value": 1919,
        "label": "RISPERIDONE AND TRIHEXYPHENIDYL HCL"
    },
    {
        "type":"DG","value": 1920,
        "label": "RITUXIMAB"
    },
    {
        "type":"DG","value": 1921,
        "label": "ROCURONIUM BROMIDE"
    },
    {
        "type":"DG","value": 1922,
        "label": "ROPIVACAINE HCL"
    },
    {
        "type":"DG","value": 1923,
        "label": "ROSUVASTATIN"
    },
    {
        "type":"DG","value": 1924,
        "label": "ROSUVASTATIN AND FENOFIBRATE"
    },
    {
        "type":"DG","value": 1925,
        "label": "ROSUVASTATIN CALCIUM"
    },
    {
        "type":"DG","value": 1926,
        "label": "ROXITHROMYCIN AMBROXOL"
    },
    {
        "type":"DG","value": 1927,
        "label": "ROXITHROMYCINE"
    },
    {
        "type":"DG","value": 1928,
        "label": "S ADENOSYL METHIONINE"
    },
    {
        "type":"DG","value": 1929,
        "label": "SACCHAROMYCES BOULARDI"
    },
    {
        "type":"DG","value": 1930,
        "label": "SACCHAROMYCES BOULARDII"
    },
    {
        "type":"DG","value": 1931,
        "label": "SALBUTAMOL"
    },
    {
        "type":"DG","value": 1932,
        "label": "SALIVA SUPPLEMENT"
    },
    {
        "type":"DG","value": 1933,
        "label": "SALMETEROL AND FLUTICASON PROPIONATE INH"
    },
    {
        "type":"DG","value": 1934,
        "label": "SERRATIOPEPTIDASE"
    },
    {
        "type":"DG","value": 1935,
        "label": "SERRATIOPEPTIDASE WITH DICLOFENAC SOD"
    },
    {
        "type":"DG","value": 1936,
        "label": "SERTRALINE HCL"
    },
    {
        "type":"DG","value": 1937,
        "label": "SEVELAMER CARBONATE"
    },
    {
        "type":"DG","value": 1938,
        "label": "SEVELAMER HCL"
    },
    {
        "type":"DG","value": 1939,
        "label": "SEVOFLURANE"
    },
    {
        "type":"DG","value": 1940,
        "label": "SIDIUM FUSIDATE"
    },
    {
        "type":"DG","value": 1941,
        "label": "SILVER NITRATE GEL"
    },
    {
        "type":"DG","value": 1942,
        "label": "SILVER SULFADIAZINE CHLOROHEXIDINE ALOE"
    },
    {
        "type":"DG","value": 1943,
        "label": "SITAGLIPTIN PHOSPHATE"
    },
    {
        "type":"DG","value": 1944,
        "label": "SLOW DICLOFENAC SUSTAINE RELEASE"
    },
    {
        "type":"DG","value": 1945,
        "label": "SOD BICARBONATE SOD CITRAT TARTARIC ACID"
    },
    {
        "type":"DG","value": 1946,
        "label": "SOD CARBOXYMETHYL CELLULOSE SORBITOL"
    },
    {
        "type":"DG","value": 1947,
        "label": "SOD FEREDETATE FOLIC ACID VIT B12"
    },
    {
        "type":"DG","value": 1948,
        "label": "SOD MERCAPTO ETHANE SULPHATE"
    },
    {
        "type":"DG","value": 1949,
        "label": "SOD VALPROATE"
    },
    {
        "type":"DG","value": 1950,
        "label": "SODIUM 2 SULPHANYLETHANESULPHONATE"
    },
    {
        "type":"DG","value": 1951,
        "label": "SODIUM ACID PHOSPHATE GRANULES"
    },
    {
        "type":"DG","value": 1952,
        "label": "SODIUM AMINOSALICYLATE"
    },
    {
        "type":"DG","value": 1953,
        "label": "SODIUM BI CARBONATE"
    },
    {
        "type":"DG","value": 1954,
        "label": "SODIUM FUSIDATE"
    },
    {
        "type":"DG","value": 1955,
        "label": "SODIUM NITROPRUSSIDE"
    },
    {
        "type":"DG","value": 1956,
        "label": "SODIUM PICOSULPHATE"
    },
    {
        "type":"DG","value": 1957,
        "label": "SODIUM VALPROATE"
    },
    {
        "type":"DG","value": 1958,
        "label": "SODIUM VALPROATE AND VALPROIC ACID"
    },
    {
        "type":"DG","value": 1959,
        "label": "SOLIFENACIN SUCCINATE"
    },
    {
        "type":"DG","value": 1960,
        "label": "SOMATOSTATIN"
    },
    {
        "type":"DG","value": 1961,
        "label": "SORAFENIB TOSYLATE"
    },
    {
        "type":"DG","value": 1962,
        "label": "SORBITOL AND TRICHOLINE CITRATE"
    },
    {
        "type":"DG","value": 1963,
        "label": "SPARFLOXACIN"
    },
    {
        "type":"DG","value": 1964,
        "label": "SPIRONOLACTONE"
    },
    {
        "type":"DG","value": 1965,
        "label": "SPIRULINA"
    },
    {
        "type":"DG","value": 1966,
        "label": "SPIRULINA CARBONL IRON FOLIC ACID ZN VIT"
    },
    {
        "type":"DG","value": 1967,
        "label": "STANOZOLOL"
    },
    {
        "type":"DG","value": 1968,
        "label": "STAVUDINE"
    },
    {
        "type":"DG","value": 1969,
        "label": "STERILE NORADRENALINE CONCENTRATE"
    },
    {
        "type":"DG","value": 1970,
        "label": "STREPTOMYCIN"
    },
    {
        "type":"DG","value": 1971,
        "label": "SUCCINYL CHOLINE CHLORIDE"
    },
    {
        "type":"DG","value": 1972,
        "label": "SUCRALFATE AND OXETACAINE"
    },
    {
        "type":"DG","value": 1973,
        "label": "SUCRALFATE SUSPENSION"
    },
    {
        "type":"DG","value": 1974,
        "label": "SUGAR FREE BUFFERED SORBITOL"
    },
    {
        "type":"DG","value": 1975,
        "label": "SULBACTUM AND CEFOPERAZONE"
    },
    {
        "type":"DG","value": 1976,
        "label": "SUMINATRIPTAN SUCCINATE"
    },
    {
        "type":"DG","value": 1977,
        "label": "SUNITINIB MALATE"
    },
    {
        "type":"DG","value": 1978,
        "label": "SUPER OXIDIZED SOLUTION"
    },
    {
        "type":"DG","value": 1979,
        "label": "SUSTAINED RELEASE METFORMIN HCL"
    },
    {
        "type":"DG","value": 1980,
        "label": "sustained released diclofenac"
    },
    {
        "type":"DG","value": 1981,
        "label": "TAMOXIFEN CITRATE"
    },
    {
        "type":"DG","value": 1982,
        "label": "TAMSULOSIN HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 1983,
        "label": "TAPENTADOL"
    },
    {
        "type":"DG","value": 1984,
        "label": "TEGAFUR AND URACIL"
    },
    {
        "type":"DG","value": 1985,
        "label": "TEGASEROD MALEATE"
    },
    {
        "type":"DG","value": 1986,
        "label": "TEICOPLANIN"
    },
    {
        "type":"DG","value": 1987,
        "label": "TELMISARTAN"
    },
    {
        "type":"DG","value": 1988,
        "label": "TELMISARTAN AND AMLODIPINE BESILATE"
    },
    {
        "type":"DG","value": 1989,
        "label": "TELMISARTAN AND CHLORTHALIDONE"
    },
    {
        "type":"DG","value": 1990,
        "label": "TEMOZOLOMIDE"
    },
    {
        "type":"DG","value": 1991,
        "label": "TEMSIROLIMUS"
    },
    {
        "type":"DG","value": 1992,
        "label": "TENOFOVIR DISOPROXIL FUMARATE"
    },
    {
        "type":"DG","value": 1993,
        "label": "TERAZOSIN"
    },
    {
        "type":"DG","value": 1994,
        "label": "TERBINAFINE"
    },
    {
        "type":"DG","value": 1995,
        "label": "TERBUTALIN BROMOHEXINE GUAIPHENESIN"
    },
    {
        "type":"DG","value": 1996,
        "label": "TERBUTALINE"
    },
    {
        "type":"DG","value": 1997,
        "label": "TERBUTALINE SULPHATE BROMHEXINE"
    },
    {
        "type":"DG","value": 1998,
        "label": "TERBUTALINE SULPHATE BROMHEXINE AND HCL"
    },
    {
        "type":"DG","value": 1999,
        "label": "TERLIPRESSIN"
    },
    {
        "type":"DG","value": 2000,
        "label": "TESTOSTERONE"
    },
    {
        "type":"DG","value": 2001,
        "label": "TETANUS VACCINE"
    },
    {
        "type":"DG","value": 2002,
        "label": "TETRACYCLINE"
    },
    {
        "type":"DG","value": 2003,
        "label": "THALIDOMIDE"
    },
    {
        "type":"DG","value": 2004,
        "label": "THEOPHYLLINE CONTROLLED RELEASE"
    },
    {
        "type":"DG","value": 2005,
        "label": "THIAMINE HCL"
    },
    {
        "type":"DG","value": 2006,
        "label": "THIAMINE YRIDOXINE B12 RIBOFLAVIN NICOTI"
    },
    {
        "type":"DG","value": 2007,
        "label": "THIOGUANINE"
    },
    {
        "type":"DG","value": 2008,
        "label": "THIOPENTONE SODIUM"
    },
    {
        "type":"DG","value": 2009,
        "label": "THYROTROPIN ALFA"
    },
    {
        "type":"DG","value": 2010,
        "label": "THYROXINE SODIUM"
    },
    {
        "type":"DG","value": 2011,
        "label": "TICARCILLIN AND CLAVULANIC ACID"
    },
    {
        "type":"DG","value": 2012,
        "label": "TIGECYCLINE"
    },
    {
        "type":"DG","value": 2013,
        "label": "TINIDAZOLE"
    },
    {
        "type":"DG","value": 2014,
        "label": "TIOTROPIUM BROMIDE"
    },
    {
        "type":"DG","value": 2015,
        "label": "TOBRAMYCIN SULPHATE"
    },
    {
        "type":"DG","value": 2016,
        "label": "TOCOTRIENOLS WHEAT GERM OIL COD LIVER OI"
    },
    {
        "type":"DG","value": 2017,
        "label": "TOLTERODINE TARTARATE EXTENDED RELEASE"
    },
    {
        "type":"DG","value": 2018,
        "label": "TOLTERODINE TARTRATE TAMSULOSIN HCL"
    },
    {
        "type":"DG","value": 2019,
        "label": "TOLVAPTAN"
    },
    {
        "type":"DG","value": 2020,
        "label": "TOPIRAMATE"
    },
    {
        "type":"DG","value": 2021,
        "label": "TOPOTECAN INJ"
    },
    {
        "type":"DG","value": 2022,
        "label": "TORSEMIDE"
    },
    {
        "type":"DG","value": 2023,
        "label": "TORSEMIDE AND SPIRANOLACTONE"
    },
    {
        "type":"DG","value": 2024,
        "label": "TORTERODINE TARTARATE"
    },
    {
        "type":"DG","value": 2025,
        "label": "TRABECTEDIN POWDER"
    },
    {
        "type":"DG","value": 2026,
        "label": "TRACE ELEMENTS INJECTION"
    },
    {
        "type":"DG","value": 2027,
        "label": "TRAMADOL HCL AND ACETAMINOPHEN DISPERSIB"
    },
    {
        "type":"DG","value": 2028,
        "label": "TRAMADOL HYDROCHLORIDE AND PARACETAMOL"
    },
    {
        "type":"DG","value": 2029,
        "label": "TRANEXAMIC ACID"
    },
    {
        "type":"DG","value": 2030,
        "label": "TRANEXAMIV ACID AND MEFENAMIC ACID"
    },
    {
        "type":"DG","value": 2031,
        "label": "TRANSMUCOSAL FENTANYL"
    },
    {
        "type":"DG","value": 2032,
        "label": "TRASTUZUMAB"
    },
    {
        "type":"DG","value": 2033,
        "label": "TRIAMCINOLONE ACETONIDE"
    },
    {
        "type":"DG","value": 2034,
        "label": "TRICLOFOS"
    },
    {
        "type":"DG","value": 2035,
        "label": "TRIHEXYPHENIDYL HCL"
    },
    {
        "type":"DG","value": 2036,
        "label": "TRIHEXYPHENIDYL HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 2037,
        "label": "TRIMETAZIDIN DI HCL MODFIED RELEASE"
    },
    {
        "type":"DG","value": 2038,
        "label": "TRIMETHOPRIM AND SULPHAMETHOXAZOLE"
    },
    {
        "type":"DG","value": 2039,
        "label": "TRIPTORELIN"
    },
    {
        "type":"DG","value": 2040,
        "label": "TROXERUTIN"
    },
    {
        "type":"DG","value": 2041,
        "label": "TROXERUTIN  CALCIUM BOBESILATE"
    },
    {
        "type":"DG","value": 2042,
        "label": "TROXERUTIN CAL DOBESILATE Zn LIGNOCAIN H"
    },
    {
        "type":"DG","value": 2043,
        "label": "TROXERUTIN CALCIUM DOBESILATE ZINC PHENY"
    },
    {
        "type":"DG","value": 2044,
        "label": "TRYPSIN BROMELAIN RUTOSIDE TRIHYDRATE"
    },
    {
        "type":"DG","value": 2045,
        "label": "TRYPSIN CHYMOTRYPSIN"
    },
    {
        "type":"DG","value": 2046,
        "label": "TRYPSIN CHYMOTRYPSIN AND DICLOFENAC POT"
    },
    {
        "type":"DG","value": 2047,
        "label": "TYGECYCLINE"
    },
    {
        "type":"DG","value": 2048,
        "label": "UBIDECARENON AR TOCOPHEROL SELENIUM"
    },
    {
        "type":"DG","value": 2049,
        "label": "UBIQUINONE"
    },
    {
        "type":"DG","value": 2050,
        "label": "UBIQUINONE AND PIPPERINE"
    },
    {
        "type":"DG","value": 2051,
        "label": "UBIQUINONE EICOSAPENTAENOIC ACID LYCOPEN"
    },
    {
        "type":"DG","value": 2052,
        "label": "ULINASTATIN"
    },
    {
        "type":"DG","value": 2053,
        "label": "ULTRASOUND TRANSMISSION GEL"
    },
    {
        "type":"DG","value": 2054,
        "label": "UREA AND LACTIC ACID"
    },
    {
        "type":"DG","value": 2055,
        "label": "URSODEOXYCHOLIC ACID"
    },
    {
        "type":"DG","value": 2056,
        "label": "URSODIOL"
    },
    {
        "type":"DG","value": 2057,
        "label": "VALSARTAN"
    },
    {
        "type":"DG","value": 2058,
        "label": "VANCOMYCIN HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 2059,
        "label": "VECURONIUM BROMIDE"
    },
    {
        "type":"DG","value": 2060,
        "label": "VERAPAMIL"
    },
    {
        "type":"DG","value": 2061,
        "label": "VILDAGLIPTIN AND METFORMIN HCL"
    },
    {
        "type":"DG","value": 2062,
        "label": "VINBLASTIN"
    },
    {
        "type":"DG","value": 2063,
        "label": "VINCRISTINE"
    },
    {
        "type":"DG","value": 2064,
        "label": "VINORELBINE"
    },
    {
        "type":"DG","value": 2065,
        "label": "VIT A B COMPLEX  D E MINERALS  ZINC"
    },
    {
        "type":"DG","value": 2066,
        "label": "VIT B1 B6 B12 AND D PANTHENOL"
    },
    {
        "type":"DG","value": 2067,
        "label": "VIT B12"
    },
    {
        "type":"DG","value": 2068,
        "label": "VIT C AND ZINC"
    },
    {
        "type":"DG","value": 2069,
        "label": "VIT E ACETATE AND LEVOCARNITINE"
    },
    {
        "type":"DG","value": 2070,
        "label": "VITA D B COMPLEX E C ZINC AND POT IODIDE"
    },
    {
        "type":"DG","value": 2071,
        "label": "VITAMIN B COMPLEX"
    },
    {
        "type":"DG","value": 2072,
        "label": "VITAMIN D3"
    },
    {
        "type":"DG","value": 2073,
        "label": "VITAMIN K2 7 CALCIUM CALCITRIOL ZINC AND"
    },
    {
        "type":"DG","value": 2074,
        "label": "VITAMINES  MINERALS  ZINC"
    },
    {
        "type":"DG","value": 2075,
        "label": "VITAMINES GINSENG AND MINERALS"
    },
    {
        "type":"DG","value": 2076,
        "label": "VITAMINS NATURAL EXTRACTS MINERALS A"
    },
    {
        "type":"DG","value": 2077,
        "label": "VITAMINS WITH AMINOACIDS AND MINERALS"
    },
    {
        "type":"DG","value": 2078,
        "label": "VOGLIBOSE"
    },
    {
        "type":"DG","value": 2079,
        "label": "VORICONAZOLE"
    },
    {
        "type":"DG","value": 2080,
        "label": "WARFARIN SODIUM"
    },
    {
        "type":"DG","value": 2081,
        "label": "WATER GLYCERINE CELLULOSE GUM SOD SACCHA"
    },
    {
        "type":"DG","value": 2082,
        "label": "XYLOMETAZOLINE HCL"
    },
    {
        "type":"DG","value": 2083,
        "label": "ZIDOVUDINE"
    },
    {
        "type":"DG","value": 2084,
        "label": "ZOLEDRONIC ACID"
    },
    {
        "type":"DG","value": 2085,
        "label": "ZOLPIDEM TARTRATE"
    },
    {
        "type":"DG","value": 2086,
        "label": "NA"
    },
    {
        "type":"DG","value": 2087,
        "label": "ATORVASTIN"
    },
    {
        "type":"DG","value": 2088,
        "label": "PAMIDRONATE DISODIUM"
    },
    {
        "type":"DG","value": 2089,
        "label": "CALAMINE & DIPHENHYDRAMINE CHLORIDE"
    },
    {
        "type":"DG","value": 2090,
        "label": "CEFPODOXIME PROXETIL"
    },
    {
        "type":"DG","value": 2091,
        "label": "CHLOROMYCETIN"
    },
    {
        "type":"DG","value": 2092,
        "label": "LACTO BACILLUS"
    },
    {
        "type":"DG","value": 2093,
        "label": "ACETYLSALICYLLIC ACID EFFERVECENT"
    },
    {
        "type":"DG","value": 2094,
        "label": "DROTAVARINE"
    },
    {
        "type":"DG","value": 2095,
        "label": "SODIUM PHOSPHATE"
    },
    {
        "type":"DG","value": 2096,
        "label": "BENZOYLMETRONIDAZOLE"
    },
    {
        "type":"DG","value": 2097,
        "label": "FORMALIN"
    },
    {
        "type":"DG","value": 2098,
        "label": "PHENYLEPHERINE HCL"
    },
    {
        "type":"DG","value": 2099,
        "label": "FERROUS GLYCINE SULPHATE & FOLIC ACID &C"
    },
    {
        "type":"DG","value": 2100,
        "label": "TINOCARDIN"
    },
    {
        "type":"DG","value": 2101,
        "label": "METHYLERGOMETRINE"
    },
    {
        "type":"DG","value": 2102,
        "label": "METHYLENE BLUE"
    },
    {
        "type":"DG","value": 2103,
        "label": "MIRTAZAPINA"
    },
    {
        "type":"DG","value": 2104,
        "label": "SODIUM CHLORIDE"
    },
    {
        "type":"DG","value": 2105,
        "label": "NITRAZEPAM"
    },
    {
        "type":"DG","value": 2106,
        "label": "SALINE NASAL SOLUTION"
    },
    {
        "type":"DG","value": 2107,
        "label": "POTASIUM CITRATE AND CITRIC ACID"
    },
    {
        "type":"DG","value": 2108,
        "label": "QUETIPINE"
    },
    {
        "type":"DG","value": 2109,
        "label": "AMITRIPTYLINE HCL"
    },
    {
        "type":"DG","value": 2110,
        "label": "METAXALONE AND DICLOFENAC POTASSIUM"
    },
    {
        "type":"DG","value": 2111,
        "label": "VALACYCLOVIR"
    },
    {
        "type":"DG","value": 2112,
        "label": "DESFLURANE INHALATION"
    },
    {
        "type":"DG","value": 2113,
        "label": "VASOPRESSIN"
    },
    {
        "type":"DG","value": 2114,
        "label": "CALCITRIOL"
    },
    {
        "type":"DG","value": 2115,
        "label": "BECLOMETHASONE PHENYLEPHRINE LIGNOCAINE"
    },
    {
        "type":"DG","value": 2116,
        "label": "NUTRIENT ADMIX FOR HEPATIC FAILURE"
    },
    {
        "type":"DG","value": 2117,
        "label": "AYURVEDIC APETIZER"
    },
    {
        "type":"DG","value": 2118,
        "label": "ROMOSETRON HCL"
    },
    {
        "type":"DG","value": 2119,
        "label": "DARIFENACIN HYDRO BROMIDE"
    },
    {
        "type":"DG","value": 2120,
        "label": "GANCICLOVIR"
    },
    {
        "type":"DG","value": 2121,
        "label": "SUXAMETHONIUM"
    },
    {
        "type":"DG","value": 2122,
        "label": "IVABRADINE TAB"
    },
    {
        "type":"DG","value": 2123,
        "label": "BACILLUS CLAUSII SPORES SUSPENSION"
    },
    {
        "type":"DG","value": 2124,
        "label": "MONTALEUCAST SODIUM"
    },
    {
        "type":"DG","value": 2125,
        "label": "PHENOXYBENZAMINE HCL"
    },
    {
        "type":"DG","value": 2126,
        "label": "FULVESTRANT"
    },
    {
        "type":"DG","value": 2127,
        "label": "ACETYLCYSTEINE"
    },
    {
        "type":"DG","value": 2128,
        "label": "ETORICOXIB"
    },
    {
        "type":"DG","value": 2129,
        "label": "NUTRIENT ADMIX FOR RENAL FAILURE"
    },
    {
        "type":"DG","value": 2130,
        "label": "TRIPLE CHAMBER (CENTRAL-BIG)"
    },
    {
        "type":"DG","value": 2131,
        "label": "IVABRADINE"
    },
    {
        "type":"DG","value": 2132,
        "label": "RINGER LACTATE SOLUTION"
    },
    {
        "type":"DG","value": 2133,
        "label": "MANNITOL"
    },
    {
        "type":"DG","value": 2134,
        "label": "0.9% SODIUM CHLORIDE AND 5% DEXTROSE 500"
    },
    {
        "type":"DG","value": 2135,
        "label": "CRIZOTINIB"
    },
    {
        "type":"DG","value": 2136,
        "label": "POTASSIUM PHOSPHATES"
    },
    {
        "type":"DG","value": 2137,
        "label": "PENTOSAN POLYSULFATE SODIUM"
    },
    {
        "type":"DG","value": 2138,
        "label": "SODIUM 2 SUPHANYLETHANESULPHONATE"
    },
    {
        "type":"DG","value": 2139,
        "label": "CEFPODOXIME,DICLOXACILLIN"
    },
    {
        "type":"DG","value": 2140,
        "label": "PREGALIN"
    },
    {
        "type":"DG","value": 2141,
        "label": "ACECLOFENAC AND RABEPRAZOLE"
    },
    {
        "type":"DG","value": 2142,
        "label": "AFATINIB DIMALEATE"
    },
    {
        "type":"DG","value": 2143,
        "label": "MENADIONE SODIUM BISULPHITE"
    },
    {
        "type":"DG","value": 2144,
        "label": "ALL TRANS RETINOIC ACID"
    },
    {
        "type":"DG","value": 2145,
        "label": "SUPERSATURATED CALCIUM PHOSPHATE RINSE"
    },
    {
        "type":"DG","value": 2146,
        "label": "PERTUZUMAB"
    },
    {
        "type":"DG","value": 2147,
        "label": "BOTULINUM TOXIN TYPE A"
    },
    {
        "type":"DG","value": 2148,
        "label": "ALCID"
    },
    {
        "type":"DG","value": 2149,
        "label": "POLYETHYLENE GLYCOL 3350 POWDER"
    },
    {
        "type":"DG","value": 2150,
        "label": "CILNIDIPINE"
    },
    {
        "type":"DG","value": 2151,
        "label": "POLYMYXIN B"
    },
    {
        "type":"DG","value": 2152,
        "label": "ANTACID ANTIGAS LIQUID"
    },
    {
        "type":"DG","value": 2153,
        "label": "SEMI ELEMENTAL FORMULAS"
    },
    {
        "type":"DG","value": 2154,
        "label": "AZACYTADINE"
    },
    {
        "type":"DG","value": 2155,
        "label": "VITAMIN - A"
    },
    {
        "type":"DG","value": 2156,
        "label": "IBRUTINIB"
    },
    {
        "type":"DG","value": 2157,
        "label": "DISODIUM HYDROGEN CITRATE"
    },
    {
        "type":"DG","value": 2158,
        "label": "INSULIN GLARGINE INJECTION"
    },
    {
        "type":"DG","value": 2159,
        "label": "CHORZOXAZONE AND PARACETAMOL"
    },
    {
        "type":"DG","value": 2160,
        "label": "OXYMETAZOLINE HYDROCHLORIDE NASAL SOLUTI"
    },
    {
        "type":"DG","value": 2161,
        "label": "POLYVINYL ALCOHOL"
    },
    {
        "type":"DG","value": 2162,
        "label": "ATENOLOL AND CHLORTHALIDONE"
    },
    {
        "type":"DG","value": 2163,
        "label": "TELMISARTAN AND AMLODIPINE"
    },
    {
        "type":"DG","value": 2164,
        "label": "PANTOPRAZOLE SODIUM AND ITOPRIDE HCL"
    },
    {
        "type":"DG","value": 2165,
        "label": "AYURVEDIC  APETIZER"
    },
    {
        "type":"DG","value": 2166,
        "label": "PREDNISOLONE ACETATE OPTHALMIC"
    },
    {
        "type":"DG","value": 2167,
        "label": "CEFOPERAZONE AND SULBACTUM"
    },
    {
        "type":"DG","value": 2168,
        "label": "FOSFESTROL"
    },
    {
        "type":"DG","value": 2169,
        "label": "ANTACID ANTIFLATULENT"
    },
    {
        "type":"DG","value": 2170,
        "label": "CEFAPODOXIME"
    },
    {
        "type":"DG","value": 2171,
        "label": "PARACETAMOL PAEDIATRIC"
    },
    {
        "type":"DG","value": 2172,
        "label": "MULTIVITAMIN  MULTIMINERAL"
    },
    {
        "type":"DG","value": 2173,
        "label": "QUETIAPINE FUMARATE"
    },
    {
        "type":"DG","value": 2174,
        "label": "QUETIAPINE"
    },
    {
        "type":"DG","value": 2175,
        "label": "ARMODAFINIL"
    },
    {
        "type":"DG","value": 2176,
        "label": "AMIODARONE"
    },
    {
        "type":"DG","value": 2177,
        "label": "ENOXAPARIN"
    },
    {
        "type":"DG","value": 2178,
        "label": "N-ACETYL CYSTIENE"
    },
    {
        "type":"DG","value": 2179,
        "label": "BENDAMUSTINE"
    },
    {
        "type":"DG","value": 2180,
        "label": "BORTEZOMIB"
    },
    {
        "type":"DG","value": 2181,
        "label": "DARBEPOETIN"
    },
    {
        "type":"DG","value": 2182,
        "label": "DOXORUBICIN HCL (LIPOSOME))"
    },
    {
        "type":"DG","value": 2183,
        "label": "HYDROXYUREA"
    },
    {
        "type":"DG","value": 2184,
        "label": "IFOSFAMIDE WITH MESNA"
    },
    {
        "type":"DG","value": 2185,
        "label": "IRINOTECAM"
    },
    {
        "type":"DG","value": 2186,
        "label": "LEU.CALCIUM"
    },
    {
        "type":"DG","value": 2187,
        "label": "SORAFENIB"
    },
    {
        "type":"DG","value": 2188,
        "label": "TOPOTECAN"
    },
    {
        "type":"DG","value": 2189,
        "label": "MITOMYCIN-C"
    },
    {
        "type":"DG","value": 2190,
        "label": "DEXTROSE"
    },
    {
        "type":"DG","value": 2191,
        "label": "MULTIPLE ELECTROLYTES AND DEXTROSE"
    },
    {
        "type":"DG","value": 2192,
        "label": "INSULIN DEGLUDEC / INSULIN ASPART"
    },
    {
        "type":"DG","value": 2193,
        "label": "LACOSAMIDE"
    },
    {
        "type":"DG","value": 2194,
        "label": "CARBONYL ITEON FOLIC ACID & ZINC"
    },
    {
        "type":"DG","value": 2195,
        "label": "ALPRAZOLAM & MELATONIN"
    },
    {
        "type":"DG","value": 6195,
        "label": "CEFPIROME SULPHATE"
    },
    {
        "type":"DG","value": 6196,
        "label": "METOPROLOL SUCCINATE ER"
    },
    {
        "type":"DG","value": 6197,
        "label": "RABEPRAZOLE SODIUM & SUSTAINED RELEASE LEVOSULPIRIDE"
    },
    {
        "type":"DG","value": 6198,
        "label": "FLUCONAZOLE"
    },
    {
        "type":"DG","value": 6199,
        "label": "TAMSULOSIN (0.4 MG) AND DUTASTERIDE (0.5 MG)"
    },
    {
        "type":"DG","value": 6200,
        "label": "TRASTUZUMAB EMTANSINE"
    },
    {
        "type":"DG","value": 6201,
        "label": "METHYLPREDNISOLONE ACETATE"
    },
    {
        "type":"DG","value": 6202,
        "label": "DIPHENHYDRAMINE HCL, AMMONIUM CHLORIDE, SODIUM CITRATE"
    },
    {
        "type":"DG","value": 6203,
        "label": "DOMPERIDONE AND NAPROXEN SODIUM"
    },
    {
        "type":"DG","value": 6204,
        "label": "WHEY PROTEIN"
    },
    {
        "type":"DG","value": 6205,
        "label": "VITAMINS AND MINERALS"
    },
    {
        "type":"DG","value": 6206,
        "label": "LYCOPENE, BETACAROTENE, SELENIUM, ZINC SULPHATE ALPHA LIPOIC ACID & ALPHA TOCOPHERYL ACETATE"
    },
    {
        "type":"DG","value": 6207,
        "label": "CARBOXYMETHYLCELLULOSE"
    },
    {
        "type":"DG","value": 6208,
        "label": "AMOXYCILLN"
    },
    {
        "type":"DG","value": 6209,
        "label": "DOXYCYCLINE AND LACTIC ACID BACILLUS"
    },
    {
        "type":"DG","value": 6210,
        "label": "COD LIVER OIL"
    },
    {
        "type":"DG","value": 6211,
        "label": "FUNGAL DIASTASE AND ACTIVATED CHARCOAL"
    },
    {
        "type":"DG","value": 6212,
        "label": "CALCIUM WITH VITAMIN D3"
    },
    {
        "type":"DG","value": 6213,
        "label": "DIPHENHYDRAMINE HCL AMMONIUM CHLORIDE SODIUM CITRATE & MENTHOL"
    },
    {
        "type":"DG","value": 6214,
        "label": "CHLORPHENIRAMINE MALEATE, DEXTROMETHORPHAN HYDROBROMIDE & PHENYLEPHRINE HCL"
    },
    {
        "type":"DG","value": 6215,
        "label": "CLOTRIMAZOLE VAGINAL"
    },
    {
        "type":"DG","value": 6216,
        "label": "DESMOPRESSIN ACETATE"
    },
    {
        "type":"DG","value": 6217,
        "label": "ALUMINIUM HYDROXIDE, MAGNESIUM HYDROXIDE, ACTIVATED DIMETHICONE AND SORBITOL"
    },
    {
        "type":"DG","value": 6218,
        "label": "RABEPRAZOLE SODIUM & LEVOSULPIRIDE SUSTAINED RELEASE"
    },
    {
        "type":"DG","value": 6219,
        "label": "TESTOSTERONE UNDECANOATE"
    },
    {
        "type":"DG","value": 6220,
        "label": "PALBOCICLIB"
    },
    {
        "type":"DG","value": 6221,
        "label": "FERROUS ASCORBATE & FOLIC ACID"
    },
    {
        "type":"DG","value": 6222,
        "label": "DIMETHICONE ZINC OXIDE CALAMINE & CETRIMIDE"
    },
    {
        "type":"DG","value": 6223,
        "label": "RIVAROXABAN"
    },
    {
        "type":"DG","value": 6224,
        "label": "COMPOUND DITHRANOL"
    },
    {
        "type":"DG","value": 6225,
        "label": "ADHESION BARRIER MATRIX"
    },
    {
        "type":"DG","value": 6226,
        "label": "FLUCONAZOLE DISPERSIBLE"
    },
    {
        "type":"DG","value": 6227,
        "label": "OCTREOTIDE"
    },
    {
        "type":"DG","value": 6228,
        "label": "MICAFUNGIN"
    },
    {
        "type":"DG","value": 6229,
        "label": "REGORAFENIB"
    },
    {
        "type":"DG","value": 6230,
        "label": "HYDROCHLOROTHIAZIDE"
    },
    {
        "type":"DG","value": 6231,
        "label": "WHITE SOFT PARAFFIN LIQUID PARAFFIN ALOE VERA CREAM BASE"
    },
    {
        "type":"DG","value": 6232,
        "label": "CEFTAZIDIME 2GM + TAZOBACTAM 0.25GM"
    },
    {
        "type":"DG","value": 6233,
        "label": "DOXYCYCLINE HCL & LACTIC ACID BACILLUS"
    },
    {
        "type":"DG","value": 2273,
        "label": "RAMUCIRUMAB"
    },
    {
        "type":"DG","value": 2472,
        "label": "HUMAN RECOMBINANT COAGULATION FACTOR VII"
    },
    {
        "type":"DG","value": 2473,
        "label": "HUMAN RECOMBINANT COAGULATION FACTOR VII"
    },
    {
        "type":"DG","value": 2474,
        "label": "AMOXICILLIN  AND  POTASSIUM CLAVULANATE"
    },
    {
        "type":"DG","value": 2475,
        "label": "INDOCYANINE GREEN"
    },
    {
        "type":"DG","value": 2476,
        "label": "LOW CALORIE SUGAR SUBSTITUTE"
    },
    {
        "type":"DG","value": 2477,
        "label": "AMOXYCILLIN AND POTASSIUM CLAVULANATE"
    },
    {
        "type":"DG","value": 2478,
        "label": "ETHAMBUTOL HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 2479,
        "label": "DIGESTIVE ENZYME LIQUID"
    },
    {
        "type":"DG","value": 2480,
        "label": "HUMAN NORMAL IMMUNOGLOBULIN"
    },
    {
        "type":"DG","value": 2481,
        "label": "DOXYCYCLINE HCL WITH BETACYCLODEXTRIN"
    },
    {
        "type":"DG","value": 2482,
        "label": "CIPROFLOXACIN HCL"
    },
    {
        "type":"DG","value": 2483,
        "label": "DULOXETINE DELAYED  RELEASE"
    },
    {
        "type":"DG","value": 2555,
        "label": "RECOMBINANT HUMAN ERYTHROPOIETIN"
    },
    {
        "type":"DG","value": 3109,
        "label": "LIDOCAINE HCL"
    },
    {
        "type":"DG","value": 4258,
        "label": "CARBAMAZEPINE"
    },
    {
        "type":"DG","value": 4513,
        "label": "FAROPENEM SODIUM"
    },
    {
        "type":"DG","value": 5110,
        "label": "LACTULOSE SOLUTION"
    },
    {
        "type":"DG","value": 6181,
        "label": "PHENYLEPHRINE HCL AND CHLORPHENIRAMINE MALEATE"
    },
    {
        "type":"DG","value": 6182,
        "label": "PHENYLEPHRINE  HCL AND  CHLORPHENIRAMINE MALEATE"
    },
    {
        "type":"DG","value": 6183,
        "label": "GLYCOPYRROLATE"
    },
    {
        "type":"DG","value": 6184,
        "label": "THIOCOLCHICOSIDE"
    },
    {
        "type":"DG","value": 6185,
        "label": "PYRIDOXINE HCL, NICOTINAMIDE, CYANOCOBALAMIN, FOLIC ACID WITH CHROMIUM, ZINC AND SELENIUM"
    },
    {
        "type":"DG","value": 6186,
        "label": "VITAMINS AND MINERALS WITH ANTIOXIDANTS"
    },
    {
        "type":"DG","value": 6187,
        "label": "CALCIUM WITH ALFACALCIDOL"
    },
    {
        "type":"DG","value": 6188,
        "label": "POLYETHYLENE GLYCOL 3350"
    },
    {
        "type":"DG","value": 6189,
        "label": "OLMESARTAN MEDOXOMIL AND HCL THIAZIDE"
    },
    {
        "type":"DG","value": 6190,
        "label": "NIVOLUMAB"
    },
    {
        "type":"DG","value": 6191,
        "label": "NORTRIPTYLINE HYDROCHLORIDE"
    },
    {
        "type":"DG","value": 6192,
        "label": "ETTHMBUTL RIFAMPICN ISONIAZD PYRIZINAMID"
    },
    {
        "type":"DG","value": 6193,
        "label": "PARACETAMOL DISPERSIBLE"
    },
    {
        "type":"DG","value": 6194,
        "label": "ENRICHED WITH ELECTROLYTES"
    },
    {
        "type":"DG","value": 5962,
        "label": "L-ALANYL-L-GLUTAMINE SOLUTION FOR INFUSI"
    },
    {
        "type":"DG","value": 5963,
        "label": "CALCIUM AND PHOSPHORUS WITH VITAMIN D3"
    },
    {
        "type":"DG","value": 5964,
        "label": "CEFEPIME & TAZOBACTAM"
    },
    {
        "type":"DG","value": 5965,
        "label": "ELECTROLYTE"
    },
    {
        "type":"DG","value": 5966,
        "label": "HYDROXYPROGESTERONE"
    },
    {
        "type":"DG","value": 6177,
        "label": "TOLPERISONE HYDROCHLORIDE & DICLOFENAC SODIUM"
    },
    {
        "type":"DG","value": 6178,
        "label": "DEXTROMETHORPHAN HYDROBROMIDE & CHLORPHENIRAMINE MALEATE"
    },
    {
        "type":"DG","value": 6179,
        "label": "AMBROXOL HCL  AND  LEVOSALBUTAMOL SULPHATE"
    },
    {
        "type":"DG","value": 6180,
        "label": "PHENYLEPHRINE HCLNAPHAZOLINE HCL MENTHOL AND CAMPHOR OPHTHALMIC SOLUTION"
    },
    {
        "type":"DG","value": 6176,
        "label": "ANTISEPTIC, ANALGESIC, ASTRINGENT, DEMULSCENT"
    }
]