﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace GHMS.DOCTOR.Helpers
{
    public static class Constants
    {
        public static string API_DOCTOR_BASE_URL = Convert.ToString(ConfigurationManager.AppSettings["DOCTOR_API_BASE_URL"]);
        public static string API_RESPONSE_SUCCESS = "SUCCESS";        
        public static string CREATE_SUCCESS_MSG = "Created Sucessfully.";
        public static string CREATE_ERROR_MSG = "Error encountered while creating.";
        public static string UPDATE_SUCCESS_MSG = "Updated Sucessfully";
        public static string UPDATE_ERROR_MSG = "Error encountered while updating.";
    }
}