﻿using GHMS.DOCTOR.SERVICE.Repository;
using GHMS.DOCTOR.SERVICE.Repository.Implementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace GHMS.DOCTOR.SERVICE
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            var container = new UnityContainer();           
            container.RegisterType<IPatientRepository, PatientRespository>();
            container.RegisterType<IAssesmentRepository, AssesmentRepository>();
            container.RegisterType<IVisitRepository, VisitRepository>();
            container.RegisterType<IFollowupRepository, FollowupRepository>();
            container.RegisterType<IVisitRepository, VisitRepository>();
            container.RegisterType<IDrugRepository, DrugRepository>();
            container.RegisterType<IServiceRepository, ServiceRepository>();

            config.DependencyResolver = new UnityDependencyResolver(container);
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
