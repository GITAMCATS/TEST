﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class Assessment
    {
        public int INITIAL_ASSESMENT_ID { get; set; }
        public string PATIENT_ID { get; set; }      
        public string CHIEF_COMPLAINTS { get; set; }
        public string TREATMENT_HISTORY { get; set; }
        public string ILLNESS_HISTORY { get; set; }
        public string ALLERGIRS_MEDICATIONS { get; set; }
        public string FAMILY_HISTORY { get; set; }
        public string PERSONAL_HISTORY { get; set; }
        public string MENSTRUAL_HISTORY { get; set; }
        public string NUTRITIONAL_SCREENING { get; set; }
        public short DIET { get; set; }
        public decimal HEIGHT { get; set; }
        public string HEIGHT_UOM { get; set; }
        public decimal WEIGHT { get; set; }
        public string WEIGHT_UOM { get; set; }
        public decimal BMI { get; set; }
        public decimal BSA { get; set; }
        public string CLINICAL_NUTRITION_STATUS { get; set; }
        public string CLINICAL_EXAMINATION { get; set; }
        public string SYSTEMIC_EXAMINATION { get; set; }
        public string PROVISIONAL_DIAGNOSIS { get; set; }
        public string PROVISIONAL_STAGE { get; set; }
        public string INVESTIGATIONS { get; set; }
        public string FINAL_DIAGNOSIS { get; set; }
        public string FINAL_STAGE { get; set; }
        public string PLAN_OF_CARE { get; set; }
        public short TREATMENT_INTENT { get; set; }
        public string PREVENTIVE_ASPECTS { get; set; }
        public DateTime DT_TIME { get; set; }
        public string LOCAL_EXAMINATION { get; set; }
        public int CONSULTANT_ID { get; set; }
        public int CREATED_BY { get; set; }
        public DateTime CREATED_DT_TIME { get; set; }
        public bool SIGN_OFF { get; set; }
        public string CONSULTANT_NAME { get; set; }
        public string CREATED_BY_NAME { get; set; }
    }
}
