﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class Visit
    {
        public int ID { get; set; }
        public int VISIT_ID { get; set; }
        public string PATIENT_ID { get; set; }
        public string VISIT_TYPE { get; set; }
        public DateTime VISIT_DATE { get; set; }
        public int PREVIOUS_VISIT_ID { get; set; }
        public int CONSULTANT_ID { get; set; }
        public int ADMITTING_DEPT_ID { get; set; }
        public int CREATED_BY { get; set; }
        public DateTime CREATED_DT_TIME { get; set; }
        public string VISIT_CATEGORY { get; set; }
        public string STATUS { get; set; }
        public string CONSULTANT_NAME { get; set; }
        public string ADMITTING_DEPT_NAME { get; set; }
    }
}
