﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class Patient
    {
        public int ID { get; set; }
        public string PATIENT_ID { get; set; }
        public string PATIENT_TYPE_ID { get; set; }
        public string TITLE { get; set; }
        public string FIRST_NAME { get; set; }
        public string MIDDLE_NAME { get; set; }
        public string LAST_NAME { get; set; }
        public DateTime DOB { get; set; }
        public string GENDER { get; set; }
        public string MARITAL_STATUS { get; set; }
        public string FATHER_NAME { get; set; }
        public string MOTHER_NAME { get; set; }
        public string RELIGION { get; set; }
        public string NATIONALITY { get; set; }
        public string MOTHER_TONGUE { get; set; }
        public string EDUCATION { get; set; }
        public string AGE { get; set; }
        public string SPOUSE_NAME { get; set; }
        public string CORR_HSNO { get; set; }
        public string CORR_LOCATION { get; set; }
        public string CORR_TELEPHONE { get; set; }
        public string CORR_MOBILE { get; set; }
        public string CORR_COUNTRY_ID { get; set; }
        public string CORR_STATE_ID { get; set; }
        public string CORR_DISTRICT_ID { get; set; }
        public string CORR_CITY { get; set; }
        public string CORR_DURATION_OF_STAY { get; set; }
        public string CORR_EMAIL_ID { get; set; }
        public string CORR_PINCODE { get; set; }
        public string PER_HSNO { get; set; }
        public string PER_LOCATION { get; set; }
        public string PER_TELEPHONE { get; set; }
        public string PER_MOBILE { get; set; }
        public string PER_COUNTRY_ID { get; set; }
        public string PER_STATE_ID { get; set; }
        public string PER_DISTRICT_ID { get; set; }
        public string PER_CITY { get; set; }
        public string PER_DURATION_OF_STAY { get; set; }
        public string PER_EMAIL_ID { get; set; }
        public string PER_PINCODE { get; set; }
        public string PATIENT_SOURCE { get; set; }
        public string PATIENT_SOURCE_NAME { get; set; }
        public string PATIENT_SOURCE_ADDRESS { get; set; }
        public string PATIENT_SOURCE_CONTACTNO { get; set; }
        public string REMARKS { get; set; }
        public string IS_PATIENT_PRESENT { get; set; }
        public string ATTENDER_NAME { get; set; }
        public string PATIENT_IMAGE_PATH { get; set; }
        public string NEXTKIN_NAME { get; set; }
        public string NEXTKIN_CONTACTNO { get; set; }
        public string NEXTKIN_RELATIONSHIP { get; set; }
        public string NEXTKIN_ADDRESS { get; set; }
        public string CREATED_BY { get; set; }
        public string HOSPITAL_LOCATION { get; set; }
        public DateTime CREATED_DATE { get; set; }
        public DateTime MODIFIED_DATE { get; set; }
        public string PATIENT_STATUS { get; set; }
    }
}
