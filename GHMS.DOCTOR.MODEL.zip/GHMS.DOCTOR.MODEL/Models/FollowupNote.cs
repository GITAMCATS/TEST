﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class FollowupNote
    {
        public int FOLLOWUP_NOTE_ID { get; set; }
        public int VISIT_ID { get; set; }
        public string PATIENT_ID { get; set; }
        public int CONSULTANT_ID { get; set; }
        public string CLINICAL_NOTES { get; set; }
        public System.DateTime DT_TIME { get; set; }
    }
}
