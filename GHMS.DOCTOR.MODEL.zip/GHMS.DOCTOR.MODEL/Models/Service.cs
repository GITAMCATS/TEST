﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class Service
    {
        public int id { get; set; }
        public int Service_id { get; set; }
        public string Service_desc { get; set; }
        public string Patient_id { get; set; }
        public int Visit_ID { get; set; }
        public string Dept_id { get; set; }
        public int Doctor_id { get; set; }
        public DateTime Generate_date { get; set; }
        public string CONSULTANT_NAME { get; set; }
       
    }
}
