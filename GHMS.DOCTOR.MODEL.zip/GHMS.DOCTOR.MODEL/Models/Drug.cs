﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.DOCTOR.MODEL.Models
{
    public class Drug
    {
        public int id { get; set; }
        public int drug_id { get; set; }
        public string drug__desc { get; set; }
        public string Patient_id { get; set; }
        public int Visit_ID { get; set; }
        public string duration { get; set; }
        public double quantity { get; set; }
        public string dosage { get; set; }
        public int Doctor_id { get; set; }
        public DateTime Generate_date { get; set; }
        public string CONSULTANT_NAME { get; set; }
       
    }
}
